#!/usr/bin/env python3
"""Integrate the common navigation into the user's current layout without replacing it."""
from pathlib import Path
import re
import sys
p=Path(sys.argv[1] if len(sys.argv)>1 else 'app/layouts/default.vue')
s=p.read_text(encoding='utf-8')
if '<NavigationAppNavigation' in s:
    print('Навигация уже установлена; изменений нет.')
    sys.exit(0)
slots=list(re.finditer(r'<slot\s*/>',s))
if len(slots)!=1 or not re.search(r'<main\b[^>]*>[\s\S]*<slot\s*/>[\s\S]*</main>',s):
    sys.exit('Остановка: не найден единственный <slot /> внутри <main>. Файл не изменён; требуется адаптация layout.')
backup=p.with_name(p.name+'.before-navigation.bak')
if not backup.exists():backup.write_text(s,encoding='utf-8')
s=s[:slots[0].start()]+'''<NavigationAppNavigation v-if="!['/login', '/activate-account', '/verify-email'].includes($route.path)" />
        <div class="space-page-body"><slot /></div>'''+s[slots[0].end():]
s+='''
<style scoped>
/* Keep the global path above page-local scrolling and absolute-positioned tables. */
.main-content { display: flex; flex-direction: column; overflow: hidden; }
.main-content > :deep(.app-navigation) { flex: 0 0 auto; }
.space-page-body { position: relative; flex: 1 1 0; min-width: 0; min-height: 0; overflow: auto; }
.main-content--contained > .space-page-body { overflow: hidden; }
</style>
'''
p.write_text(s,encoding='utf-8')
print('Навигация добавлена. Исходный layout сохранён в .bak.')
