import { readFile, writeFile, copyFile } from 'node:fs/promises';
const path = 'prisma/schema.prisma';
const original = await readFile(path, 'utf8');
const fields = `  passwordResetTokenHash   String? @unique @db.VarChar(64)
  passwordResetExpiresAt   DateTime?
  passwordResetRequestedAt DateTime?
  externalSessionVersion   Int @default(0)
`;
if (original.includes('passwordResetTokenHash')) {
  for (const field of ['passwordResetExpiresAt', 'passwordResetRequestedAt', 'externalSessionVersion', 'model PasswordResetLimit']) {
    if (!original.includes(field)) throw new Error('Обнаружена частичная правка схемы. Проверьте поля восстановления пароля.');
  }
  console.log('Поля уже добавлены.');
} else {
  if (!/model User\s*\{/.test(original)) throw new Error('Модель User не найдена.');
  const updated = original.replace(/model User\s*\{/, match => `${match}\n${fields}`) + `
model PasswordResetLimit {
  key String @id @db.VarChar(100)
  startedAt DateTime
  count Int
  @@index([startedAt])
  @@map("password_reset_limits")
}
`;
  await copyFile(path, `${path}.before-password-reset.bak`);
  await writeFile(path, updated);
  console.log('Схема обновлена, резервная копия сохранена. Выполните prisma validate / migrate deploy / generate.');
}
