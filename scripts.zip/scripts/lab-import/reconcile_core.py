#!/usr/bin/env python3
"""Read-only legacy CSV / Space snapshot comparison. Python 3.10+, stdlib only."""
import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

FIELDS = {
    'sampling': {'number': 'Номер акта отбора проб', 'date': 'Дата отбора проб',
                 'plp': 'ПЛП', 'object': 'Наименование объекта', 'place': 'Место отбора проб',
                 'person': 'Лицо, предоставившее пробу', 'note': 'Примечание'},
    'receipts': {'date': 'Дата поступления', 'material': 'Материал',
                 'qualityDate': 'Дата документа о качестве', 'qualityNumber': 'Номер документа о качестве',
                 'manufacturer': 'Предприятие изготовитель'},
    'protocols': {'number': 'Номер', 'date': 'Дата', 'result': 'Результат испытаний'},
}
KEYS = {'sampling': ('number', 'date'), 'receipts': ('material', 'date', 'qualityNumber', 'qualityDate', 'manufacturer'),
        'protocols': ('number', 'date')}
RELATIONS = {'receipts': ('Отбор проб', 'sampling'), 'protocols': ('Поступление материала', 'receipts')}
DATES = {'date', 'qualityDate'}


def norm(value):
    return re.sub(r'\s+', ' ', str(value or '').replace('\xa0', ' ')).strip()


def canonical(value, field):
    value = norm(value)
    if not value or field not in DATES:
        return value
    for fmt in ('%d.%m.%Y', '%Y-%m-%d'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).date().isoformat()
    except ValueError:
        raise ValueError(f'Invalid date: {value!r}')


def read_csv(path, encoding, delimiter):
    with open(path, encoding=encoding, newline='') as f:
        reader = csv.reader(f, delimiter=delimiter)
        headers = [norm(h).lstrip('\ufeff') for h in next(reader)]
        named = [h for h in headers if h]
        if len(named) != len(set(named)):
            raise ValueError(f'Duplicate column names: {path}')
        rows = []
        for line, values in enumerate(reader, 2):
            if not any(norm(v) for v in values):
                continue
            if len(values) != len(headers):
                raise ValueError(f'{path}: record {line}: expected {len(headers)} columns, got {len(values)}')
            rows.append((line, dict(zip(headers, values))))
        return headers, rows


def write_csv(path, rows, columns):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=columns, delimiter=';')
        writer.writeheader()
        for row in rows:
            # Reports may be opened in Excel; prevent values becoming formulas.
            writer.writerow({k: ("'" + str(v) if str(v).lstrip().startswith(('=', '+', '-', '@')) else v)
                             for k, v in row.items() if k in columns})


def run(args):
    snapshot = json.loads(Path(args.snapshot).read_text(encoding='utf-8'))
    if snapshot.get('version') != 1:
        raise ValueError('Unsupported snapshot version')
    config = json.loads(Path(args.config).read_text(encoding='utf-8')) if args.config else {}
    maps = {}
    if args.id_map:
        headers, rows = read_csv(args.id_map, args.encoding, args.delimiter)
        if not {'entity', 'legacy_id', 'space_id'} <= set(headers):
            raise ValueError('ID map needs entity;legacy_id;space_id')
        for _, row in rows:
            key = (norm(row['entity']), norm(row['legacy_id']))
            if key[0] not in FIELDS or not key[1] or key in maps:
                raise ValueError(f'Invalid or duplicate map entry: {key}')
            maps[key] = norm(row['space_id'])
    report, differences, links, coverage, warnings = [], [], [], [], []
    resolved, legacy_indexes = {}, {}
    for entity, defaults in FIELDS.items():
        source = getattr(args, entity)
        if not source:
            warnings.append(f'{entity}: legacy export not provided')
            resolved[entity], legacy_indexes[entity] = [], {}
            continue
        columns = {**defaults, **config.get(entity, {}).get('columns', {})}
        id_column = config.get(entity, {}).get('id', 'ID')
        headers, source_rows = read_csv(source, args.encoding, args.delimiter)
        missing = [v for v in columns.values() if v not in headers]
        if missing:
            warnings.append(f'{entity}: missing comparison columns: {missing}')
        if id_column not in headers:
            warnings.append(f'{entity}: no legacy ID column {id_column!r}; incoming links cannot be resolved')
        current = snapshot[entity]
        by_id = {str(r['id']): r for r in current}
        if len(by_id) != len(current):
            raise ValueError(f'{entity}: duplicate Space IDs in snapshot')
        active = [r for r in current if not r.get('deleted')]
        key_index, number_index = defaultdict(list), defaultdict(list)
        for r in active:
            r['_norm'] = {k: canonical(r.get(k), k) for k in columns}
            key_index[tuple(r['_norm'].get(k, '') for k in KEYS[entity])].append(r)
            if 'number' in columns:
                number_index[r['_norm']['number']].append(r)
        items, legacy_index = [], defaultdict(list)
        for line, row in source_rows:
            old_id = norm(row.get(id_column))
            item = {'entity': entity, 'row': line, 'legacy_id': old_id, 'space_id': '',
                    'status': '', 'basis': '', 'candidates': '', 'detail': '', '_row': row, '_target': None}
            items.append(item)
            if old_id:
                legacy_index[old_id].append(item)
            try:
                values = {k: canonical(row.get(h), k) for k, h in columns.items() if h in headers}
            except ValueError as e:
                item.update(status='INVALID_DATA', detail=str(e))
                continue
            target_id = maps.get((entity, old_id)) if old_id else None
            if target_id is not None:
                target = by_id.get(target_id)
                if not target or target.get('deleted'):
                    item.update(status='INVALID_MAP', detail='Mapped Space record missing or deleted')
                    continue
                candidates, basis = [target], 'EXPLICIT_MAP'
            else:
                required = KEYS[entity]
                # Receipts have no unique business identifier: full tuple is only a candidate.
                usable = all(k in values for k in required) and (
                    bool(values.get('number') and values.get('date')) if entity != 'receipts'
                    else bool(values.get('material') and values.get('date')))
                candidates = key_index.get(tuple(values.get(k, '') for k in required), []) if usable else []
                basis = 'BUSINESS_KEY'
                if len(candidates) > 1:
                    exact = [r for r in candidates if all(r['_norm'].get(k, '') == v for k, v in values.items())]
                    if len(exact) == 1:
                        candidates = exact
                        basis = 'ALL_AVAILABLE_FIELDS'
                if not candidates:
                    hints = number_index.get(values.get('number'), []) if values.get('number') else []
                    item.update(status='REVIEW_CANDIDATES' if hints else ('NOT_FOUND' if usable else 'INSUFFICIENT_KEY'),
                                candidates=','.join(str(r['id']) for r in hints), detail='No unique full business-key match')
                    continue
            item['candidates'] = ','.join(str(r['id']) for r in candidates)
            if len(candidates) != 1:
                item['status'] = 'AMBIGUOUS'
                continue
            target = candidates[0]
            changes = [(k, v, canonical(target.get(k), k)) for k, v in values.items()
                       if v != canonical(target.get(k), k)]
            item.update(space_id=str(target['id']), _target=target, basis=basis,
                        status='DIFFERENT' if changes else ('PARTIAL_MATCH' if missing else 'MATCH'))
            for k, old, new in changes:
                differences.append({'entity': entity, 'row': line, 'legacy_id': old_id,
                                    'space_id': target['id'], 'field': columns[k], 'legacy': old, 'space': new})
        # Never resolve duplicate legacy IDs or multiple legacy rows to the same Space row silently.
        collisions = defaultdict(list)
        for item in items:
            if item['_target']:
                collisions[item['space_id']].append(item)
        for group in list(legacy_index.values()) + list(collisions.values()):
            if len(group) > 1:
                for item in group:
                    item.update(status='DUPLICATE_MAPPING', detail='Duplicate legacy ID or multiple source rows target one Space row', _target=None)
        resolved[entity], legacy_indexes[entity] = items, legacy_index
        used = {i['space_id'] for i in items if i['_target']}
        for r in current:
            if r.get('deleted') or str(r['id']) not in used:
                coverage.append({'entity': entity, 'space_id': r['id'],
                                 'status': 'SOFT_DELETED' if r.get('deleted') else 'NOT_MATCHED_IN_EXPORT'})
        report.extend(items)
    sampling_by_receipt, sampling_by_protocol = defaultdict(list), defaultdict(list)
    for s in snapshot['sampling']:
        if not s.get('deleted'):
            sampling_by_receipt[str(s.get('receiptId', ''))].append(s)
            if s.get('protocolId'):
                sampling_by_protocol[str(s['protocolId'])].append(s)
    for entity, (default_header, parent_entity) in RELATIONS.items():
        header = config.get(entity, {}).get('relation', default_header)
        for item in resolved[entity]:
            old_parent = norm(item['_row'].get(header))
            result = {'entity': entity, 'row': item['row'], 'legacy_id': item['legacy_id'],
                      'space_id': item['space_id'], 'relation': header, 'legacy_target': old_parent,
                      'expected_space_id': '', 'actual_space_id': '', 'status': ''}
            parents = legacy_indexes[parent_entity].get(old_parent, [])
            if not old_parent:
                result['status'] = 'EMPTY_OR_MISSING_LEGACY_LINK'
            elif not item['_target']:
                result['status'] = 'SOURCE_UNRESOLVED'
            elif len(parents) != 1 or not parents[0]['_target']:
                result['status'] = 'LEGACY_TARGET_UNRESOLVED'
            else:
                expected = parents[0]['space_id']
                connected = (sampling_by_receipt if entity == 'receipts' else sampling_by_protocol).get(item['space_id'], [])
                actual = [str(s['id'] if entity == 'receipts' else s['receiptId']) for s in connected]
                result.update(expected_space_id=expected, actual_space_id=','.join(actual),
                              status=('MATCH_BY_RESOLVED_RECORDS' if actual == [expected] else 'LINK_MISMATCH'))
            links.append(result)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    write_csv(out / 'records.csv', report, ['entity', 'row', 'legacy_id', 'space_id', 'status', 'basis', 'candidates', 'detail'])
    write_csv(out / 'differences.csv', differences, ['entity', 'row', 'legacy_id', 'space_id', 'field', 'legacy', 'space'])
    write_csv(out / 'links.csv', links, ['entity', 'row', 'legacy_id', 'space_id', 'relation', 'legacy_target', 'expected_space_id', 'actual_space_id', 'status'])
    write_csv(out / 'space-coverage.csv', coverage, ['entity', 'space_id', 'status'])
    summary = {'snapshotAt': snapshot.get('exportedAt'), 'warnings': warnings,
               'records': {e: dict(Counter(i['status'] for i in resolved[e])) for e in FIELDS},
               'links': dict(Counter(i['status'] for i in links)), 'fieldDifferences': len(differences),
               'note': 'Business-key matches are comparison candidates, not proof of historical identity. No data was changed.'}
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snapshot', required=True)
    for entity in FIELDS:
        p.add_argument('--' + entity)
    p.add_argument('--id-map', help='Optional verified CSV: entity;legacy_id;space_id')
    p.add_argument('--config', help='Optional JSON header overrides')
    p.add_argument('--encoding', default='utf-8-sig')
    p.add_argument('--delimiter', default=';')
    p.add_argument('--out', required=True, help='New report directory (must not exist)')
    return p


if __name__ == '__main__':
    args = parser().parse_args()
    if not any(getattr(args, e) for e in FIELDS):
        raise SystemExit('Provide at least one legacy CSV export')
    try:
        run(args)
    except (ValueError, KeyError, OSError, StopIteration) as e:
        raise SystemExit(f'Error: {e}')
