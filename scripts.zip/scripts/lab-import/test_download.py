import importlib.util
import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('download',Path(__file__).with_name('2-download.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Response(io.BytesIO):
    status=200
    def __init__(self,body):
        super().__init__(body);self.headers={'Content-Type':'application/pdf','Content-Length':str(len(body))}
    def geturl(self):return 'https://portal.avtodor-eng.ru/document'

class DownloadTests(unittest.TestCase):
    def test_validation(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):m.destination(Path(d),'../../outside')
        with self.assertRaises(ValueError):m.check_url('https://example.com/a')
        with self.assertRaises(ValueError):m.check_content(b'<html>login','.pdf','text/html')
        with self.assertRaises(ValueError):m.check_content(b'garbage','.pdf','application/pdf')
        m.check_content(b'%PDF-1.7\n','.pdf','application/pdf')

    def test_download_resume_and_conflict(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);root=p/'files'
            entry={'entity':'sampling','legacy_id':'12','file_id':'34','space_id':'56','approved':True,
                   'status':'MATCH','relative_path':'object/place/2025-01-01/file.pdf',
                   'url':'https://portal.avtodor-eng.ru/?list_id=176&element_id=12&file_id=34'}
            (p/'plan.json').write_text(json.dumps({'version':2,'documents':[entry]}))
            args=SimpleNamespace(plan=str(p/'plan.json'),root=str(root),execute=False,cookies=None,timeout=1,max_mb=1)
            with patch.object(m,'build_opener') as mocked:
                m.main(args);mocked.assert_not_called()
            args.execute=True
            opener=SimpleNamespace(open=lambda *a,**kw:Response(b'%PDF-1.7\ntest'))
            with patch.object(m,'build_opener',return_value=opener):m.main(args)
            self.assertTrue((root/entry['relative_path']).exists())
            with patch.object(m,'build_opener') as mocked:
                m.main(args);mocked.return_value.open.assert_not_called()
            (root/entry['relative_path']).write_bytes(b'changed')
            with patch.object(m,'build_opener'):
                with self.assertRaises(SystemExit):m.main(args)
            self.assertEqual((root/entry['relative_path']).read_bytes(),b'changed')

if __name__=='__main__':unittest.main()
