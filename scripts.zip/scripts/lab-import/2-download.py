#!/usr/bin/env python3
"""Download approved documents from a reviewed plan. Dry run unless --execute."""
import argparse
import hashlib
import http.cookiejar
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from urllib.error import HTTPError
from urllib.parse import urlsplit, parse_qs
from urllib.request import build_opener, HTTPRedirectHandler, HTTPCookieProcessor, Request

HOST='portal.avtodor-eng.ru'
LIST_IDS={'sampling':'176','receipts':'177','protocols':'178'}


def check_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or p.hostname!=HOST or p.port not in (None,443) or p.username or p.password:
        raise ValueError('URL or redirect outside the allowed HTTPS portal')


class SamePortalRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        check_url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def destination(root,relative):
    p=PurePosixPath(relative)
    if p.is_absolute() or '..' in p.parts or '\\' in relative or not p.parts:
        raise ValueError('Unsafe relative path')
    target=(root/Path(*p.parts)).resolve()
    if not target.is_relative_to(root) or target==root:
        raise ValueError('Destination escapes root')
    return target


def validate(entry,root):
    if entry.get('blocked_reason') or not entry.get('relative_path'):
        raise ValueError('Blocked document cannot be approved; fix mapping and rerun analysis')
    if entry.get('status') not in ('MATCH','PARTIAL_MATCH','DIFFERENT') or entry.get('link_status')=='LINK_MISMATCH':
        raise ValueError('Unresolved or conflicting mapping')
    check_url(entry['url'])
    q=parse_qs(urlsplit(entry['url']).query)
    for key,wanted in [('element_id',entry['legacy_id']),('file_id',entry['file_id']),('list_id',LIST_IDS[entry['entity']])]:
        if q.get(key)!=[str(wanted)]:raise ValueError('Plan URL metadata mismatch')
    return destination(root,entry['relative_path'])


def check_content(prefix,suffix,content_type):
    data=prefix.lstrip().lower()
    if 'html' in content_type.lower() or data.startswith((b'<!doctype html',b'<html',b'<head',b'<body')):
        raise ValueError('Portal returned an HTML page, possibly the login page')
    signatures={'.pdf':(b'%PDF-',),'.png':(b'\x89PNG\r\n\x1a\n',),'.jpg':(b'\xff\xd8\xff',),
                '.jpeg':(b'\xff\xd8\xff',),'.tif':(b'II*\x00',b'MM\x00*'),'.tiff':(b'II*\x00',b'MM\x00*'),
                '.doc':(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1',),'.xls':(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1',),
                '.zip':(b'PK\x03\x04',),'.docx':(b'PK\x03\x04',),'.xlsx':(b'PK\x03\x04',)}
    if suffix.lower() not in signatures:raise ValueError('Unsupported document extension; add an explicit content validator')
    if not any(prefix.startswith(s) for s in signatures[suffix.lower()]):raise ValueError('Document signature does not match extension')


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def main(args):
    plan=json.loads(Path(args.plan).read_text(encoding='utf-8'))
    if plan.get('version')!=2:raise ValueError('Unsupported plan version')
    root=Path(args.root).expanduser().resolve()
    selected=[e for e in plan['documents'] if e.get('approved') is True]
    targets=[validate(e,root) for e in selected]
    if len(targets)!=len(set(targets)):raise ValueError('Duplicate output paths in approved plan')
    print(f'Approved documents: {len(selected)} / {len(plan["documents"])}')
    if not args.execute:
        for e,t in zip(selected,targets):print(f'{e["entity"]} Space {e["space_id"]}: {t}')
        print('Dry run. No requests or file writes were performed.')
        return
    if not selected:raise ValueError('No approved documents; review download-plan.json first')
    root.mkdir(parents=True,exist_ok=True)
    logpath=root/'download-log.jsonl'
    old={}
    if logpath.exists():
        for line in logpath.read_text(encoding='utf-8').splitlines():
            r=json.loads(line)
            if r.get('status')=='DOWNLOADED':old[r['relative_path']]=r
    jar=http.cookiejar.MozillaCookieJar()
    if args.cookies:jar.load(args.cookies,ignore_discard=True,ignore_expires=False)
    opener=build_opener(SamePortalRedirect(),HTTPCookieProcessor(jar))
    failures=0
    for e,target in zip(selected,targets):
        result={k:e[k] for k in ('entity','space_id','legacy_id','file_id','relative_path')}
        result['time']=datetime.now(timezone.utc).isoformat()
        temporary=None
        try:
            if target.exists():
                known=old.get(e['relative_path'])
                if (known and all(str(known.get(k))==str(e[k]) for k in ('entity','space_id','legacy_id','file_id'))
                    and digest(target)==known.get('sha256')):
                    result.update(status='SKIPPED_VERIFIED',sha256=known['sha256'])
                else:raise ValueError('Existing file has no matching verified download record; not overwritten')
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                # Recheck after directory creation to reject symlink escapes.
                target=destination(root,e['relative_path'])
                req=Request(e['url'],headers={'User-Agent':'Space-Lab-Migration/2','Accept-Encoding':'identity'})
                with opener.open(req,timeout=args.timeout) as response:
                    check_url(response.geturl())
                    if response.status!=200:raise ValueError(f'Unexpected HTTP status {response.status}')
                    length=response.headers.get('Content-Length')
                    limit=args.max_mb*1024*1024
                    if length and int(length)>limit:raise ValueError('Document exceeds size limit')
                    prefix=response.read(4096)
                    check_content(prefix,target.suffix,response.headers.get('Content-Type',''))
                    fd,temporary=tempfile.mkstemp(prefix='.download-',suffix='.part',dir=target.parent)
                    size=0;h=hashlib.sha256()
                    with os.fdopen(fd,'wb') as f:
                        block=prefix
                        while block:
                            size+=len(block)
                            if size>limit:raise ValueError('Document exceeds size limit')
                            h.update(block);f.write(block);block=response.read(1024*1024)
                        f.flush();os.fsync(f.fileno())
                    if length and size!=int(length):raise ValueError('Incomplete response body')
                    # Atomic publish without overwriting an existing file (same filesystem).
                    os.link(temporary,target)
                    os.unlink(temporary);temporary=None
                    result.update(status='DOWNLOADED',bytes=size,sha256=h.hexdigest())
        except Exception as exc:
            failures+=1
            # Do not log request headers, cookies or complete URLs.
            result.update(status='ERROR',error=(f'HTTP {exc.code}' if isinstance(exc,HTTPError) else str(exc)))
        finally:
            if temporary and os.path.exists(temporary):os.unlink(temporary)
        with logpath.open('a',encoding='utf-8') as f:
            f.write(json.dumps(result,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
        print(f'{result["status"]}: {e["entity"]} Space {e["space_id"]}')
    if failures:raise SystemExit(f'{failures} downloads failed; inspect download-log.jsonl')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',required=True);p.add_argument('--root',required=True)
    p.add_argument('--cookies',help='Local Netscape-format cookie file; never share this file')
    p.add_argument('--execute',action='store_true');p.add_argument('--timeout',type=int,default=60)
    p.add_argument('--max-mb',type=int,default=100)
    a=p.parse_args()
    if a.max_mb<=0 or a.timeout<=0:p.error('Limits must be positive')
    main(a)
