"""Internal helper; can also analyze an existing snapshot without accessing the DB."""
import argparse
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
import reconcile_core as core

SPECS = {
 'sampling': ('sampling.csv', '176', 'Документ отбора проб'),
 'receipts': ('receivedMaterials.csv', '177', 'Документ о качестве'),
 'protocols': ('testProtocols.csv', '178', 'Протокол испытаний')
}
HOST = 'portal.avtodor-eng.ru'


def safe(value):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(value)).strip(' .')
    return value[:90] or 'unnamed'


def load(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f, delimiter=';')
        rows = list(reader)
        if any(None in r or any(v is None for v in r.values()) for r in rows):
            raise ValueError(f'Incorrect column count in {path.name}')
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError(f'Duplicate headers in {path.name}')
        return reader.fieldnames, rows


def analyze(args):
    output = Path(args.out)
    normalized = output / 'normalized'
    normalized.mkdir(exist_ok=False)
    sources, audit, metadata = {}, {}, {}
    for entity, (filename, list_id, document) in SPECS.items():
        path = Path(args.input) / filename
        headers, rows = load(path)
        required = set(core.FIELDS[entity].values()) | {document}
        if not required <= set(headers):
            raise ValueError(f'{filename}: missing columns {sorted(required-set(headers))}')
        link_header = 'Ссылка' if 'Ссылка' in headers else ''
        if link_header not in headers:
            raise ValueError(f'{filename}: link column not found')
        metadata[entity] = []
        for rownum, row in enumerate(rows, 2):
            url = row[link_header].strip()
            parsed = urlsplit(url)
            q = parse_qs(parsed.query)
            valid = (parsed.scheme == 'https' and parsed.hostname == HOST and not parsed.username
                     and not parsed.password and parsed.port in (None,443)
                     and q.get('list_id') == [list_id]
                     and len(q.get('element_id', [])) == 1 and len(q.get('file_id', [])) == 1
                     and q['element_id'][0].isdigit() and q['file_id'][0].isdigit())
            if not valid:
                raise ValueError(f'{filename}: record {rownum}: invalid or unexpected document URL')
            legacy_id = q['element_id'][0]
            if row.get('ID','').strip() not in ('', legacy_id):
                raise ValueError(f'{filename}: record {rownum}: ID conflicts with URL')
            row['ID'] = legacy_id
            metadata[entity].append({'url': url, 'legacy_id': legacy_id, 'file_id': q['file_id'][0],
                                     'filename': row[document], 'row': rownum})
        sources[entity] = rows
        audit[entity] = {'file': filename, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'rows': len(rows), 'columns': headers,
                         'empty': {h: sum(not r[h].strip() for r in rows) for h in headers},
                         'duplicate_numbers': {k:v for k,v in Counter(r[core.FIELDS[entity].get('number','Номер документа о качестве')] for r in rows).items() if v>1}}
    # Receipt exports use display titles, NOT foreign-key IDs. Resolve only unique titles.
    titles = defaultdict(list)
    for row in sources['sampling']:
        titles[core.norm(row.get('Название'))].append(row['ID'])
    title_report = []
    for n, row in enumerate(sources['receipts'], 2):
        title = core.norm(row.get('Отбор проб'))
        ids = titles.get(title, [])
        row['Resolved sampling ID'] = ids[0] if len(ids)==1 else ''
        title_report.append({'row': n, 'legacy_id': row['ID'], 'title': title,
                             'status': 'UNIQUE_TITLE_CANDIDATE' if len(ids)==1 else ('AMBIGUOUS_TITLE' if ids else 'TITLE_NOT_IN_EXPORT'),
                             'candidates': ','.join(ids)})
    config = {'receipts': {'relation': 'Resolved sampling ID'}}
    (normalized/'config.json').write_text(json.dumps(config), encoding='utf-8')
    argv = ['--snapshot', args.snapshot, '--out', str(output/'reports'), '--config', str(normalized/'config.json')]
    for entity, rows in sources.items():
        target = normalized / (entity+'.csv')
        with target.open('w', encoding='utf-8-sig', newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';') if rows else None
            if w: w.writeheader(); w.writerows(rows)
            else: raise ValueError(f'{entity}: empty export')
        argv += ['--'+entity, str(target)]
    if args.id_map: argv += ['--id-map',args.id_map]
    core.run(core.parser().parse_args(argv))
    _, records = load(output/'reports/records.csv')
    _, links = load(output/'reports/links.csv')
    link_status={(r['entity'],int(r['row'])):r['status'] for r in links}
    core.write_csv(output/'reports/receipt-sampling-titles.csv',title_report,['row','legacy_id','title','status','candidates'])
    (output/'source-analysis.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    snap=json.loads(Path(args.snapshot).read_text())
    indexes={e:{str(r['id']):r for r in snap[e] if not r.get('deleted')} for e in SPECS}
    receipt_sampling, protocol_sampling=defaultdict(list),defaultdict(list)
    for s in indexes['sampling'].values():
        receipt_sampling[str(s['receiptId'])].append(s)
        if s.get('protocolId'):protocol_sampling[str(s['protocolId'])].append(s)
    plan=[]
    for r in records:
        entity=r['entity']; meta=metadata[entity][int(r['row'])-2]
        entry={**meta, 'entity':entity, 'space_id':r['space_id'], 'status':r['status'], 'basis':r['basis'],
               'link_status':link_status.get((entity,int(r['row'])),'NOT_APPLICABLE'),
               'approved':False, 'relative_path':None, 'blocked_reason':None}
        if r['status'] not in ('MATCH','PARTIAL_MATCH','DIFFERENT'):
            entry['blocked_reason']='Unresolved or ambiguous record; provide a verified ID map and rerun analysis'
        elif entry['link_status']=='LINK_MISMATCH':
            entry['blocked_reason']='Conflicting legacy and Space relationship'
        else:
            target=indexes[entity][r['space_id']]
            owners=([target] if entity=='sampling' else
                    (receipt_sampling if entity=='receipts' else protocol_sampling).get(r['space_id'],[]))
            date=target.get('date')
            if len(owners)!=1 or not date:
                entry['blocked_reason']='Missing unique Space sampling owner or event date'
            else:
                owner=owners[0]
                if not owner.get('objectId') or not owner.get('locationId'):
                    entry['blocked_reason']='Snapshot lacks object/location IDs; regenerate with 1-analyze.ts'
                else:
                    original=meta['filename']
                    suffix=Path(original).suffix.lower()
                    name=safe(original[:-len(suffix)] if suffix else original)+suffix
                    entry['relative_path']='/'.join([safe(owner['object'])+'__o'+owner['objectId'],
                        safe(owner['place'])+'__l'+owner['locationId'],core.canonical(date,'date'),
                        entity+'__s'+r['space_id']+'__f'+meta['file_id']+'__'+name])
                    entry['sampling_space_id']=str(owner['id'])
        plan.append(entry)
    (output/'download-plan.json').write_text(json.dumps({'version':2,'snapshotAt':snap.get('exportedAt'),
        'layout':'object__ID/location__ID/event-date/entity__spaceID__fileID__original-name',
        'documents':plan},ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Analysis complete: {output}. All download approvals are initially false.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);p.add_argument('--input',required=True)
    p.add_argument('--out',required=True);p.add_argument('--id-map')
    analyze(p.parse_args())
