import { PrismaClient, Prisma } from '@prisma/client';
import { writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

// Run from the project root with DATABASE_URL available to Prisma.
const db = new PrismaClient();
async function main() {
  const input = process.argv[2];
  const directory = process.argv[3];
  if (!input || !directory) throw new Error('Usage: npx tsx scripts/lab-import/1-analyze.ts CSV_DIRECTORY NEW_OUTPUT_DIRECTORY [ID_MAP_CSV]');
  const outputDir = resolve(directory);
  mkdirSync(outputDir, { recursive: false, mode: 0o700 });
  const output = join(outputDir, 'snapshot.json');
  const snapshot = await db.$transaction(async tx => {
    await tx.$executeRawUnsafe('SET TRANSACTION READ ONLY');
    const sampling = await tx.samplingTest.findMany({
      include: { plp: true, inspector: true, testLocation: { include: { testObject: true } } }
    });
    const receipts = await tx.receiptMaterial.findMany({ include: { material: true, manufacturer: true } });
    const protocols = await tx.testProtocol.findMany();
    return {
      version: 1, exportedAt: new Date().toISOString(),
      sampling: sampling.map(s => ({
        id: String(s.id), deleted: Boolean(s.deletedAt),
        number: s.samplingActNumber, date: s.samplingDate,
        plp: s.plp.name, object: s.testLocation.testObject.name,
        objectId: String(s.testLocation.testObject.id), locationId: String(s.testLocation.id),
        place: s.testLocation.name, person: s.inspector.name, note: s.note,
        receiptId: String(s.receiptMaterialId), protocolId: s.testProtocolId == null ? '' : String(s.testProtocolId)
      })),
      receipts: receipts.map(r => ({
        id: String(r.id), deleted: Boolean(r.deletedAt), date: r.receiptDate,
        material: r.material.name, qualityDate: r.qualityDocumentDate,
        qualityNumber: r.qualityDocumentNumber, manufacturer: r.manufacturer?.name
      })),
      protocols: protocols.map(p => ({
        id: String(p.id), deleted: Boolean(p.deletedAt), number: p.protocolNumber,
        date: p.protocolDate, result: p.testResult
      }))
    };
  }, { isolationLevel: Prisma.TransactionIsolationLevel.RepeatableRead, timeout: 180000 });
  // Exclusive creation prevents overwriting an earlier snapshot.
  writeFileSync(output, JSON.stringify(snapshot), { flag: 'wx', mode: 0o600 });
  console.log(`Snapshot saved: ${output}`);
  const helper = join(dirname(fileURLToPath(import.meta.url)), 'analyze_helper.py');
  const argv = [helper, '--snapshot', output, '--input', resolve(input), '--out', outputDir];
  if (process.argv[4]) argv.push('--id-map', resolve(process.argv[4]));
  const child = spawnSync(process.env.LAB_PYTHON || 'python3', argv, { stdio: 'inherit' });
  if (child.error || child.status !== 0) throw new Error('CSV analysis failed; snapshot retained. ' + (child.error?.message || ''));
  console.log(`Sampling: ${snapshot.sampling.length}; receipts: ${snapshot.receipts.length}; protocols: ${snapshot.protocols.length}`);
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
