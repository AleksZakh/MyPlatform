// scripts/fix-receipt-data.ts
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function fixReceiptData() {
  console.log('🔧 ИСПРАВЛЕНИЕ ДАННЫХ В receipt_materials\n');

  let updated = 0;
  let skipped = 0;
  let errors = 0;

  // Получаем все записи AEng
  const aengRecords = await prisma.aEng.findMany({
    orderBy: { id: 'asc' }
  });

  console.log(`📊 Найдено записей в AEng: ${aengRecords.length}`);

  for (const record of aengRecords) {
    try {
      // Ищем соответствующую запись в receipt_materials
      const receipt = await prisma.receiptMaterial.findFirst({
        where: {
          material: {
            name: record.materialName
          },
          qualDocNumber: record.qualDocNumber && record.qualDocNumber !== '-' ? record.qualDocNumber : ''
        }
      });

      if (!receipt) {
        skipped++;
        continue;
      }

      // Проверяем, нужно ли обновлять
      const needsUpdate: any = {};
      let hasChanges = false;

      // Исправляем qualDate (берем из materialReceiptDate)
      if (record.materialReceiptDate && 
          receipt.qualDate?.getTime() !== record.materialReceiptDate.getTime()) {
        needsUpdate.qualDate = record.materialReceiptDate;
        hasChanges = true;
      }

      // Исправляем qualDocNumber (если было "-", ставим пустую строку)
      const correctDocNumber = record.qualDocNumber && record.qualDocNumber !== '-' ? record.qualDocNumber : '';
      if (receipt.qualDocNumber !== correctDocNumber) {
        needsUpdate.qualDocNumber = correctDocNumber;
        hasChanges = true;
      }

      // Исправляем note (добавляем информацию об объекте и акте)
      const correctNote = `Объект: ${record.objectName || 'неизвестен'}, Место: ${record.samplingPlace || 'неизвестно'}, Акт: ${record.samplingActNumber || 'без номера'}`;
      if (receipt.note !== correctNote) {
        needsUpdate.note = correctNote;
        hasChanges = true;
      }

      if (hasChanges) {
        await prisma.receiptMaterial.update({
          where: { id: receipt.id },
          data: {
            ...needsUpdate,
            editorEmail: 'fix-script@system',
            editedAt: new Date()
          }
        });
        updated++;
        console.log(`✅ Обновлено поступление ID: ${receipt.id} для AEng ID: ${record.id}`);
      } else {
        skipped++;
      }

    } catch (error) {
      errors++;
      console.error(`❌ Ошибка при обработке AEng ID: ${record.id}`, error);
    }
  }

  console.log(`\n📊 ИТОГИ:`);
  console.log(`   ✅ Обновлено: ${updated}`);
  console.log(`   ⏭️ Пропущено: ${skipped}`);
  console.log(`   ❌ Ошибок: ${errors}`);
}

fixReceiptData()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });