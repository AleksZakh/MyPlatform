// @ts-expect-error Модуль доступен в среде выполнения Node.js.
import * as fs from 'node:fs';
// @ts-expect-error Модуль доступен в среде выполнения Node.js.
import * as readline from 'node:readline';
// @ts-expect-error
import * as path from 'node:path';
// @ts-expect-error
import { fileURLToPath } from 'node:url';
// @ts-expect-error Модуль будет установлен через npm
import httpntlm from 'httpntlm'

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const filePath = path.join(__dirname, '../../legacy-data/sampling.csv');
const LOG_FILE = path.join(__dirname, 'import-stats.log');

// Глобальная переменная сессии, которая будет динамически обновляться
let activePortalCookie = '';


async function refreshPortalCookieViaNtlm(): Promise<string> {
    console.log('🔑 [NTLM] Запуск генерации сессионной куки через доменную учетную запись...');
    
    const ntlmOptions = {
        // Запрашиваем корень портала для инициализации сессии
        url: 'https://portal.avtodor-eng.ru', 
        username: 'ivanov', // Имя домена и ваш логин
        password: '0310_a',
        domain: 'CORP',
        workstation: '',
        headers: {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
        }
    };

     return new Promise((resolve, reject) => {
        httpntlm.get(ntlmOptions, (err: any, res: any) => {
            if (err) {
                return reject(new Error(`Сбой NTLM при получении сессии: ${err.message || err}`));
            }

            // Извлекаем заголовки Set-Cookie, которые прислал Apache/Битрикс
            // @ts-ignore
            const setCookieHeaders = typeof res.headers['set-cookie'] === 'object' 
                ? res.headers['set-cookie'] 
                : [res.headers['set-cookie']].filter(Boolean);

            if (!setCookieHeaders || setCookieHeaders.length === 0) {
                return reject(new Error('Сервер ответил успешно, но не прислал заголовки сессии Set-Cookie.'));
            }

            // ИСПРАВЛЕНО: Забираем только то, что идет ДО первой точки с запятой
            // Из "PHPSESSID=123; path=/; HttpOnly" мы получим чистое "PHPSESSID=123"
            const cleanCookies = setCookieHeaders.map((cookieStr: string) => {
                return cookieStr.split(';')[0].trim();
            });

            // Объединяем куки через точку с запятой с пробелом
            // Результат: "PHPSESSID=123; BITRIX_SM_GUEST_ID=456"
            const sessionCookie = cleanCookies.join('; ');

            console.log(' -> [NTLM] Отлично! Живой токен сессии Автодора успешно сгенерирован.');
            resolve(sessionCookie);
        });
    });
}

// Кэш хранит пары: Ключ_Строки -> Полный_Объект_Из_БД
const dbCache = new Map<string, any>();

const TARGET_SERVER_URL = 'https://space.avtodor-eng.ru'; 
const TARGET_SERVER_COOKIE = '';

function parseCsvLine(line: string): string[] {
    return line.split(';');
}

function createMatchKey(actNumber: string, date: string, objectName: string, place: string): string {
    const fuzzyNormalize = (text: string): string => {
        return String(text || '')
            .toLowerCase()
            .replace(/ё/g, 'е')
            .replace(/[№#%?®©™""''«»‘’„“]/g, '')
            .replace(/[–—_]/g, '-')
            .replace(/[^a-zа-я0-9\-,]|\s/g, '')             
            .trim();
    };

    return [
        fuzzyNormalize(actNumber),
        fuzzyNormalize(date),
        fuzzyNormalize(objectName),
        fuzzyNormalize(place)
    ].join('||');
}

/**
 * Скачивание файла с портала Автодор и отправка на целевой сервер с ID
 */
async function downloadAndUploadToTarget(
    fileUrl: string, 
    actNumber: string, 
    date: string, 
    objectName: string, 
    location: string,
    dbRecordId: number
): Promise<void> {
    
    // Если скрипт только запущен и куки еще нет — генерируем её через NTLM автоматический вход
    if (!activePortalCookie) {
        activePortalCookie = await refreshPortalCookieViaNtlm();
    }

    // Выполняем стандартный, стабильный fetch с использованием полученной куки
    const response = await fetch(fileUrl, {
        method: 'GET',
        headers: {
            'Cookie': activePortalCookie, // Подставляем сгенерированную куку
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',
            'sec-ch-ua': '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'Accept': 'application/pdf,application/octet-stream,*/*'
        },
        redirect: 'manual' // Надежный ручной перехват редиректа Битрикса [7]
    });

    // ПЕРЕХВАТ ИСТЕКШЕЙ СЕССИИ (Если в процессе долгой миграции кука протухнет)
    if (response.status === 401) {
        console.warn(`⚠️ Сессия Автодора протухла (401) на акте ${actNumber}. Перевыпуск куки через NTLM...`);
        activePortalCookie = ''; // Сбрасываем старую
        activePortalCookie = await refreshPortalCookieViaNtlm(); // Генерируем новую
        
        console.log(' -> Повторный запрос файла со свежей сессией...');
        return await downloadAndUploadToTarget(fileUrl, actNumber, date, objectName, location, dbRecordId);
    }

    // Обработка ручного редиректа (301/302) до физического PDF-файла [7]
    if (response.status === 301 || response.status === 302 || response.status === 307) {
        let redirectUrl = response.headers.get('location');
        if (redirectUrl) {
            if (redirectUrl.startsWith('/')) {
                redirectUrl = `https://portal.avtodor-eng.ru${redirectUrl}`;
            }
            // Рекурсивно идем дальше по редиректу с нашей кукой
            return await downloadAndUploadToTarget(redirectUrl, actNumber, date, objectName, location, dbRecordId);
        }
    }

    if (!response.ok) {
        throw new Error(`Ошибка скачивания с портала Автодор. Статус: ${response.status} ${response.statusText}`);
    }

    // --- ЭТАП 2: Упаковка в FormData и отправка на целевой бэкенд space.avtodor-eng.ru ---
    const arrayBuffer = await response.arrayBuffer();
    const fileBlob = new Blob([arrayBuffer], { type: 'application/pdf' });

    const formData = new FormData();
    const safeFileName = `act_${actNumber.replace(/\//g, '_')}.pdf`;
    
    formData.append('file', fileBlob, safeFileName);
    formData.append('dbRecordId', String(dbRecordId));
    formData.append('actNumber', actNumber);
    formData.append('date', date);
    formData.append('objectName', objectName);
    formData.append('location', location);

    const uploadResponse = await fetch(`https://space.avtodor-eng.ru`, {
        method: 'POST',
        headers: {
            'Cookie': TARGET_SERVER_COOKIE,
            'X-Migration-Key': 'SuperSecretToken123_AutoDOR'
        },
        body: formData 
    });

    if (!uploadResponse.ok) {
        const errorDetails = await uploadResponse.text();
        throw new Error(`Целевой сервер вернул ошибку при приеме файла. Статус: ${uploadResponse.status}. Детали: ${errorDetails}`);
    }

    const uploadResult = await uploadResponse.json();
    console.log(` -> Ответ от целевого сервера:`, uploadResult.message);
}

/**
 * Вспомогательная рекурсивная функция для следования за NTLM-редиректами
 */
async function downloadAndUploadToTargetRecursive(targetUrl: string, originalOptions: any): Promise<Buffer> {
    const updatedOptions = { ...originalOptions, url: targetUrl };

    return new Promise((resolve, reject) => {
        httpntlm.get(updatedOptions, async (err: any, res: any) => {
            if (err) return reject(new Error(`Низкоуровневый сбой NTLM: ${err.message || err}`));
            
            if (res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307) {
                let nextUrl = res.headers.location;
                if (nextUrl) {
                    if (nextUrl.startsWith('/')) {
                        nextUrl = `https://avtodor-eng.ru${nextUrl}`;
                    }
                    return resolve(await downloadAndUploadToTargetRecursive(nextUrl, originalOptions));
                }
            }

            if (res.statusCode !== 200) {
                return reject(new Error(`Ошибка на этапе редиректа NTLM. Статус: ${res.statusCode}`));
            }

            resolve(res.body);
        });
    });
}

async function loadAllDatabaseRecords(): Promise<void> {
    console.log(' Запуск полной выгрузки данных из БД для кэширования...');
    const BATCH_SIZE = 500;
    let currentPage = 1;
    let hasMoreData = true;
    let totalLoaded = 0;

    while (hasMoreData) {
        const dbRecords = await recordsRequest(currentPage, BATCH_SIZE);
        if (!dbRecords || dbRecords.length === 0) {
            hasMoreData = false;
            break;
        }

        for (const record of dbRecords) {
            const key = createMatchKey(record.samplingActNumber, record.samplingDate, record.objectName, record.samplingPlace);
            dbCache.set(key, record); // Кэшируем объект целиком, чтобы иметь доступ к record.id
        }

        totalLoaded += dbRecords.length;
        console.log(`Загружено записей из БД: ${totalLoaded}...`);

        if (dbRecords.length < BATCH_SIZE) {
            hasMoreData = false;
        } else {
            currentPage++;
        }
    }
    console.log(` Кэширование завершено! В оперативной памяти: ${dbCache.size} уникальных ключей.\n`);
}

async function startMigrationCheck(): Promise<void> {
    await loadAllDatabaseRecords();
    fs.writeFileSync(LOG_FILE, '', 'utf-8');

    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    let headers: string[] = [];
    let processedMatches = 0;
    const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    console.log(`🚀 Начат полный обход CSV-файла...`);

    for await (const line of rl) {
        if (headers.length === 0) {
            headers = parseCsvLine(line);
            continue; 
        }

        const currentLineValues = parseCsvLine(line);
        const rowObject: Record<string, string> = {};

        headers.forEach((headerName, index) => {
            rowObject[headerName] = currentLineValues[index] || '';
        });

        const csvActNumber = String(rowObject['Номер акта отбора проб'] || '').trim();
        const csvDate = String(rowObject['Дата отбора проб'] || '').trim();
        const csvObjectName = String(rowObject['Наименование объекта'] || '').trim();
        const csvPlace = String(rowObject['Место отбора проб'] || '').trim();
        const fileUrl = String(rowObject['Ссылка'] || '').trim();

        const searchKey = createMatchKey(csvActNumber, csvDate, csvObjectName, csvPlace);
        const matchedDbRecord = dbCache.get(searchKey); // Получаем объект из кэша

        if (matchedDbRecord) {
            const dbRecordId = matchedDbRecord.id; // Извлекаем точный ID из базы данных
            processedMatches++;
            
            console.log(`\n Совпадение №${processedMatches} найдено! Акт: ${csvActNumber} (ID в БД: ${dbRecordId})`);

            if (!fileUrl) {
                console.log(`⚠️ Пропуск: Отсутствует ссылка для акта ${csvActNumber}`);
                continue;
            }

            try {
                if (processedMatches > 1) {
                    console.log(' Пауза 3 секунды для предотвращения блокировок...');
                    await delay(3000);
                }

                console.log(`Запуск миграции для ссылки: ${fileUrl}`);
                
                let attempts = 0;
                const MAX_ATTEMPTS = 3;
                let success = false;

                while (attempts < MAX_ATTEMPTS && !success) {
                    try {
                        attempts++;
                        // Передаем dbRecordId шестым параметром
                        await downloadAndUploadToTarget(fileUrl, csvActNumber, csvDate, csvObjectName, csvPlace, dbRecordId);
                        success = true; 
                    } catch (err: any) {
                        const isReset = err.message?.includes('ECONNRESET') || err.cause?.code === 'ECONNRESET';
                        if (isReset && attempts < MAX_ATTEMPTS) {
                            const backoffDelay = attempts * 4000; 
                            console.warn(`⚠️ [Попытка ${attempts}/${MAX_ATTEMPTS}] ECONNRESET. Ожидание ${backoffDelay / 1000} сек...`);
                            await delay(backoffDelay);
                        } else {
                            throw err;
                        }
                    }
                }

                const successLog = [
                    `TIMESTAMP: ${new Date().toISOString()}`,
                    `ACT_NUMBER: ${csvActNumber}`,
                    `DB_ID: ${dbRecordId}`,
                    `RESULT: PROXY_MIGRATION_SUCCESS`,
                    `URL: ${fileUrl}`,
                    `----------------------------------------\n`
                ].join('\n');
                fs.appendFileSync(LOG_FILE, successLog, 'utf-8');
			} catch (migrationError: any) {
				let errorDetails = migrationError.message || migrationError;
				if (migrationError.cause) {
					errorDetails +=  `| Код: ${migrationError.cause.code || migrationError.cause.message}`;
				}
				const errorLog = [
					`TIMESTAMP: ${new Date().toISOString()}`,
					`ACT_NUMBER: ${csvActNumber}`,
					`RESULT: PROXY_MIGRATION_FAILED`,
					`ERROR_MESSAGE: ${errorDetails}`,
					`----------------------------------------\n`
					].join('\n');
				fs.appendFileSync(LOG_FILE, errorLog, 'utf-8');
				console.error(`❌ Ошибка на акте ${csvActNumber}. Остановка.`);
				rl.close();
				process.exit(1);
				}}}
				console.log(`\n🏁 Обработка CSV-файла полностью завершена. Всего совпадений отправлено: ${processedMatches}`);}
				async function recordsRequest(step: number, rowCount: number): Promise<any[]> {
				const url = `${TARGET_SERVER_URL}/api/lab/sampling-test/summary?page=${step}&pageSize=${rowCount}&sortKey=samplingActNumber&sortOrder=desc`;
				try {const response = await fetch(url, {method: 'GET',headers: { 'Cookie': TARGET_SERVER_COOKIE, 'Content-Type': 'application/json' }});
				if (!response.ok) throw new Error(`Ошибка сервера: ${response.status}`);
				const result = await response.json();return result.data || [];
				} catch (error) {return [];}}
				
		startMigrationCheck().catch((error) => {console.error('Глобальная ошибка миграции:', error);});