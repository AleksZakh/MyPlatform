import { detectMigrationDocument } from '../../shared/utils/migration-document';
import * as fs from 'node:fs';
import * as path from 'node:path';
import process from 'node:process';
import * as readline from 'node:readline';
import { Writable } from 'node:stream';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { Agent, request as httpsRequest } from 'node:https';
import { createHash } from 'node:crypto';
import { parse } from 'csv-parse/sync';

const moduleRequire = createRequire(import.meta.url);
interface Credentials { username: string; password: string; domain: string; workstation: string }
interface NtlmApi {
  createType1Message(options: Credentials): string;
  parseType2Message(header: string): unknown;
  createType3Message(challenge: unknown, options: Credentials): string;
}
const ntlm = (moduleRequire('httpntlm') as { ntlm: NtlmApi }).ntlm;
const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const SPACE_ORIGIN = new URL(process.env.SPACE_BASE_URL || 'https://space.avtodor-eng.ru').origin;
const UPLOAD_PATH = '/api/lab/test-protocol/migration/upload';
const CSV_PATH = path.resolve(process.env.CSV_PATH || path.join(scriptDir, '../../legacy-data/testProtocols.csv'));
const LOG_PATH = path.resolve(process.env.PROTOCOL_LOG || path.join(scriptDir, 'protocol-import.log'));
const STATE_PATH = path.resolve(process.env.PROTOCOL_STATE || path.join(scriptDir, 'protocol-state.jsonl'));
const PORTAL_HOST = 'portal.avtodor-eng.ru';
const MAX_BYTES = 50 * 1024 * 1024;
const REQUEST_TIMEOUT = 120_000;
const MAX_REDIRECTS = 10;
const USER_AGENT = 'Space-Lab-Migration/2';
const delay = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));

class MigrationError extends Error {
  constructor(public code: string, message: string, public fatal = false) { super(message); }
}
function safeError(error: unknown): string {
  if (error instanceof MigrationError) return `${error.code}: ${error.message}`;
  // Never serialize HTTP request/options objects: they may contain credentials.
  if (error instanceof Error) return error.message.replace(/[\r\n]+/g, ' ').slice(0, 800);
  return 'Unknown error';
}
function envNumber(name: string, fallback: number): number {
  const value = Number(process.env[name] ?? fallback);
  if (!Number.isSafeInteger(value) || value < 0) throw new Error(`Некорректный ${name}`);
  return value;
}
async function askInput(label: string, secret = false): Promise<string> {
  if (!process.stdin.isTTY) throw new MigrationError('INPUT', 'Нет терминала: задайте учётные данные через окружение.', true);
  process.stdout.write(label);
  const output = secret ? new Writable({ write(_chunk, _encoding, done) { done(); } }) : process.stdout;
  const rl = readline.createInterface({ input: process.stdin, output, terminal: true });
  return new Promise((resolve, reject) => {
    let answered = false;
    rl.on('SIGINT', () => rl.close());
    rl.on('close', () => { if (secret) process.stdout.write('\n');
      if (!answered) reject(new MigrationError('INPUT_CANCELLED', 'Ввод отменён.', true)); });
    rl.question('', answer => { answered = true; rl.close(); resolve(answer); });
  });
}

// Separate jars: cookies never cross between Space and the old portal.
// Ports do not scope HTTP cookies; path/domain/expiry do.
export class CookieJar {
  private cookies = new Map<string, { name: string; value: string; domain: string;
    hostOnly: boolean; path: string; secure: boolean; expires: number }>();
  remember(url: URL, values: string[]): void {
    for (const raw of values) {
      const [pair = '', ...parts] = raw.split(';');
      const equals = pair.indexOf('=');
      if (equals < 1) continue;
      const attrs = new Map<string, string>(parts.map(part => {
        const i = part.indexOf('=');
        return i < 0 ? [part.trim().toLowerCase(), ''] : [part.slice(0, i).trim().toLowerCase(), part.slice(i + 1).trim()];
      }));
      const domain = (attrs.get('domain') || url.hostname).replace(/^\./, '').toLowerCase();
      if (url.hostname !== domain && !url.hostname.endsWith('.' + domain)) continue;
      // Only this portal host (or its parent domain) is needed; reject public suffix cookies.
      if (!domain.includes('.')) continue;
      const defaultPath = url.pathname.slice(0, url.pathname.lastIndexOf('/')) || '/';
      const cookiePath = attrs.get('path')?.startsWith('/') ? attrs.get('path')! : defaultPath;
      const name = pair.slice(0, equals).trim(), value = pair.slice(equals + 1).trim();
      let expires = Date.parse(attrs.get('expires') || '');
      if (!Number.isFinite(expires)) expires = Infinity;
      if (/^-?\d+$/.test(attrs.get('max-age') || '')) expires = Date.now() + Number(attrs.get('max-age')) * 1000;
      const key = `${domain}|${cookiePath}|${name}`;
      if (expires <= Date.now()) this.cookies.delete(key);
      else this.cookies.set(key, { name, value, domain, hostOnly: !attrs.has('domain'),
        path: cookiePath, secure: attrs.has('secure'), expires });
    }
  }
  header(url: URL): string {
    return [...this.cookies.values()].filter(c => c.expires > Date.now() &&
      (!c.secure || url.protocol === 'https:') &&
      (c.hostOnly ? url.hostname === c.domain : url.hostname === c.domain || url.hostname.endsWith('.' + c.domain)) &&
      (url.pathname === c.path || url.pathname.startsWith(c.path.endsWith('/') ? c.path : c.path + '/')))
      .sort((a, b) => b.path.length - a.path.length).map(c => `${c.name}=${c.value}`).join('; ');
  }
}
const spaceJar = new CookieJar(), portalJar = new CookieJar();
async function spaceFetch(endpoint: string, options: RequestInit = {}): Promise<Response> {
  const url = new URL(endpoint, SPACE_ORIGIN);
  if (url.protocol !== 'https:' || url.origin !== SPACE_ORIGIN || url.username || url.password)
    throw new MigrationError('SPACE_URL', 'Недопустимый адрес Space.', true);
  const headers = new Headers(options.headers);
  const cookie = spaceJar.header(url);
  if (cookie) headers.set('Cookie', cookie);
  const response = await fetch(url, { ...options, headers, redirect: 'manual', signal: AbortSignal.timeout(REQUEST_TIMEOUT) });
  spaceJar.remember(url, response.headers.getSetCookie());
  return response;
}
async function assertSpaceResponse(response: Response): Promise<void> {
  if (response.ok) return;
  let reason = '';
  try {
    const body = await response.clone().json() as Record<string, unknown>;
    reason = [body.statusMessage, body.message].filter(v => typeof v === 'string').join(' | ').slice(0, 500);
  } catch { reason = 'Ответ не JSON'; }
  throw new MigrationError(`SPACE_HTTP_${response.status}`,
    `${new URL(response.url).pathname}; ${reason}; WWW-Authenticate=${response.headers.get('www-authenticate') || 'нет'}`,
    [401, 403].includes(response.status) || response.status >= 300 && response.status < 400);
}
async function loginToSpace(): Promise<void> {
  const login = (process.env.SPACE_LOGIN || await askInput('Логин Space: ')).trim();
  let password = process.env.SPACE_PASSWORD || await askInput('Пароль Space: ', true);
  if (!login || !password) throw new MigrationError('SPACE_CREDENTIALS', 'Введите логин и пароль.', true);
  let response: Response;
  try { response = await spaceFetch('/api/auth/login', { method: 'POST',
    headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ login, password }) }); }
  finally { password = ''; }
  await assertSpaceResponse(response);
  const result = await response.json() as { success?: boolean };
  if (result.success !== true || !spaceJar.header(new URL('/api/lab/test-protocol/migration/summary', SPACE_ORIGIN)))
    throw new MigrationError('SPACE_SESSION', 'Space не подтвердил вход или не выдал cookie для API.', true);
  console.log('Вход в Space выполнен.');
}
let credentials: Credentials | undefined;
async function portalCredentials(): Promise<Credentials> {
  if (credentials) return credentials;
  let login = (process.env.PORTAL_LOGIN || await askInput('Логин старого портала: ')).trim();
  const password = process.env.PORTAL_PASSWORD || await askInput('Пароль старого портала: ', true);
  let domain = process.env.PORTAL_DOMAIN || 'CORP';
  if (login.includes('\\')) { const i = login.indexOf('\\'); domain = login.slice(0, i); login = login.slice(i + 1); }
  if (!login || !password) throw new MigrationError('PORTAL_CREDENTIALS', 'Введите логин и пароль портала.', true);
  credentials = { username: login, password, domain, workstation: '' };
  return credentials;
}
export function portalUrl(value: string, base?: URL): URL {
  const url = new URL(value, base);
  if (url.protocol !== 'https:' || url.hostname !== PORTAL_HOST || !['', '443', '8891'].includes(url.port) || url.username || url.password)
    throw new MigrationError('PORTAL_URL', 'Перенаправление за пределы разрешённого портала запрещено.');
  return url;
}
interface PortalResponse { status: number; headers: Record<string, string | string[] | undefined>; body: Buffer }
function header(response: PortalResponse, name: string): string {
  const value = response.headers[name]; return Array.isArray(value) ? value.join(', ') : value || '';
}
// Explicit HTTPS requests let us collect cookies from BOTH NTLM handshake responses,
// keep Type 1/Type 3 on one socket and prohibit automatic cross-host redirects.
async function portalGet(url: URL, agent?: Agent, authorization?: string): Promise<PortalResponse> {
  portalUrl(url.href);
  return new Promise((resolve, reject) => {
    const headers: Record<string, string> = { 'User-Agent': USER_AGENT, Accept: 'application/pdf,image/jpeg,*/*' };
    const cookie = portalJar.header(url);
    if (cookie) headers.Cookie = cookie;
    if (authorization) { headers.Authorization = authorization; headers.Connection = 'keep-alive'; }
    const req = httpsRequest(url, { method: 'GET', headers, agent: agent || false }, res => {
      portalJar.remember(url, res.headers['set-cookie'] || []);
      const chunks: Buffer[] = []; let bytes = 0;
      res.on('data', (chunk: Buffer) => {
        bytes += chunk.length;
        if (bytes > MAX_BYTES) { req.destroy(new MigrationError('FILE_TOO_LARGE', 'Ответ портала больше 50 МиБ.')); return; }
        chunks.push(chunk);
      });
      res.on('error', reject);
      res.on('end', () => resolve({ status: res.statusCode || 0, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    const timer = setTimeout(() => req.destroy(new MigrationError('PORTAL_TIMEOUT', 'Таймаут запроса старого портала.')), REQUEST_TIMEOUT);
    req.on('close', () => clearTimeout(timer));
    req.on('error', reject);
    req.end();
  });
}
const detectDocument = detectMigrationDocument;
function isDocument(response: PortalResponse): boolean {
  return response.status === 200 && !header(response, 'content-type').toLowerCase().includes('text/html') &&
    detectDocument(response.body) !== null;
}
function redirect(response: PortalResponse, url: URL): URL | null {
  if (![301, 302, 303, 307, 308].includes(response.status)) return null;
  const location = header(response, 'location');
  if (!location) throw new MigrationError('PORTAL_REDIRECT', 'Перенаправление без Location.');
  return portalUrl(location, url);
}
async function ntlmHandshake(url: URL): Promise<PortalResponse> {
  const auth = await portalCredentials();
  console.log(`[NTLM] Авторизация: ${url.origin}${url.pathname}`);
  const agent = new Agent({ keepAlive: true, maxSockets: 1 });
  try {
    const first = await portalGet(url, agent, ntlm.createType1Message(auth));
    const challenge = header(first, 'www-authenticate').match(/(?:^|,\s*)NTLM\s+([A-Za-z0-9+/=]+)/i);
    if (!challenge) {
      if (first.status === 200 || redirect(first, url)) return first;
      throw new MigrationError('NTLM_CHALLENGE', `Не получен NTLM challenge, HTTP ${first.status}.`);
    }
    // Give the Agent a chance to release the fully consumed response socket.
    await new Promise<void>(resolve => setImmediate(resolve));
    const type2 = ntlm.parseType2Message('NTLM ' + challenge[1]);
    const final = await portalGet(url, agent, ntlm.createType3Message(type2, auth));
    console.log(`[NTLM] Итоговый HTTP ${final.status}. Проверяем скачивание документа.`);
    if (final.status === 401 || final.status === 403)
      throw new MigrationError('NTLM_DENIED', `Портал отклонил NTLM-вход: HTTP ${final.status}.`);
    return final;
  } finally { agent.destroy(); }
}

// The original URL never changes. Only one handshake and one restart from the
// original URL are allowed per document (no recursive restart at :8891).
export async function downloadPortalDocument(original: string,
  get: (url: URL) => Promise<PortalResponse> = portalGet,
  handshake: (url: URL) => Promise<PortalResponse> = ntlmHandshake): Promise<Buffer> {
  const originalUrl = portalUrl(original);
  let current = originalUrl, authenticated = false, restarted = false;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    let response = await get(current);
    if (isDocument(response)) return response.body;
    const needsAuth = response.status === 401 && /\bNTLM\b/i.test(header(response, 'www-authenticate'));
    if (needsAuth) {
      if (authenticated) throw new MigrationError('PORTAL_AUTH_REPEAT', 'После NTLM портал снова требует вход. Документ пропущен.');
      authenticated = true;
      response = await handshake(current);
      if (isDocument(response)) return response.body;
    }
    const next = redirect(response, current);
    if (next) { current = next; continue; }
    if (authenticated && response.status === 200 && !restarted) {
      restarted = true; current = originalUrl; continue;
    }
    throw new MigrationError(`PORTAL_HTTP_${response.status}`,
      `Документ не получен: ${current.origin}${current.pathname}; Content-Type=${header(response, 'content-type') || 'нет'}`);
  }
  throw new MigrationError('PORTAL_REDIRECT_LIMIT', 'Превышен предел перенаправлений. Документ пропущен.');
}

export function normalizeDate(value: string): string | null {
  const text = String(value || '').trim();
  const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/);
  const local = text.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  const date = iso ? `${iso[1]}-${iso[2]}-${iso[3]}` : local ? `${local[3]}-${local[2]}-${local[1]}` : null;
  if (!date) return null;
  const parsed = new Date(`${date}T00:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === date ? date : null;
}
export function createMatchKey(number: string, date: string, result: string): string {
  const normalize = (value: string) => String(value || '').toLowerCase()
    .replace(/[\s?№#"'«»‘’„“]/g, '');
  const day = normalizeDate(date);
  if (!day || !normalize(number) || !normalize(result)) return '';
  return JSON.stringify([normalize(number), day, normalize(result)]);
}
export function sourceIdentity(value: string): string {
  const url = portalUrl(value);
  const keys = ['list_id', 'element_id', 'field_id', 'file_id'];
  if (keys.every(key => url.searchParams.has(key)))
    return [url.hostname, ...keys.map(key => `${key}=${url.searchParams.get(key)}`)].join('|');
  url.hash = ''; url.searchParams.sort(); return url.href;
}
function jobKey(id: number, source: string): string { return `${SPACE_ORIGIN}|protocol|${id}|${sourceIdentity(source)}`; }
interface RecordRow { id: number; protocolNumber: string | null; protocolDate: string | null; testResult: string | null; protocolDocumentPath: string | null; canStore: boolean }
interface CsvRow { [key: string]: string }
interface JournalRow { at: string; key: string; status: string; id: number; source: string; act: string; path?: string; error?: string; sha256?: string }
const latest = new Map<string, JournalRow>();
function loadJournals(): void {
  if (fs.existsSync(STATE_PATH)) {
    const lines = fs.readFileSync(STATE_PATH, 'utf8').split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]!.trim(); if (!line) continue;
      try {
        const row = JSON.parse(line) as JournalRow;
        if (typeof row.key !== 'string' || !row.key.startsWith(`${SPACE_ORIGIN}|protocol|`) || typeof row.status !== 'string') throw new Error('schema');
        latest.set(row.key, { ...row, sha256: row.sha256 ?? latest.get(row.key)?.sha256 });
      } catch {
        throw new MigrationError('JOURNAL_INVALID', `Повреждён журнал ${STATE_PATH}, строка ${i + 1}. Сохраните копию и проверьте запись; автоматический повтор загрузок остановлен.`, true);
      }
    }
  }
  console.log(`История протоколов: ${latest.size} записей состояния.`);
}
function durableAppend(file: string, text: string): void {
  const fd = fs.openSync(file, 'a', 0o600);
  try { fs.writeFileSync(fd, text); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
}
function journal(row: Omit<JournalRow, 'at'>): void {
  const entry: JournalRow = { ...row, at: new Date().toISOString() };
  // Persist structured state first; if the text log fails, restart still sees this result.
  durableAppend(STATE_PATH, JSON.stringify(entry) + '\n'); latest.set(row.key, entry);
  const result = row.status === 'SUCCESS' ? 'PROXY_MIGRATION_SUCCESS' : row.status;
  durableAppend(LOG_PATH, [`TIMESTAMP: ${entry.at}`, `PROTOCOL_NUMBER: ${row.act.replace(/[\r\n]/g, ' ')}`,
    `DB_ID: ${row.id}`, `RESULT: ${result}`, `URL: ${row.source}`, `SPACE_ORIGIN: ${SPACE_ORIGIN}`,
    row.path ? `PATH: ${row.path}` : '', row.error ? `ERROR_MESSAGE: ${row.error.replace(/[\r\n]/g, ' ')}` : '',
    '----------------------------------------\n'].filter(Boolean).join('\n'));
}
async function loadRecords(): Promise<Map<string, RecordRow[]>> {
  const cache = new Map<string, RecordRow[]>(), ids = new Set<number>();
  for (let page = 1; ; page++) {
    const response = await spaceFetch(`/api/lab/test-protocol/migration/summary?page=${page}&pageSize=500&sortKey=id&sortOrder=asc`);
    await assertSpaceResponse(response);
    const result = await response.json() as { data?: RecordRow[] };
    if (!Array.isArray(result.data)) throw new MigrationError('SPACE_DATA', 'Некорректный ответ summary.', true);
    for (const row of result.data) {
      if (!Number.isSafeInteger(row.id) || row.id <= 0 || ids.has(row.id))
        throw new MigrationError('SPACE_PAGING', 'Некорректные/повторные ID при чтении страниц.', true);
      ids.add(row.id);
      const key = createMatchKey(row.protocolNumber || '', row.protocolDate || '', row.testResult || '');
      if (!key) continue;
      const matches = cache.get(key) || []; matches.push(row); cache.set(key, matches);
    }
    console.log(`Прочитано записей Space: ${ids.size}`);
    if (result.data.length < 500) return cache;
  }
}
async function existingRecord(id: number): Promise<RecordRow> {
  const response = await spaceFetch(`/api/lab/test-protocol/migration/${id}`);
  await assertSpaceResponse(response);
  const body = await response.json() as { success?: boolean; data?: RecordRow };
  if (body.success !== true || body.data?.id !== id || !Object.hasOwn(body.data, 'protocolDocumentPath'))
    throw new MigrationError('SPACE_DETAIL', `Некорректная карточка протокола ID=${id}.`, true);
  return body.data;
}
function filePath(row: RecordRow): string | null {
  const value = row.protocolDocumentPath;
  if (value !== null && typeof value !== 'string') throw new MigrationError('SPACE_DETAIL', 'Некорректный путь.', true);
  return typeof value === 'string' && value.trim() && value.trim() !== '-' ? value : null;
}

interface Verification {
  success: boolean;
  data: RecordRow;
  file: { state: 'ABSENT' | 'MISSING' | 'PRESENT' | 'UNAVAILABLE'; sha256?: string; reason?: string };
}
async function verifyRecord(id: number): Promise<Verification> {
  const response = await spaceFetch(`/api/lab/test-protocol/migration/verify/${id}`);
  await assertSpaceResponse(response);
  const value = await response.json() as Verification;
  if (value.success !== true || value.data?.id !== id || !['ABSENT', 'MISSING', 'PRESENT', 'UNAVAILABLE'].includes(value.file?.state)) {
    throw new MigrationError('VERIFY_INVALID', 'Некорректный ответ проверки файла.', true);
  }
  return value;
}
const retrySources = new Set<string>();
function retryTargets(): Set<string> | null {
  if (!process.env.RETRY_REPORT) return null;
  const targets = new Set<string>();
  for (const line of fs.readFileSync(path.resolve(process.env.RETRY_REPORT), 'utf8').split('\n')) {
    if (!line.trim()) continue;
    const row = JSON.parse(line) as { status?: string; id?: number; source?: string };
    if (!['FAILED', 'UNCERTAIN'].includes(row.status || '')) continue;
    if (!Number.isSafeInteger(row.id) || !row.source) throw new Error('Некорректная запись RETRY_REPORT.');
    const key = jobKey(row.id!, row.source);
    if (!latest.has(key)) throw new Error(`В журнале нет истории для ID=${row.id} на ${SPACE_ORIGIN}. Проверьте PROTOCOL_STATE и SPACE_BASE_URL.`);
    targets.add(key);
    retrySources.add(sourceIdentity(row.source));
  }
  if (!targets.size) throw new Error('В RETRY_REPORT нет FAILED/UNCERTAIN.');
  console.log(`Повторный проход: ${targets.size} назначений из отчёта.`);
  return targets;
}

async function uploadDocument(id: number, expected: RecordRow, bytes: Buffer, repair?: { path: string; sha256: string }): Promise<string> {
  const form = new FormData();
  const document = detectDocument(bytes);
  if (!document) throw new MigrationError('UNSUPPORTED_DOCUMENT', 'Ожидается PDF, JPEG, PNG или XLSX.');
  form.append('file', new Blob([new Uint8Array(bytes)], { type: document.mime }), `protocol_${id}.${document.extension}`);
  form.append('dbRecordId', String(id)); form.append('testProtocolId', String(id)); form.append('expected', JSON.stringify({ protocolNumber: expected.protocolNumber, protocolDate: expected.protocolDate, testResult: expected.testResult }));
  if (repair) form.append('repairMissing', JSON.stringify(repair));
  const response = await spaceFetch(UPLOAD_PATH, { method: 'POST', body: form });
  await assertSpaceResponse(response);
  const result = await response.json() as { success?: boolean; attached?: boolean; testProtocolId?: number; path?: string };
  if (result.success !== true || result.attached === false || !result.path ||
    result.testProtocolId !== undefined && result.testProtocolId !== id)
    throw new MigrationError('UPLOAD_UNCONFIRMED', 'Space не подтвердил привязку файла. Требуется проверка.');
  return result.path;
}

export async function main(): Promise<void> {
  const limit = envNumber('MAX_FILES', 0), pause = envNumber('MIGRATION_DELAY_MS', 3000);
  if (!['0', '1'].includes(process.env.DRY_RUN ?? '1')) throw new Error('DRY_RUN должен быть 0 или 1.');
  const dryRun = process.env.DRY_RUN !== '0';
  if (!['0', '1'].includes(process.env.RECOVER_UNCERTAIN ?? '0')) throw new Error('RECOVER_UNCERTAIN должен быть 0 или 1.');
  const recover = process.env.RECOVER_UNCERTAIN === '1';
  if (!['0', '1'].includes(process.env.REPAIR_MISSING ?? '0')) throw new Error('REPAIR_MISSING должен быть 0 или 1.');
  const repairMissing = process.env.REPAIR_MISSING === '1';
  if (repairMissing && (!recover || !process.env.RETRY_REPORT)) throw new Error('Для REPAIR_MISSING нужны RECOVER_UNCERTAIN=1 и RETRY_REPORT.');
  if (recover && !process.env.RETRY_REPORT) throw new Error('Для RECOVER_UNCERTAIN укажите RETRY_REPORT.');
  const reportPath = path.join(scriptDir, `protocol-report-${new Date().toISOString().replace(/[:.]/g, '-')}-${process.pid}.jsonl`);
  for (const file of [LOG_PATH, STATE_PATH]) fs.mkdirSync(path.dirname(file), { recursive: true });
  const lockPath = STATE_PATH + '.lock';
  let lock: number;
  try { lock = fs.openSync(lockPath, 'wx', 0o600); }
  catch { throw new MigrationError('LOCK', `Есть ${lockPath}. Убедитесь, что другой импорт протоколов не работает, перед удалением оставшегося .lock.`, true); }
  const counts = { success: 0, ready: 0, existing: 0, review: 0, failed: 0, unmatched: 0, ambiguous: 0, missing: 0, invalidDate: 0, reconciled: 0, skipped: 0 };
  try {
    loadJournals();
    const retryKeys = retryTargets();
    const rows = parse(fs.readFileSync(CSV_PATH), { bom: true, delimiter: ';', columns: (names: string[]) => {
      const headers = names.map(name => name.trim());
      if (!headers.includes('Ссылка') && headers.length === 10 && headers[5] === 'Протокол испытаний' && headers[6] === '' && headers[7] === 'Результат испытаний') headers[6] = 'Ссылка';
      if (new Set(headers).size !== headers.length) throw new Error('Повторяющиеся заголовки CSV.');
      return headers;
    }, skip_empty_lines: true }) as CsvRow[];
    const required = ['Номер', 'Дата', 'Результат испытаний', 'Ссылка'];
    if (!rows.length || required.some(name => !Object.hasOwn(rows[0]!, name))) throw new Error('CSV: нужны Номер, Дата, Результат испытаний, Ссылка.');
    await loginToSpace();
    const cache = await loadRecords();
    const rowKey = (row: CsvRow) => createMatchKey(row['Номер'] || '', row['Дата'] || '', row['Результат испытаний'] || '');
    const sourcesById = new Map<number, Set<string>>();
    for (const row of rows) {
      const matches = cache.get(rowKey(row));
      if (matches?.length !== 1 || !row['Ссылка']?.trim()) continue;
      try {
        const id = matches[0]!.id, sources = sourcesById.get(id) || new Set<string>();
        sources.add(sourceIdentity(row['Ссылка']!)); sourcesById.set(id, sources);
      } catch { /* Reported in main loop. */ }
    }
    let attempts = 0, consecutiveAuthFailures = 0;
    for (const [index, row] of rows.entries()) {
      const act = (row['Номер'] || '').trim(), source = (row['Ссылка'] || '').trim();
      const report = (status: string, details: Record<string, unknown> = {}) => durableAppend(reportPath, JSON.stringify({
        at: new Date().toISOString(), csvRecord: index + 2, status, number: act, date: row['Дата'], result: row['Результат испытаний'],
        source, legacyReceipt: row['Поступление материала'], filename: row['Протокол испытаний'], ...details,
      }) + '\n');
      if (retryKeys) {
        try {
          if (!retrySources.has(sourceIdentity(source))) { counts.skipped++; continue; }
        } catch { counts.skipped++; continue; }
      }
      if (!act || !source || !row['Дата']?.trim() || !row['Результат испытаний']?.trim()) { counts.missing++; report('MISSING_FIELDS'); continue; }
      if (!normalizeDate(row['Дата'])) { counts.invalidDate++; report('INVALID_DATE'); continue; }
      const matchKey = rowKey(row), matches = cache.get(matchKey) || [];
      if (!matchKey) { counts.missing++; report('EMPTY_NORMALIZED_KEY'); continue; }
      if (!matches.length) { counts.unmatched++; report('NOT_FOUND'); continue; }
      if (matches.length !== 1) { counts.ambiguous++; report('AMBIGUOUS', { candidateIds: matches.map(row => row.id) }); continue; }
      const id = matches[0]!.id;
      let key: string;
      try { key = jobKey(id, source); } catch (error) { counts.failed++; report('INVALID_URL', { id, error: safeError(error) }); continue; }
      const base = { key, id, source, act };
      if (retryKeys && !retryKeys.has(key)) { counts.review++; report('TARGET_MAPPING_CHANGED', { id }); continue; }
      if ([11681, 11813, 11829].includes(id) || !/[\p{L}\p{N}]/u.test(act)) {
        counts.review++; report('PLACEHOLDER_PROTOCOL_NUMBER', { id }); continue;
      }
      if ((sourcesById.get(id)?.size || 0) > 1) {
        counts.review++; report('MULTIPLE_SOURCE_DOCUMENTS', { id }); continue;
      }
      let postStarted = false;
      let attemptedHash: string | undefined;
      try {
        const current = await existingRecord(id);
        if (createMatchKey(current.protocolNumber || '', current.protocolDate || '', current.testResult || '') !== matchKey) {
          counts.review++; report('RECORD_CHANGED', { id }); continue;
        }
        const history = latest.get(key);
        const previous = history?.status;
        const recovering = recover && previous === 'UNCERTAIN';
        let repair: { path: string; sha256: string } | undefined;
        if (retryKeys) {
          const verified = await verifyRecord(id);
          if (createMatchKey(verified.data.protocolNumber || '', verified.data.protocolDate || '', verified.data.testResult || '') !== matchKey
            || filePath(verified.data) !== filePath(current)) {
            counts.review++; report('RECORD_CHANGED', { id }); continue;
          }
          if (filePath(current) && verified.file.state === 'MISSING' && repairMissing && recovering && history?.sha256) {
            repair = { path: filePath(current)!, sha256: history.sha256 };
          } else if (filePath(current)) {
            if (verified.file.state !== 'PRESENT') {
              counts.review++; report(verified.file.state === 'MISSING' ? 'ATTACHED_FILE_MISSING' : 'ATTACHED_FILE_UNAVAILABLE', { id, path: filePath(current), reason: verified.file.reason, recoveryEnabled: repairMissing, previous, hasPreviousHash: Boolean(history?.sha256) }); continue;
            }
            if (previous === 'UNCERTAIN' || previous === 'UPLOAD_PENDING') {
              if (!history?.sha256 || verified.file.sha256 !== history.sha256) {
                counts.review++; report('ATTACHED_HASH_MISMATCH', { id, path: filePath(current) }); continue;
              }
              counts.reconciled++;
              report('RECONCILED_SUCCESS', { id, path: filePath(current), sha256: verified.file.sha256 });
              if (!dryRun) journal({ ...base, status: 'SUCCESS', path: filePath(current)!, sha256: verified.file.sha256 });
              continue;
            }
            counts.existing++; report('EXISTING_VERIFIED', { id, path: filePath(current) }); continue;
          }
          if (!repair && verified.file.state !== 'ABSENT') {
            counts.review++; report('VERIFY_CONFLICT', { id }); continue;
          }
        } else if (filePath(current)) { counts.existing++; report('EXISTING', { id, path: filePath(current) }); continue; }
        if (!current.canStore) { counts.review++; report('NO_ACTIVE_SAMPLING', { id }); continue; }
        if (previous && ['SUCCESS', 'UPLOAD_PENDING', 'UNCERTAIN', 'REVIEW', 'EXISTING'].includes(previous) && !recovering) {
          counts.review++; report('HISTORY_WITHOUT_DB_PATH', { id, previous }); continue;
        }
        if (recovering && !history?.sha256) {
          counts.review++; report('MISSING_PREVIOUS_HASH', { id }); continue;
        }
        if (dryRun) { counts.ready++; report(repair ? 'READY_TO_REPAIR_MISSING' : recovering ? 'READY_TO_RETRY' : 'READY', { id, ...(repair ? { path: repair.path } : {}) }); continue; }
        if (limit && attempts >= limit) break;
        if (attempts) await delay(pause);
        attempts++;
        console.log(`Загрузка №${attempts}: протокол ${act}, ID=${id}`);
        const bytes = await downloadPortalDocument(source);
        consecutiveAuthFailures = 0;
        const check = await existingRecord(id);
        if (repair) {
          if (filePath(check) !== repair.path) { counts.review++; report('RECOVERY_PATH_CHANGED', { id }); continue; }
        } else if (filePath(check)) { counts.existing++; report('EXISTING', { id, path: filePath(check) }); continue; }
        if (!check.canStore || createMatchKey(check.protocolNumber || '', check.protocolDate || '', check.testResult || '') !== matchKey) {
          counts.review++; report('RECORD_CHANGED', { id }); continue;
        }
        const sha256 = createHash('sha256').update(bytes).digest('hex');
        if (recovering && sha256 !== history?.sha256) {
          counts.review++; report('SOURCE_HASH_CHANGED', { id, sha256 }); continue;
        }
        attemptedHash = sha256;
        journal({ ...base, status: 'UPLOAD_PENDING', sha256 }); postStarted = true;
        const savedPath = await uploadDocument(id, check, bytes, repair);
        journal({ ...base, status: 'SUCCESS', path: savedPath, sha256 });
        counts.success++; report('SUCCESS', { id, path: savedPath, sha256 });
        console.log(`[ГОТОВО] ID=${id}: ${savedPath}`);
      } catch (error) {
        const code = error instanceof MigrationError ? error.code : '';
        const status = postStarted || ['UNCERTAIN', 'UPLOAD_PENDING'].includes(latest.get(key)?.status || '') ? 'UNCERTAIN' : 'FAILED';
        counts.failed++; report(status, { id, error: safeError(error) });
        if (!dryRun) journal({ ...base, status, error: safeError(error), sha256: attemptedHash ?? latest.get(key)?.sha256 });
        console.error(`[ОШИБКА] ID=${id}: ${safeError(error)}`);
        if (/^(NTLM_|PORTAL_AUTH_|PORTAL_HTTP_401|PORTAL_HTTP_403)/.test(code)) consecutiveAuthFailures++;
        else consecutiveAuthFailures = 0;
        if (error instanceof MigrationError && error.fatal) throw error;
        if (consecutiveAuthFailures >= 3) throw new MigrationError('AUTH_STOP', 'Три последовательных отказа авторизации портала.', true);
      }
    }
  } finally {
    credentials = undefined; fs.closeSync(lock); fs.unlinkSync(lockPath);
    console.log('Режим:', dryRun ? 'ПРОВЕРКА БЕЗ СКАЧИВАНИЯ' : 'ИМПОРТ');
    console.log('Итоги:', counts); console.log('Отчёт:', reportPath);
  }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error('Миграция остановлена:', safeError(error)); process.exitCode = 1; });
}
