/// <reference types="node" />
/**
 * Space sampling PDF/JPEG migration. Node.js 22+, existing packages: httpntlm, csv-parse.
 * Install at scripts/import-files/read-files.ts; run: npx tsx scripts/import-files/read-files.ts
 *
 * Defaults: ../../legacy-data/sampling.csv; import-stats.log beside this script.
 * Optional env: CSV_PATH, IMPORT_LOG, MIGRATION_STATE, SPACE_BASE_URL,
 * SPACE_UPLOAD_PATH, SPACE_LOGIN, SPACE_PASSWORD, PORTAL_LOGIN, PORTAL_PASSWORD,
 * PORTAL_DOMAIN (CORP), MAX_FILES (0 = all), MIGRATION_DELAY_MS (3000).
 * Additional old logs: LEGACY_LOG_FILES=/absolute/one.log,/absolute/two.log
 * Credentials are prompted once per process, not stored in logs/state.
 * Corporate CA: NODE_EXTRA_CA_CERTS=/absolute/company-ca.pem (PEM CA chain).
 *
 * Resume: append-only legacy log + migration-state.jsonl + live record detail.
 * Existing non-empty samplingDocumentPath is NEVER overwritten by this script.
 * A logged success with no current DB path, or an uncertain POST without a DB
 * path, is recorded for manual review. A new run does not blindly repeat it.
 * This is not atomic server-side idempotency: do not run parallel importers or
 * attach documents to these same records concurrently. The server must enforce
 * atomic no-overwrite/idempotency for that stronger guarantee.
 *
 * Dates: ISO and DD.MM.YYYY normalize to YYYY-MM-DD. Other matching text follows
 * the supplied script's normalization. Ambiguous DB matches are skipped.
 * PDF and JPEG are supported; deploy the matching upload endpoint first.
 * Log/DB checks do not prove that the referenced physical file is readable.
 * Do not delete logs to force retries: resolve REVIEW/UNCERTAIN records first.
 */
import * as fs from 'node:fs';
import * as path from 'node:path';
import process from 'node:process';
import * as readline from 'node:readline';
import { Writable } from 'node:stream';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { Agent, request as httpsRequest } from 'node:https';
import { createHash } from 'node:crypto';
import { parse } from 'csv-parse/sync';

const moduleRequire = createRequire(import.meta.url);
interface Credentials { username: string; password: string; domain: string; workstation: string }
interface NtlmApi {
  createType1Message(options: Credentials): string;
  parseType2Message(header: string): unknown;
  createType3Message(challenge: unknown, options: Credentials): string;
}
const ntlm = (moduleRequire('httpntlm') as { ntlm: NtlmApi }).ntlm;
const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const SPACE_ORIGIN = new URL(process.env.SPACE_BASE_URL || 'https://space.avtodor-eng.ru').origin;
const UPLOAD_PATH = process.env.SPACE_UPLOAD_PATH || '/api/lab/sampling-test/upload';
const CSV_PATH = path.resolve(process.env.CSV_PATH || path.join(scriptDir, '../../legacy-data/sampling.csv'));
const LOG_PATH = path.resolve(process.env.IMPORT_LOG || path.join(scriptDir, 'import-stats.log'));
const STATE_PATH = path.resolve(process.env.MIGRATION_STATE || path.join(scriptDir, 'migration-state.jsonl'));
const PORTAL_HOST = 'portal.avtodor-eng.ru';
const MAX_BYTES = 50 * 1024 * 1024;
const REQUEST_TIMEOUT = 120_000;
const MAX_REDIRECTS = 10;
const USER_AGENT = 'Space-Lab-Migration/2';
const delay = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));

class MigrationError extends Error {
  constructor(public code: string, message: string, public fatal = false) { super(message); }
}
function safeError(error: unknown): string {
  if (error instanceof MigrationError) return `${error.code}: ${error.message}`;
  // Never serialize HTTP request/options objects: they may contain credentials.
  if (error instanceof Error) return error.message.replace(/[\r\n]+/g, ' ').slice(0, 800);
  return 'Unknown error';
}
function envNumber(name: string, fallback: number): number {
  const value = Number(process.env[name] ?? fallback);
  if (!Number.isSafeInteger(value) || value < 0) throw new Error(`Некорректный ${name}`);
  return value;
}
async function askInput(label: string, secret = false): Promise<string> {
  if (!process.stdin.isTTY) throw new MigrationError('INPUT', 'Нет терминала: задайте учётные данные через окружение.', true);
  process.stdout.write(label);
  const output = secret ? new Writable({ write(_chunk, _encoding, done) { done(); } }) : process.stdout;
  const rl = readline.createInterface({ input: process.stdin, output, terminal: true });
  return new Promise((resolve, reject) => {
    let answered = false;
    rl.on('SIGINT', () => rl.close());
    rl.on('close', () => { if (secret) process.stdout.write('\n');
      if (!answered) reject(new MigrationError('INPUT_CANCELLED', 'Ввод отменён.', true)); });
    rl.question('', answer => { answered = true; rl.close(); resolve(answer); });
  });
}

// Separate jars: cookies never cross between Space and the old portal.
// Ports do not scope HTTP cookies; path/domain/expiry do.
export class CookieJar {
  private cookies = new Map<string, { name: string; value: string; domain: string;
    hostOnly: boolean; path: string; secure: boolean; expires: number }>();
  remember(url: URL, values: string[]): void {
    for (const raw of values) {
      const [pair = '', ...parts] = raw.split(';');
      const equals = pair.indexOf('=');
      if (equals < 1) continue;
      const attrs = new Map<string, string>(parts.map(part => {
        const i = part.indexOf('=');
        return i < 0 ? [part.trim().toLowerCase(), ''] : [part.slice(0, i).trim().toLowerCase(), part.slice(i + 1).trim()];
      }));
      const domain = (attrs.get('domain') || url.hostname).replace(/^\./, '').toLowerCase();
      if (url.hostname !== domain && !url.hostname.endsWith('.' + domain)) continue;
      // Only this portal host (or its parent domain) is needed; reject public suffix cookies.
      if (!domain.includes('.')) continue;
      const defaultPath = url.pathname.slice(0, url.pathname.lastIndexOf('/')) || '/';
      const cookiePath = attrs.get('path')?.startsWith('/') ? attrs.get('path')! : defaultPath;
      const name = pair.slice(0, equals).trim(), value = pair.slice(equals + 1).trim();
      let expires = Date.parse(attrs.get('expires') || '');
      if (!Number.isFinite(expires)) expires = Infinity;
      if (/^-?\d+$/.test(attrs.get('max-age') || '')) expires = Date.now() + Number(attrs.get('max-age')) * 1000;
      const key = `${domain}|${cookiePath}|${name}`;
      if (expires <= Date.now()) this.cookies.delete(key);
      else this.cookies.set(key, { name, value, domain, hostOnly: !attrs.has('domain'),
        path: cookiePath, secure: attrs.has('secure'), expires });
    }
  }
  header(url: URL): string {
    return [...this.cookies.values()].filter(c => c.expires > Date.now() &&
      (!c.secure || url.protocol === 'https:') &&
      (c.hostOnly ? url.hostname === c.domain : url.hostname === c.domain || url.hostname.endsWith('.' + c.domain)) &&
      (url.pathname === c.path || url.pathname.startsWith(c.path.endsWith('/') ? c.path : c.path + '/')))
      .sort((a, b) => b.path.length - a.path.length).map(c => `${c.name}=${c.value}`).join('; ');
  }
}
const spaceJar = new CookieJar(), portalJar = new CookieJar();
async function spaceFetch(endpoint: string, options: RequestInit = {}): Promise<Response> {
  const url = new URL(endpoint, SPACE_ORIGIN);
  if (url.protocol !== 'https:' || url.origin !== SPACE_ORIGIN || url.username || url.password)
    throw new MigrationError('SPACE_URL', 'Недопустимый адрес Space.', true);
  const headers = new Headers(options.headers);
  const cookie = spaceJar.header(url);
  if (cookie) headers.set('Cookie', cookie);
  const response = await fetch(url, { ...options, headers, redirect: 'manual', signal: AbortSignal.timeout(REQUEST_TIMEOUT) });
  spaceJar.remember(url, response.headers.getSetCookie());
  return response;
}
async function assertSpaceResponse(response: Response): Promise<void> {
  if (response.ok) return;
  let reason = '';
  try {
    const body = await response.clone().json() as Record<string, unknown>;
    reason = [body.statusMessage, body.message].filter(v => typeof v === 'string').join(' | ').slice(0, 500);
  } catch { reason = 'Ответ не JSON'; }
  throw new MigrationError(`SPACE_HTTP_${response.status}`,
    `${new URL(response.url).pathname}; ${reason}; WWW-Authenticate=${response.headers.get('www-authenticate') || 'нет'}`,
    [401, 403].includes(response.status) || response.status >= 300 && response.status < 400);
}
async function loginToSpace(): Promise<void> {
  const login = (process.env.SPACE_LOGIN || await askInput('Логин Space: ')).trim();
  let password = process.env.SPACE_PASSWORD || await askInput('Пароль Space: ', true);
  if (!login || !password) throw new MigrationError('SPACE_CREDENTIALS', 'Введите логин и пароль.', true);
  let response: Response;
  try { response = await spaceFetch('/api/auth/login', { method: 'POST',
    headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ login, password }) }); }
  finally { password = ''; }
  await assertSpaceResponse(response);
  const result = await response.json() as { success?: boolean };
  if (result.success !== true || !spaceJar.header(new URL('/api/lab/sampling-test/summary', SPACE_ORIGIN)))
    throw new MigrationError('SPACE_SESSION', 'Space не подтвердил вход или не выдал cookie для API.', true);
  console.log('Вход в Space выполнен.');
}
let credentials: Credentials | undefined;
async function portalCredentials(): Promise<Credentials> {
  if (credentials) return credentials;
  let login = (process.env.PORTAL_LOGIN || await askInput('Логин старого портала: ')).trim();
  const password = process.env.PORTAL_PASSWORD || await askInput('Пароль старого портала: ', true);
  let domain = process.env.PORTAL_DOMAIN || 'CORP';
  if (login.includes('\\')) { const i = login.indexOf('\\'); domain = login.slice(0, i); login = login.slice(i + 1); }
  if (!login || !password) throw new MigrationError('PORTAL_CREDENTIALS', 'Введите логин и пароль портала.', true);
  credentials = { username: login, password, domain, workstation: '' };
  return credentials;
}
export function portalUrl(value: string, base?: URL): URL {
  const url = new URL(value, base);
  if (url.protocol !== 'https:' || url.hostname !== PORTAL_HOST || !['', '443', '8891'].includes(url.port) || url.username || url.password)
    throw new MigrationError('PORTAL_URL', 'Перенаправление за пределы разрешённого портала запрещено.');
  return url;
}
interface PortalResponse { status: number; headers: Record<string, string | string[] | undefined>; body: Buffer }
function header(response: PortalResponse, name: string): string {
  const value = response.headers[name]; return Array.isArray(value) ? value.join(', ') : value || '';
}
// Explicit HTTPS requests let us collect cookies from BOTH NTLM handshake responses,
// keep Type 1/Type 3 on one socket and prohibit automatic cross-host redirects.
async function portalGet(url: URL, agent?: Agent, authorization?: string): Promise<PortalResponse> {
  portalUrl(url.href);
  return new Promise((resolve, reject) => {
    const headers: Record<string, string> = { 'User-Agent': USER_AGENT, Accept: 'application/pdf,image/jpeg,*/*' };
    const cookie = portalJar.header(url);
    if (cookie) headers.Cookie = cookie;
    if (authorization) { headers.Authorization = authorization; headers.Connection = 'keep-alive'; }
    const req = httpsRequest(url, { method: 'GET', headers, agent: agent || false }, res => {
      portalJar.remember(url, res.headers['set-cookie'] || []);
      const chunks: Buffer[] = []; let bytes = 0;
      res.on('data', (chunk: Buffer) => {
        bytes += chunk.length;
        if (bytes > MAX_BYTES) { req.destroy(new MigrationError('FILE_TOO_LARGE', 'Ответ портала больше 50 МиБ.')); return; }
        chunks.push(chunk);
      });
      res.on('error', reject);
      res.on('end', () => resolve({ status: res.statusCode || 0, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    const timer = setTimeout(() => req.destroy(new MigrationError('PORTAL_TIMEOUT', 'Таймаут запроса старого портала.')), REQUEST_TIMEOUT);
    req.on('close', () => clearTimeout(timer));
    req.on('error', reject);
    req.end();
  });
}
function detectDocument(bytes: Buffer): { extension: 'pdf' | 'jpg'; mime: string } | null {
  // Detect the bytes, never trust the filename or the remote Content-Type alone.
  if (bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return { extension: 'jpg', mime: 'image/jpeg' };
  }
  if (bytes.subarray(0, 1024).includes(Buffer.from('%PDF-'))) {
    return { extension: 'pdf', mime: 'application/pdf' };
  }
  return null;
}
function isDocument(response: PortalResponse): boolean {
  return response.status === 200 && !header(response, 'content-type').toLowerCase().includes('text/html') &&
    detectDocument(response.body) !== null;
}
function redirect(response: PortalResponse, url: URL): URL | null {
  if (![301, 302, 303, 307, 308].includes(response.status)) return null;
  const location = header(response, 'location');
  if (!location) throw new MigrationError('PORTAL_REDIRECT', 'Перенаправление без Location.');
  return portalUrl(location, url);
}
async function ntlmHandshake(url: URL): Promise<PortalResponse> {
  const auth = await portalCredentials();
  console.log(`[NTLM] Авторизация: ${url.origin}${url.pathname}`);
  const agent = new Agent({ keepAlive: true, maxSockets: 1 });
  try {
    const first = await portalGet(url, agent, ntlm.createType1Message(auth));
    const challenge = header(first, 'www-authenticate').match(/(?:^|,\s*)NTLM\s+([A-Za-z0-9+/=]+)/i);
    if (!challenge) {
      if (first.status === 200 || redirect(first, url)) return first;
      throw new MigrationError('NTLM_CHALLENGE', `Не получен NTLM challenge, HTTP ${first.status}.`);
    }
    // Give the Agent a chance to release the fully consumed response socket.
    await new Promise<void>(resolve => setImmediate(resolve));
    const type2 = ntlm.parseType2Message('NTLM ' + challenge[1]);
    const final = await portalGet(url, agent, ntlm.createType3Message(type2, auth));
    console.log(`[NTLM] Итоговый HTTP ${final.status}. Проверяем скачивание документа.`);
    if (final.status === 401 || final.status === 403)
      throw new MigrationError('NTLM_DENIED', `Портал отклонил NTLM-вход: HTTP ${final.status}.`);
    return final;
  } finally { agent.destroy(); }
}

// The original URL never changes. Only one handshake and one restart from the
// original URL are allowed per document (no recursive restart at :8891).
export async function downloadPortalDocument(original: string,
  get: (url: URL) => Promise<PortalResponse> = portalGet,
  handshake: (url: URL) => Promise<PortalResponse> = ntlmHandshake): Promise<Buffer> {
  const originalUrl = portalUrl(original);
  let current = originalUrl, authenticated = false, restarted = false;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    let response = await get(current);
    if (isDocument(response)) return response.body;
    const needsAuth = response.status === 401 && /\bNTLM\b/i.test(header(response, 'www-authenticate'));
    if (needsAuth) {
      if (authenticated) throw new MigrationError('PORTAL_AUTH_REPEAT', 'После NTLM портал снова требует вход. Документ пропущен.');
      authenticated = true;
      response = await handshake(current);
      if (isDocument(response)) return response.body;
    }
    const next = redirect(response, current);
    if (next) { current = next; continue; }
    if (authenticated && response.status === 200 && !restarted) {
      restarted = true; current = originalUrl; continue;
    }
    throw new MigrationError(`PORTAL_HTTP_${response.status}`,
      `Документ не получен: ${current.origin}${current.pathname}; Content-Type=${header(response, 'content-type') || 'нет'}`);
  }
  throw new MigrationError('PORTAL_REDIRECT_LIMIT', 'Превышен предел перенаправлений. Документ пропущен.');
}

export function createMatchKey(act: string, date: string, object: string, location: string): string {
  const normalize = (value: string) => String(value || '').toLowerCase().replace(/ё/g, 'е')
    .replace(/[№#%?®©™"'«»‘’„“]/g, '').replace(/[–—_]/g, '-')
    .replace(/[^a-zа-я0-9\-,]|\s/g, '').trim();
  const iso = date.trim().match(/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/);
  const local = date.trim().match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  const normalizedDate = iso ? `${iso[1]}-${iso[2]}-${iso[3]}` : local ? `${local[3]}-${local[2]}-${local[1]}` : date;
  return [act, normalizedDate, object, location].map(normalize).join('||');
}
export function sourceIdentity(value: string): string {
  const url = portalUrl(value);
  const keys = ['list_id', 'element_id', 'field_id', 'file_id'];
  if (keys.every(key => url.searchParams.has(key)))
    return [url.hostname, ...keys.map(key => `${key}=${url.searchParams.get(key)}`)].join('|');
  url.hash = ''; url.searchParams.sort(); return url.href;
}
function jobKey(id: number, source: string): string { return `${SPACE_ORIGIN}|sampling|${id}|${sourceIdentity(source)}`; }
interface RecordRow { id: number; samplingActNumber: string; samplingDate: string; objectName: string; samplingPlace: string }
interface CsvRow { [key: string]: string }
interface JournalRow { at: string; key: string; status: string; id: number; source: string; act: string; path?: string; error?: string; sha256?: string }
const latest = new Map<string, JournalRow>();
const legacySuccess = new Set<string>();

export function parseLegacySuccess(text: string): Array<{ id: number; url: string }> {
  const result: Array<{ id: number; url: string }> = [];
  for (const block of text.split(/^-{5,}\s*$/m)) {
    if (!/^RESULT:\s*PROXY_MIGRATION_SUCCESS\s*$/m.test(block)) continue;
    const id = Number(block.match(/^DB_ID:\s*(\d+)\s*$/m)?.[1]);
    const url = block.match(/^URL:\s*(\S+)\s*$/m)?.[1];
    if (id > 0 && url) result.push({ id, url });
  }
  return result;
}
function loadJournals(): void {
  if (fs.existsSync(STATE_PATH)) {
    const lines = fs.readFileSync(STATE_PATH, 'utf8').split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]!.trim(); if (!line) continue;
      try {
        const row = JSON.parse(line) as JournalRow;
        if (typeof row.key !== 'string' || typeof row.status !== 'string') throw new Error('schema');
        latest.set(row.key, row);
      } catch {
        throw new MigrationError('JOURNAL_INVALID', `Повреждён журнал ${STATE_PATH}, строка ${i + 1}. Сохраните копию и проверьте запись; автоматический повтор загрузок остановлен.`, true);
      }
    }
  }
  const logs = new Set([LOG_PATH, ...(process.env.LEGACY_LOG_FILES || '').split(',').filter(Boolean)]);
  for (const file of logs) {
    if (!fs.existsSync(file)) continue;
    for (const row of parseLegacySuccess(fs.readFileSync(file, 'utf8'))) {
      try { legacySuccess.add(jobKey(row.id, row.url)); } catch { /* Unrelated log URL is ignored. */ }
    }
  }
  console.log(`История: ${latest.size} записей состояния; ${legacySuccess.size} успешных загрузок старого журнала.`);
}
function durableAppend(file: string, text: string): void {
  const fd = fs.openSync(file, 'a', 0o600);
  try { fs.writeFileSync(fd, text); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
}
function journal(row: Omit<JournalRow, 'at'>): void {
  const entry: JournalRow = { ...row, at: new Date().toISOString() };
  // Persist structured state first; if the text log fails, restart still sees this result.
  durableAppend(STATE_PATH, JSON.stringify(entry) + '\n'); latest.set(row.key, entry);
  const result = row.status === 'SUCCESS' ? 'PROXY_MIGRATION_SUCCESS' : row.status;
  durableAppend(LOG_PATH, [`TIMESTAMP: ${entry.at}`, `ACT_NUMBER: ${row.act.replace(/[\r\n]/g, ' ')}`,
    `DB_ID: ${row.id}`, `RESULT: ${result}`, `URL: ${row.source}`, `SPACE_ORIGIN: ${SPACE_ORIGIN}`,
    row.path ? `PATH: ${row.path}` : '', row.error ? `ERROR_MESSAGE: ${row.error.replace(/[\r\n]/g, ' ')}` : '',
    '----------------------------------------\n'].filter(Boolean).join('\n'));
}
async function loadRecords(): Promise<Map<string, RecordRow[]>> {
  const cache = new Map<string, RecordRow[]>(), ids = new Set<number>();
  for (let page = 1; ; page++) {
    const response = await spaceFetch(`/api/lab/sampling-test/summary?page=${page}&pageSize=500&sortKey=id&sortOrder=asc`);
    await assertSpaceResponse(response);
    const result = await response.json() as { data?: RecordRow[] };
    if (!Array.isArray(result.data)) throw new MigrationError('SPACE_DATA', 'Некорректный ответ summary.', true);
    for (const row of result.data) {
      if (!Number.isSafeInteger(row.id) || row.id <= 0 || ids.has(row.id))
        throw new MigrationError('SPACE_PAGING', 'Некорректные/повторные ID при чтении страниц.', true);
      ids.add(row.id);
      const key = createMatchKey(row.samplingActNumber, row.samplingDate, row.objectName, row.samplingPlace);
      const matches = cache.get(key) || []; matches.push(row); cache.set(key, matches);
    }
    console.log(`Прочитано записей Space: ${ids.size}`);
    if (result.data.length < 500) return cache;
  }
}
async function existingPath(id: number): Promise<string | null> {
  const response = await spaceFetch(`/api/lab/sampling-test/${id}`);
  await assertSpaceResponse(response);
  const body = await response.json() as { success?: boolean; data?: { id?: number; samplingDocumentPath?: unknown; deletedAt?: unknown } };
  if (body.success !== true || body.data?.id !== id || !Object.hasOwn(body.data, 'samplingDocumentPath'))
    throw new MigrationError('SPACE_DETAIL', `Нельзя проверить файл записи ID=${id}. Загрузка остановлена.`, true);
  if (body.data.deletedAt) throw new MigrationError('DELETED_RECORD', `Запись ID=${id} удалена.`);
  const value = body.data.samplingDocumentPath;
  if (value !== null && typeof value !== 'string') throw new MigrationError('SPACE_DETAIL', 'Некорректный тип пути файла.', true);
  return typeof value === 'string' && value.trim() && value.trim() !== '-' ? value : null;
}
async function uploadDocument(id: number, act: string, bytes: Buffer): Promise<string> {
  const form = new FormData();
  const document = detectDocument(bytes);
  if (!document) throw new MigrationError('UNSUPPORTED_DOCUMENT', 'Ожидается PDF или JPEG.');
  form.append('file', new Blob([new Uint8Array(bytes)], { type: document.mime }), `act_${id}.${document.extension}`);
  form.append('dbRecordId', String(id)); form.append('samplingTestId', String(id)); form.append('actNumber', act);
  const response = await spaceFetch(UPLOAD_PATH, { method: 'POST', body: form });
  await assertSpaceResponse(response);
  const result = await response.json() as { success?: boolean; attached?: boolean; samplingTestId?: number; path?: string };
  if (result.success !== true || result.attached === false || !result.path ||
    result.samplingTestId !== undefined && result.samplingTestId !== id)
    throw new MigrationError('UPLOAD_UNCONFIRMED', 'Space не подтвердил привязку файла. Требуется проверка.');
  return result.path;
}

export async function main(): Promise<void> {
  const limit = envNumber('MAX_FILES', 0), pause = envNumber('MIGRATION_DELAY_MS', 3000);
  for (const file of [LOG_PATH, STATE_PATH]) fs.mkdirSync(path.dirname(file), { recursive: true });
  const lockPath = STATE_PATH + '.lock';
  let lock: number;
  try { lock = fs.openSync(lockPath, 'wx', 0o600); }
  catch { throw new MigrationError('LOCK', `Уже есть ${lockPath}. Если прошлый процесс аварийно завершился, убедитесь, что он не работает, и удалите только .lock.`, true); }
  fs.writeFileSync(lock, JSON.stringify({ pid: process.pid, at: new Date().toISOString() }));
  const counts = { success: 0, existing: 0, review: 0, failed: 0, unmatched: 0, ambiguous: 0, missing: 0 };
  try {
    loadJournals();
    const rows = parse(fs.readFileSync(CSV_PATH), { bom: true, delimiter: ';', columns: (names: string[]) => names.map(n => n.trim()), skip_empty_lines: true }) as CsvRow[];
    const required = ['Номер акта отбора проб', 'Дата отбора проб', 'Наименование объекта', 'Место отбора проб', 'Ссылка'];
    if (!rows.length || required.some(name => !Object.hasOwn(rows[0]!, name))) throw new Error('В CSV отсутствуют обязательные столбцы или данные.');
    await loginToSpace();
    const cache = await loadRecords();
    // One DB field holds one document: do not silently select the first of several sources.
    const sourcesById = new Map<number, Set<string>>();
    for (const row of rows) {
      const values = ['Номер акта отбора проб', 'Дата отбора проб', 'Наименование объекта', 'Место отбора проб'].map(name => (row[name] || '').trim());
      const source = (row['Ссылка'] || '').trim();
      if (!source || values.some(value => !value)) continue;
      const matches = cache.get(createMatchKey(values[0]!, values[1]!, values[2]!, values[3]!));
      if (matches?.length !== 1) continue;
      const id = matches[0]!.id;
      try {
        const sources = sourcesById.get(id) || new Set<string>();
        sources.add(jobKey(id, source)); sourcesById.set(id, sources);
      } catch { /* Main loop reports malformed URLs. */ }
    }
    let attempts = 0, consecutiveAuthFailures = 0;
    for (const row of rows) {
      const act = (row['Номер акта отбора проб'] || '').trim(), source = (row['Ссылка'] || '').trim();
      const values = [act, row['Дата отбора проб'] || '', row['Наименование объекта'] || '', row['Место отбора проб'] || ''];
      if (values.some(v => !v.trim()) || !source) { counts.missing++; continue; }
      const matches = cache.get(createMatchKey(values[0]!, values[1]!, values[2]!, values[3]!)) || [];
      if (!matches.length) { counts.unmatched++; continue; }
      if (matches.length !== 1) { counts.ambiguous++; continue; }
      const id = matches[0]!.id;
      let key: string;
      try { key = jobKey(id, source); } catch (error) { counts.failed++; console.error(`ID=${id}: ${safeError(error)}`); continue; }
      const base = { key, id, source, act };
      if ((sourcesById.get(id)?.size || 0) > 1) {
        counts.review++;
        console.warn(`[ПРОВЕРИТЬ] ID=${id}: несколько разных исходных документов для одной записи.`);
        if (!latest.has(key) || latest.get(key)?.status === 'FAILED') {
          journal({ ...base, status: 'REVIEW', error: 'MULTIPLE_SOURCE_DOCUMENTS: несколько разных ссылок для одной записи; требуется ручная проверка.' });
        }
        continue;
      }
      // Do not clear success/pending history by writing ordinary skip events over it.
      let postStarted = false;
      try {
        const currentPath = await existingPath(id);
        if (currentPath) {
          counts.existing++; console.log(`[ПРОПУСК] ID=${id}: в Space уже есть документ.`);
          if (!latest.has(key)) journal({ ...base, status: 'EXISTING', path: currentPath });
          continue;
        }
        const status = latest.get(key)?.status;
        if (legacySuccess.has(key) || status && ['SUCCESS', 'UPLOAD_PENDING', 'UNCERTAIN', 'REVIEW', 'EXISTING'].includes(status)) {
          counts.review++; console.warn(`[ПРОВЕРИТЬ] ID=${id}: история загрузки есть, но в БД нет пути. Автоматический повтор запрещён.`);
          journal({ ...base, status: 'REVIEW', error: 'История загрузки есть, путь в Space отсутствует.' }); continue;
        }
        if (limit && attempts >= limit) break;
        if (attempts) await delay(pause);
        attempts++;
        console.log(`\nЗагрузка №${attempts}: акт ${act}, ID=${id}`);
        const bytes = await downloadPortalDocument(source);
        consecutiveAuthFailures = 0;
        // Check again after a long portal login/download, before starting a write.
        const newPath = await existingPath(id);
        if (newPath) { counts.existing++; journal({ ...base, status: 'EXISTING', path: newPath }); continue; }
        journal({ ...base, status: 'UPLOAD_PENDING', sha256: createHash('sha256').update(bytes).digest('hex') });
        postStarted = true;
        const savedPath = await uploadDocument(id, act, bytes);
        journal({ ...base, status: 'SUCCESS', path: savedPath, sha256: createHash('sha256').update(bytes).digest('hex') });
        counts.success++; console.log(`[ГОТОВО] ID=${id}: ${savedPath}`);
      } catch (error) {
        // Once a POST has started, a lost response may mean the write succeeded.
        // Never retry that POST automatically: a later run checks the DB first.
        const code = error instanceof MigrationError ? error.code : '';
        counts.failed++;
        journal({ ...base, status: postStarted ? 'UNCERTAIN' : 'FAILED', error: safeError(error) });
        console.error(`[ОШИБКА] ID=${id}: ${safeError(error)}`);
        if (/^(NTLM_|PORTAL_AUTH_|PORTAL_HTTP_401|PORTAL_HTTP_403)/.test(code)) consecutiveAuthFailures++;
        else consecutiveAuthFailures = 0;
        if (error instanceof MigrationError && error.fatal) throw error;
        if (consecutiveAuthFailures >= 3) throw new MigrationError('AUTH_STOP', 'Три последовательных отказа авторизации портала. Проверьте учётную запись и доступ.', true);
      }
    }
  } finally {
    credentials = undefined;
    fs.closeSync(lock); fs.unlinkSync(lockPath);
    console.log('Итоги:', counts);
  }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error('Миграция остановлена:', safeError(error)); process.exitCode = 1; });
}
