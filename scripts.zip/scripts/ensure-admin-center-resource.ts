// scripts/ensure-admin-center-resource.ts

import {
  AccessAction,
  AccessResourceType,
  PrismaClient,
} from '@prisma/client'


const prisma =
  new PrismaClient()


const RESOURCE_KEY =
  'admin.center'


function readGrantLogin():
  string | null {
  const prefix =
    '--grant-login='

  const value =
    process.argv.find(
      arg =>
        arg.startsWith(
          prefix,
        ),
    )

  if (!value) {
    return null
  }

  return (
    value
      .slice(
        prefix.length,
      )
      .trim() ||
    null
  )
}


async function main() {
  const resource =
    await prisma
      .accessResource
      .upsert({
        where: {
          key:
            RESOURCE_KEY,
        },

        update: {
          name:
            'AdminCenter',

          description:
            'Корневой доступ к административному центру Space.',

          type:
            AccessResourceType.SECTION,

          isActive:
            true,
        },

        create: {
          key:
            RESOURCE_KEY,

          name:
            'AdminCenter',

          description:
            'Корневой доступ к административному центру Space.',

          type:
            AccessResourceType.SECTION,

          isActive:
            true,

          sortOrder:
            990,
        },
      })


  console.log(
    `✅ SECTION-ресурс готов: ${RESOURCE_KEY}`,
  )


  const login =
    readGrantLogin()


  if (!login) {
    console.log(
      'ℹ️ VIEW никому не выдавался.',
    )

    return
  }


  const user =
    await prisma.user
      .findUnique({
        where: {
          login,
        },

        select: {
          id:
            true,

          login:
            true,
        },
      })


  if (!user) {
    throw new Error(
      `Пользователь "${login}" не найден в app_users`,
    )
  }


  await prisma.userPermission
    .upsert({
      where: {
        userId_resourceId_action: {
          userId:
            user.id,

          resourceId:
            resource.id,

          action:
            AccessAction.VIEW,
        },
      },

      update: {
        grantedByLogin:
          'bootstrap-script',
      },

      create: {
        userId:
          user.id,

        resourceId:
          resource.id,

        action:
          AccessAction.VIEW,

        grantedByLogin:
          'bootstrap-script',
      },
    })


  console.log(
    `✅ VIEW выдан пользователю ${user.login}`,
  )
}


main()
  .catch(
    error => {
      console.error(
        '❌ Ошибка:',
        error,
      )

      process.exitCode =
        1
    },
  )
  .finally(
    async () => {
      await prisma.$disconnect()
    },
  )
