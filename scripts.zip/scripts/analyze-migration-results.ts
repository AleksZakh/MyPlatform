// scripts/analyze-migration-results.ts
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function analyzeMigrationResults() {
  console.log('🔍 Анализ результатов миграции...\n');

  try {
    // 1. Проверяем, сколько записей в старой таблице
    const totalAEng = await prisma.aEng.count();
    console.log(`📊 Всего записей в AEng: ${totalAEng}`);

    // 2. Проверяем, сколько записей с производителем
    const withManufacturer = await prisma.aEng.count({
      where: {
        manufacturer: {
          not: null
        }
      }
    });
    console.log(`📊 Записей с указанным производителем: ${withManufacturer}`);
    console.log(`📊 Записей БЕЗ производителя: ${totalAEng - withManufacturer}`);

    // 3. Анализируем дубликаты производителей с разными материалами
    // ИСПРАВЛЕНО: используем правильные имена колонок (camelCase)
    const manufacturerMaterialConflicts = await prisma.$queryRaw`
      WITH conflicts AS (
        SELECT 
          manufacturer,
          COUNT(DISTINCT "materialName") as material_count,
          ARRAY_AGG(DISTINCT "materialName") as materials
        FROM "aeng"
        WHERE manufacturer IS NOT NULL AND manufacturer != ''
        GROUP BY manufacturer
        HAVING COUNT(DISTINCT "materialName") > 1
      )
      SELECT * FROM conflicts
      ORDER BY material_count DESC
      LIMIT 20
    `;

    console.log('\n⚠️ Конфликты "производитель → несколько материалов":');
    console.log('(первые 20 записей)');
    console.table(manufacturerMaterialConflicts);

    // 4. Считаем, сколько записей могло быть пропущено из-за конфликтов
    const conflictRecords = await prisma.$queryRaw`
      SELECT COUNT(*) as conflict_count
      FROM "aeng" a1
      WHERE EXISTS (
        SELECT 1 
        FROM "aeng" a2 
        WHERE a2.manufacturer = a1.manufacturer 
          AND a2."materialName" != a1."materialName"
          AND a2.id < a1.id
      )
      AND a1.manufacturer IS NOT NULL 
      AND a1.manufacturer != ''
    `;

    console.log(`\n📊 Записей, которые могли быть пропущены из-за конфликтов: ${Number(conflictRecords[0].conflict_count)}`);

    // 5. Проверяем, сколько записей без номера акта
    const noActNumber = await prisma.aEng.count({
      where: {
        samplingActNumber: {
          equals: ''
        }
      }
    });
    console.log(`📊 Записей без номера акта: ${noActNumber}`);

    // 6. Проверяем, сколько записей без материала
    const noMaterial = await prisma.aEng.count({
      where: {
        materialName: {
          equals: ''
        }
      }
    });
    console.log(`📊 Записей без названия материала: ${noMaterial}`);

    // 7. Анализируем, сколько уникальных пар (производитель, материал)
    const uniquePairs = await prisma.$queryRaw`
      SELECT COUNT(DISTINCT CONCAT(manufacturer, '|', "materialName")) as unique_pairs
      FROM "aeng"
      WHERE manufacturer IS NOT NULL AND manufacturer != ''
        AND "materialName" IS NOT NULL AND "materialName" != ''
    `;
    console.log(`📊 Уникальных пар (производитель|материал): ${Number(uniquePairs[0].unique_pairs)}`);

    // 8. Проверяем производителей, которые есть в новой таблице
    const manufacturersInNew = await prisma.manufacturer.count();
    console.log(`📊 Производителей в новой таблице: ${manufacturersInNew}`);

    // 9. Проверяем, сколько протоколов создано
    const protocolsInNew = await prisma.testProtocol.count();
    console.log(`📊 Протоколов в новой таблице: ${protocolsInNew}`);

    // 10. Проверяем, сколько актов создано
    const actsInNew = await prisma.samplingAct.count();
    console.log(`📊 Актов отбора в новой таблице: ${actsInNew}`);

    // 11. Вычисляем, сколько записей было создано на основе уникальных пар
    const uniquePairsCount = Number(uniquePairs[0].unique_pairs);
    const expectedProtocols = Math.min(
      withManufacturer, // только записи с производителем
      uniquePairsCount // только уникальные пары
    );

    console.log(`\n📊 Ожидаемое количество протоколов (при уникальных парах): ${expectedProtocols}`);
    console.log(`📊 Фактическое количество протоколов: ${protocolsInNew}`);
    console.log(`📊 Разница: ${expectedProtocols - protocolsInNew}`);

    // 12. Дополнительный анализ: проверяем, какие производители чаще всего конфликтуют
    const topConflicts = await prisma.$queryRaw`
      SELECT 
        manufacturer,
        COUNT(DISTINCT "materialName") as material_count,
        COUNT(*) as total_records
      FROM "aeng"
      WHERE manufacturer IS NOT NULL AND manufacturer != ''
      GROUP BY manufacturer
      HAVING COUNT(DISTINCT "materialName") > 1
      ORDER BY COUNT(DISTINCT "materialName") DESC
      LIMIT 10
    `;

    console.log('\n🏆 ТОП-10 производителей с наибольшим количеством конфликтов:');
    console.table(topConflicts);

    // 13. Проверяем, сколько записей с одинаковым номером акта в старой таблице
    const duplicateActs = await prisma.$queryRaw`
      SELECT 
        "samplingActNumber",
        COUNT(*) as record_count,
        COUNT(DISTINCT "materialName") as material_count
      FROM "aeng"
      GROUP BY "samplingActNumber"
      HAVING COUNT(*) > 1
      ORDER BY COUNT(*) DESC
      LIMIT 10
    `;

    console.log('\n📋 ТОП-10 актов с наибольшим количеством материалов:');
    console.table(duplicateActs);

    // 14. Проверяем, есть ли записи без номера акта
    const recordsWithoutAct = await prisma.aEng.count({
      where: {
        samplingActNumber: {
          equals: ''
        }
      }
    });
    console.log(`\n📊 Записей без номера акта: ${recordsWithoutAct}`);

    // 15. Проверяем распределение протоколов по актам
    const actDistribution = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as act_count,
        protocols_per_act
      FROM (
        SELECT 
          "samplingActId",
          COUNT(*) as protocols_per_act
        FROM "test_protocols"
        GROUP BY "samplingActId"
      ) subquery
      GROUP BY protocols_per_act
      ORDER BY protocols_per_act
    `;

    console.log('\n📊 Распределение протоколов по актам:');
    console.table(actDistribution);

  } catch (error) {
    console.error('❌ Ошибка при анализе:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

analyzeMigrationResults()
  .catch((error) => {
    console.error('❌ Ошибка:', error);
    process.exit(1);
  });