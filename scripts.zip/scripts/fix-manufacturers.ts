// scripts/fix-manufacturers.ts
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Расширенный словарь нормализации
const manufacturerNormalization: Record<string, string> = {
  'ООО СУ910': 'ООО "СУ-910"',
  'ООО СУ 910': 'ООО "СУ-910"',
  'ООО СУ-910': 'ООО "СУ-910"',
  'ООО "СУ910"': 'ООО "СУ-910"',
  'ООО "СУ 910"': 'ООО "СУ-910"',
  'ООО "СУ-910"': 'ООО "СУ-910"',
  'ООО СУ 910 ': 'ООО "СУ-910"',
  'ООО Строительное управление №910': 'ООО "СУ-910"',
  'Строительное управление №910': 'ООО "СУ-910"',
  
  'ООО СУ№926': 'ООО "СУ-926"',
  'ООО СУ №926': 'ООО "СУ-926"',
  'ООО "СУ№926"': 'ООО "СУ-926"',
  'ООО "СУ №926"': 'ООО "СУ-926"',
  'ООО СУ-926': 'ООО "СУ-926"',
  
  'ООО Трансстроймеханизация': 'ООО "Трансстроймеханизация"',
  'ООО "Трансстроймеханизация"': 'ООО "Трансстроймеханизация"',
  
  'АО Донаэродорстрой': 'АО "Донаэродорстрой"',
  'АО "Донаэродорстрой"': 'АО "Донаэродорстрой"',
  'АО ДОНАЭРОДОРСТРОЙ': 'АО "Донаэродорстрой"',
  
  'ООО СКАвтодор': 'ООО СК "Автодор"',
  'ООО СК-Автодор': 'ООО СК "Автодор"',
  'ООО "СКАвтодор"': 'ООО СК "Автодор"',
  'ООО "СК-Автодор"': 'ООО СК "Автодор"',
  
  'ООО СУ905': 'ООО "СУ-905"',
  'ООО СУ 905': 'ООО "СУ-905"',
  'ООО СУ-905': 'ООО "СУ-905"',
  'ООО "СУ905"': 'ООО "СУ-905"',
  'ООО "СУ 905"': 'ООО "СУ-905"',
  'ООО "СУ-905"': 'ООО "СУ-905"',
  
  'ООО ТЕХАЛЬЯНС': 'ООО "ТехАльянс"',
  'ООО ТехАльянс': 'ООО "ТехАльянс"',
  'ООО "ТЕХАЛЬЯНС"': 'ООО "ТехАльянс"',
  
  'ООО А-МОСТ': 'ООО "А-Мост"',
  'ООО "А-МОСТ"': 'ООО "А-Мост"',
  'ООО А-Мост': 'ООО "А-Мост"',
  
  'ООО ДИК/ ООО Динскойавтодор': 'ООО "Динскойавтодор"',
  'ООО Динскойавтодор': 'ООО "Динскойавтодор"',
  'ООО "Динскойавтодор"': 'ООО "Динскойавтодор"',
  
  // НОВЫЕ ПРОИЗВОДИТЕЛИ ИЗ CSV
  'ООО ТехСтройКонтракт': 'ООО "ТехСтройКонтракт"',
  'ООО ДРСУ Магистраль': 'ООО ДРСУ "Магистраль"',
  'к-p Спас-Загорье': 'Карьер "Спас-Загорье"',
  'Карьер Спас-Загорье': 'Карьер "Спас-Загорье"',
  'ООО ТСМ ПРОМБАЗА': 'ООО ТСМ "ПРОМБАЗА"',
  'ООО Штарком': 'ООО "Штарком"',
  'ООО ЗАРЯ БЕТОН': 'ООО "ЗАРЯ БЕТОН"',
  'ООО БизнесТрансСтрой': 'ООО "БизнесТрансСтрой"',
  'ООО ЗемДорСтрой': 'ООО "ЗемДорСтрой"',
  'ООО АБЗ Капотня': 'ООО АБЗ "Капотня"',
  'ООО "Карьер-Инвест"': 'ООО "Карьер-Инвест"',
  'ООО ?А-МОСТ?': 'ООО "А-Мост"',
  'ООО ?ТВОЙ БЕТОН?': 'ООО "Твой Бетон"',
  'ООО ДРСУ ?МАГИСТРАЛЬ?': 'ООО ДРСУ "Магистраль"',
  'АО Дороги и Мосты Мостоотряд-10': 'АО "Дороги и Мосты Мостоотряд-10"',
  'АО Дороги и Мосты Мостоотряд-1': 'АО "Дороги и Мосты Мостоотряд-1"',
};

function normalizeManufacturer(name: string): string {
  if (!name) return 'Не указан';
  const trimmed = name.trim().replace(/\s+/g, ' ');
  return manufacturerNormalization[trimmed] || trimmed;
}

async function fixManufacturers() {
  console.log('🔧 ИСПРАВЛЕНИЕ ПРОИЗВОДИТЕЛЕЙ В МАТЕРИАЛАХ\n');

  // Получаем все материалы, у которых нет производителя
  const materialsWithoutManufacturer = await prisma.material.findMany({
    where: {
      manufacturerId: null
    },
    include: {
      receipts: {
        take: 1,
        include: {
          testProtocols: {
            take: 1,
            include: {
              samplingTests: {
                take: 1,
                include: {
                  testProtocol: {
                    include: {
                      receiptMaterial: {
                        include: {
                          material: true
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  });

  console.log(`📊 Найдено материалов без производителя: ${materialsWithoutManufacturer.length}`);

  let updated = 0;
  let skipped = 0;

  for (const material of materialsWithoutManufacturer) {
    try {
      // Ищем соответствующую запись в AEng
      const aengRecord = await prisma.aEng.findFirst({
        where: {
          materialName: material.name
        }
      });

      if (!aengRecord || !aengRecord.manufacturer) {
        skipped++;
        continue;
      }

      const normalizedName = normalizeManufacturer(aengRecord.manufacturer);

      // Находим или создаем производителя
      let manufacturer = await prisma.manufacturer.findUnique({
        where: { name: normalizedName }
      });

      if (!manufacturer) {
        manufacturer = await prisma.manufacturer.create({
          data: {
            name: normalizedName,
            note: `Создан автоматически при исправлении. Исходное название: "${aengRecord.manufacturer}"`,
            authorEmail: 'fix-script@system',
            createdAt: new Date()
          }
        });
        console.log(`✅ Создан новый производитель: "${normalizedName}"`);
      }

      // Обновляем материал
      await prisma.material.update({
        where: { id: material.id },
        data: {
          manufacturerId: manufacturer.id,
          editorEmail: 'fix-script@system',
          editedAt: new Date()
        }
      });

      updated++;
      console.log(`✅ Обновлен материал: "${material.name}" → производитель: "${normalizedName}"`);

    } catch (error) {
      console.error(`❌ Ошибка при обработке материала ID: ${material.id}`, error);
    }
  }

  console.log(`\n📊 ИТОГИ:`);
  console.log(`   ✅ Обновлено материалов: ${updated}`);
  console.log(`   ⏭️ Пропущено (нет данных о производителе): ${skipped}`);
}

fixManufacturers()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });