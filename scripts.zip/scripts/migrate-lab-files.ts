/** Run with npx tsx scripts/migrate-lab-files.ts plan|apply|rollback|recover */
import 'dotenv/config'
import { mkdir, lstat, readFile, writeFile, readdir, unlink } from 'node:fs/promises'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { prisma } from '../server/utils/prisma'
import { fileReferences } from '../server/services/storage/references'
import { checkedStoragePath, normalizeStoragePath, storageJournalRoot } from '../server/services/storage/paths'
import { executeChanges, recoverStorageOperations, withStorageLock } from '../server/services/storage/operations'

const identity = (refs: any[]) => refs.map(r => `${r.model}:${r.id}:${r.field}`).sort().join('|')
const command = process.argv[2] || 'plan'
const planFile = path.resolve(process.argv[3] || 'lab-files-plan.json')
async function exists(relative: string) { try { const p = await checkedStoragePath(relative); if (!(await lstat(p)).isFile()) throw new Error('NOT_FILE'); return true } catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false; throw error } }
async function hash(relative: string) { return createHash('sha256').update(await readFile(await checkedStoragePath(relative))).digest('hex') }
async function ensureParent(relative: string) {
  let parent = ''
  for (const part of path.posix.dirname(relative).split('/')) {
    parent = [parent, part].filter(Boolean).join('/')
    const disk = await checkedStoragePath(parent, true)
    await mkdir(disk).catch(error => { if (error.code !== 'EEXIST') throw error })
  }
}
try {
  if (command === 'plan') {
    const refs = await fileReferences(), paths = new Map<string, typeof refs>()
    for (const ref of refs) {
      const source = normalizeStoragePath(ref.path)
      if (source.startsWith('lab/')) continue
      paths.set(source, [...(paths.get(source) || []), ref])
    }
    const items = []
    for (const [source, references] of paths) {
      const target = 'lab/' + source
      const present = await exists(source)
      items.push({ source, target, references, sha256: present ? await hash(source) : null, missing: !present, conflict: await exists(target) })
    }
    await writeFile(planFile, JSON.stringify({ createdAt: new Date().toISOString(), items }, null, 2), { flag: 'wx', mode: 0o600 })
    console.log(`Plan: ${planFile}; files=${items.length}; missing=${items.filter(x=>x.missing).length}; conflicts=${items.filter(x=>x.conflict).length}`)
  } else if (command === 'apply') {
    if (process.env.STORAGE_MAINTENANCE !== '1') throw new Error('Stop Space, imports and all storage writers; set STORAGE_MAINTENANCE=1')
    const plan = JSON.parse(await readFile(planFile, 'utf8'))
    if (plan.items.some((x: any) => x.missing || x.conflict)) throw new Error('Resolve missing files and conflicts, then create a new plan')
    await withStorageLock(async () => {
      await recoverStorageOperations()
      for (const item of plan.items) {
        const current = await fileReferences(prisma, [item.source, item.target])
        const sourceRefs = current.filter(r => normalizeStoragePath(r.path) === item.source)
        if (!sourceRefs.length && identity(current.filter(r => normalizeStoragePath(r.path) === item.target)) === identity(item.references) && await exists(item.target) && await hash(item.target) === item.sha256) continue
        if (JSON.stringify(sourceRefs.map(r=>[r.model,r.id,r.field,r.path]).sort()) !== JSON.stringify(item.references.map((r:any)=>[r.model,r.id,r.field,r.path]).sort())) throw new Error(`References changed: ${item.source}`)
        if (!await exists(item.source) || await exists(item.target) || await hash(item.source) !== item.sha256) throw new Error(`File changed or conflict: ${item.source}`)
        await ensureParent(item.target)
        await executeChanges(null, 'migrate-lab', [{ source: item.source, target: item.target, refs: sourceRefs }])
        console.log('Migrated:', item.source)
      }
    })
  } else if (command === 'rollback') {
    if (process.env.STORAGE_MAINTENANCE !== '1') throw new Error('Stop storage writers; set STORAGE_MAINTENANCE=1')
    const plan = JSON.parse(await readFile(planFile, 'utf8'))
    await withStorageLock(async () => {
      await recoverStorageOperations()
      for (const item of [...plan.items].reverse()) {
        const refs = (await fileReferences(prisma, [item.target])).filter(r => normalizeStoragePath(r.path) === item.target)
        if (!refs.length) continue
        if (identity(refs) !== identity(item.references)) throw new Error(`Rollback references changed: ${item.target}`)
        if (await exists(item.source) || !await exists(item.target) || await hash(item.target) !== item.sha256) throw new Error(`Rollback conflict: ${item.source}`)
        await ensureParent(item.source)
        await executeChanges(null, 'rollback-lab', [{ source: item.target, target: item.source, refs }])
        console.log('Restored:', item.source)
      }
    })
  } else if (command === 'verify') {
    const plan = JSON.parse(await readFile(planFile, 'utf8'))
    let errors = 0
    for (const item of plan.items) {
      const refs = await fileReferences(prisma, [item.source, item.target])
      const targets = refs.filter(r => normalizeStoragePath(r.path) === item.target)
      if (identity(targets) !== identity(item.references) || refs.some(r => normalizeStoragePath(r.path) === item.source) || !await exists(item.target) || await hash(item.target) !== item.sha256) {
        errors++; console.error('VERIFY_FAILED:', item.target)
      }
    }
    if (errors) throw new Error(`Verification failed for ${errors} files`)
    console.log(`Verified ${plan.items.length} migrated files and their references`)
  } else if (command === 'recover') {
    if (process.env.STORAGE_MAINTENANCE !== '1') throw new Error('Stop storage writers; set STORAGE_MAINTENANCE=1')
    // A crashed process leaves a lock. Removal is explicit, never time-based.
    if (process.env.STORAGE_CLEAR_STALE_LOCK === '1') await unlink(path.join(storageJournalRoot, 'lock')).catch(error => { if (error.code !== 'ENOENT') throw error })
    await withStorageLock(recoverStorageOperations)
    console.log('Recovery finished')
  } else throw new Error('Use plan, apply, verify, rollback or recover')
} catch (error) { console.error((error as Error).message); process.exitCode = 1 }
finally { await prisma.$disconnect() }
