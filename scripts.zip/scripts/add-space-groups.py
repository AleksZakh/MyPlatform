#!/usr/bin/env python3
"""Additive patch for a single-file Prisma schema. Stops on incompatible or duplicate models."""
import re
import sys
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else 'prisma/schema.prisma')
text = path.read_text(encoding='utf-8')
original = text
spec = (Path(__file__).resolve().parent.parent / 'schema-additions.txt').read_text(encoding='utf-8')
models = spec.split('Добавить модели один раз:\n', 1)[1]
def blocks(source, name):
    return list(re.finditer(r'^model\s+' + re.escape(name) + r'\s*\{.*?^\}', source, re.M | re.S))
for name, table in [('User', 'app_users'), ('Department', 'departments'), ('DomainGroup', 'domain_groups'), ('AccessResource', 'access_resources'), ('DirectoryDepartmentMapping', 'directory_department_mappings')]:
    found = blocks(text, name)
    if len(found) != 1 or f'@@map("{table}")' not in found[0].group():
        sys.exit(f'Остановка: требуется ровно одна модель {name} с таблицей {table}. Сначала установите базовые изменения v2. Файл не изменён.')
for name, declaration in [('User', 'spaceGroups SpaceGroupUser[]'), ('DomainGroup', 'spaceGroups SpaceGroupDomain[]'), ('AccessResource', 'spaceGroupPermissions SpaceGroupPermission[]')]:
    block = blocks(text, name)[0]
    field = declaration.split()[0]
    exists = re.search(r'^\s*' + field + r'\s+([^\n]+)', block.group(), re.M)
    if exists:
        if exists[1].strip() != declaration.split(' ', 1)[1]:
            sys.exit(f'Остановка: поле {name}.{field} уже существует с другим типом. Файл не изменён.')
    else:
        start = block.start() + block.group().index('{') + 1
        text = text[:start] + '\n  ' + declaration + text[start:]
for match in re.finditer(r'^model\s+(\w+)\s*\{.*?^\}', models, re.M | re.S):
    existing = blocks(text, match[1])
    if len(existing) > 1:
        sys.exit(f'Остановка: повтор модели {match[1]}. Файл не изменён.')
    if existing:
        if re.sub(r'\s+', '', existing[0].group()) != re.sub(r'\s+', '', match.group()):
            sys.exit(f'Остановка: модель {match[1]} уже существует в другой версии. Файл не изменён.')
    else:
        text += '\n\n' + match.group() + '\n'
if text == original:
    print('Схема уже содержит эти модели и связи. Изменений нет.')
else:
    backup = path.with_name(path.name + '.before-space-groups.bak')
    if not backup.exists():
        backup.write_text(original, encoding='utf-8')
    path.write_text(text, encoding='utf-8')
    print('Добавлены модели групп Space; исходная схема сохранена в .bak. Теперь выполните prisma validate и prisma generate.')
