import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, join } from 'node:path';

type Entity = 'sampling' | 'receipts' | 'protocols';
type Row = Record<string, any>;
type Spec = { file: string; fields: [string,string][]; required: string[]; document: string; list: string };
const specs: Record<Entity, Spec> = {
  sampling: { file: 'sampling.csv', fields: [
    ['date','Дата отбора проб'], ['object','Наименование объекта'],
    ['place','Место отбора проб'], ['number','Номер акта отбора проб']
  ], required: ['date','object','place','number'], document:'Документ отбора проб', list:'176' },
  receipts: { file:'receivedMaterials.csv', fields: [
    ['date','Дата поступления'], ['material','Материал'],
    ['qualityDate','Дата документа о качестве'], ['qualityNumber','Номер документа о качестве'],
    ['manufacturer','Предприятие изготовитель']
  ], required:['date','material'], document:'Документ о качестве', list:'177' },
  protocols: { file:'testProtocols.csv', fields: [
    ['date','Дата'], ['number','Номер'], ['result','Результат испытаний']
  ], required:['date','number'], document:'Протокол испытаний', list:'178' }
};

// Deliberately retain digits, leading zeros, hyphens, slashes and plus signs.
function normalizeText(value: unknown): string {
  return String(value ?? '').normalize('NFC').toLowerCase()
    .replace(/[?№#"'«»“”„‘’`\s\u00a0]+/gu, '');
}
function normalizeDate(value: unknown): string {
  if (value == null || value === '') return '';
  const text = value instanceof Date ? value.toISOString() : String(value).trim();
  if (!text) return '';
  let y: number, m: number, d: number;
  const ru = /^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/.exec(text);
  const iso = /^(\d{4})-(\d{2})-(\d{2})(?:T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)?$/.exec(text);
  if (ru) { y=+ru[3];m=+ru[2];d=+ru[1]; }
  else if (iso) { y=+iso[1];m=+iso[2];d=+iso[3]; }
  else throw new Error(`Invalid date: ${text}`);
  const date = new Date(Date.UTC(y,m-1,d));
  if (date.getUTCFullYear()!==y || date.getUTCMonth()!==m-1 || date.getUTCDate()!==d)
    throw new Error(`Invalid date: ${text}`);
  return `${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
}
function normalize(field: string, value: unknown) {
  return field==='date' || field==='qualityDate' ? normalizeDate(value) : normalizeText(value);
}
function buildKey(entity: Entity, row: Row) {
  const spec = specs[entity];
  const values = Object.fromEntries(spec.fields.map(([k])=>[k,normalize(k,row[k])]));
  const missing = spec.required.filter(k=>!values[k]);
  return { key: JSON.stringify(spec.fields.map(([k])=>values[k])), missing, values };
}
function compare(entity: Entity, source: Row[], current: Row[]) {
  const spec = specs[entity];
  const index = new Map<string,string[]>();
  const invalidDb: Row[] = [];
  for (const row of current) {
    if (row.deleted) continue;
    try {
      const k = buildKey(entity,row);
      if (k.missing.length) { invalidDb.push({space_id:row.id, reason:'Missing fields',fields:k.missing}); continue; }
      const group=index.get(k.key)??[];group.push(String(row.id));index.set(k.key,group);
    } catch (e) { invalidDb.push({space_id:row.id,reason:String(e)}); }
  }
  const results=source.map((row,i)=>{
    const values=Object.fromEntries(spec.fields.map(([k,h])=>[k,row[h]]));
    const url=String(row['Ссылка']??row['']??'').trim();
    let legacyId='',fileId='',linkStatus='NO_LINK';
    if(url) {
      try {
        const u=new URL(url);
        legacyId=u.searchParams.get('element_id')??'';fileId=u.searchParams.get('file_id')??'';
        linkStatus=u.protocol==='https:' && u.hostname==='portal.avtodor-eng.ru' && !u.username && !u.password &&
          (!u.port || u.port==='443') && u.searchParams.get('list_id')===spec.list &&
          /^\d+$/.test(legacyId) && /^\d+$/.test(fileId) &&
          ['element_id','file_id','list_id'].every(k=>u.searchParams.getAll(k).length===1)
          ? 'VALID':'CHECK_LINK';
      } catch { linkStatus='INVALID_LINK'; }
    }
    const result:Row={entity,row:i+2,legacy_id:legacyId,file_id:fileId,space_id:'',status:'',
      candidates:'',missing_fields:'',detail:'',link_status:linkStatus,
      filename:row[spec.document]??'',url,source_values:values,normalized_values:{}};
    try {
      const k=buildKey(entity,values);result.normalized_values=k.values;
      if(k.missing.length) {
        result.status='MISSING_FIELDS';
        result.missing_fields=spec.fields.filter(([f])=>k.missing.includes(f)).map(([,h])=>h).join(' | ');
      } else {
        const ids=index.get(k.key)??[];result.candidates=ids.join(',');
        result.status=ids.length===1?'MATCH':ids.length?'AMBIGUOUS':'NOT_FOUND';
        if(ids.length===1) result.space_id=ids[0];
      }
    } catch(e) { result.status='INVALID_DATE';result.detail=String(e); }
    return result;
  });
  return {results,invalidDb};
}
function csvCell(value: unknown): string {
  let s=typeof value==='object'?JSON.stringify(value):String(value??'');
  if(/^[\s]*[=+\-@]/.test(s)) s="'"+s;
  return '"'+s.replace(/"/g,'""')+'"';
}
function writeCsv(path:string,rows:Row[],columns:string[]) {
  writeFileSync(path,'\ufeff'+[columns,...rows.map(r=>columns.map(k=>r[k]))].map(r=>r.map(csvCell).join(';')).join('\r\n')+'\r\n',{flag:'wx',mode:0o600});
}
async function snapshotFromDatabase() {
  const {PrismaClient,Prisma}=await import('@prisma/client');
  const db=new PrismaClient();
  try {
    return await db.$transaction(async tx=>{
      await tx.$executeRawUnsafe('SET TRANSACTION READ ONLY');
      const sampling=await tx.samplingTest.findMany({where:{deletedAt:null},select:{id:true,samplingDate:true,samplingActNumber:true,testLocation:{select:{name:true,testObject:{select:{name:true}}}}}});
      const receipts=await tx.receiptMaterial.findMany({where:{deletedAt:null},select:{id:true,receiptDate:true,qualityDocumentDate:true,qualityDocumentNumber:true,material:{select:{name:true}},manufacturer:{select:{name:true}}}});
      const protocols=await tx.testProtocol.findMany({where:{deletedAt:null},select:{id:true,protocolNumber:true,protocolDate:true,testResult:true}});
      return {version:1,exportedAt:new Date().toISOString(),
        sampling:sampling.map(s=>({id:String(s.id),date:s.samplingDate,number:s.samplingActNumber,object:s.testLocation.testObject.name,place:s.testLocation.name})),
        receipts:receipts.map(r=>({id:String(r.id),date:r.receiptDate,material:r.material.name,qualityDate:r.qualityDocumentDate,qualityNumber:r.qualityDocumentNumber,manufacturer:r.manufacturer?.name})),
        protocols:protocols.map(p=>({id:String(p.id),date:p.protocolDate,number:p.protocolNumber,result:p.testResult}))};
    },{isolationLevel:Prisma.TransactionIsolationLevel.RepeatableRead,timeout:180000});
  } finally {await db.$disconnect();}
}
async function main() {
  if(process.argv[2]==='--self-test') {
    const {strict:assert}=await import('node:assert');
    assert.equal(normalizeText('ООО «Тест» № 4 ? #'),normalizeText('ооо Тест4'));
    assert.notEqual(normalizeText('01/02-03'),normalizeText('010203'));
    assert.equal(normalizeDate('1.02.2025'),'2025-02-01');assert.throws(()=>normalizeDate('31.02.2025'));
    const source=[{'Дата отбора проб':'01.02.2025','Наименование объекта':'Объект №1','Место отбора проб':'ПК 1+00 ?','Номер акта отбора проб':'#001'}];
    const db=[{id:'9',date:'2025-02-01',object:'объект1',place:'ПК1+00',number:'001'}];
    assert.equal(compare('sampling',source,db).results[0].status,'MATCH');
    assert.equal(compare('sampling',source,[...db,{...db[0],id:'10'}]).results[0].status,'AMBIGUOUS');
    assert.equal(compare('sampling',[{...source[0],'Дата отбора проб':''}],db).results[0].status,'MISSING_FIELDS');
    assert.equal(compare('sampling',source,[{...db[0],deleted:true}]).results[0].status,'NOT_FOUND');
    const many=Array.from({length:50000},(_,i)=>({...source[0],'Номер акта отбора проб':String(i)}));
    const dbMany=Array.from({length:50000},(_,i)=>({...db[0],id:String(i),number:String(i)}));
    assert.equal(compare('sampling',many,dbMany).results.filter(r=>r.status==='MATCH').length,50000);
    console.log('Self-tests passed, including 50,000 rows. No database connection.');return;
  }
  const [input,out,...rest]=process.argv.slice(2);
  if(!input||!out||!([0,2].includes(rest.length))||(rest.length && rest[0]!=='--snapshot'))
    throw new Error('Usage: npx tsx scripts/analyze-lab-simple.ts CSV_DIRECTORY NEW_REPORT_DIRECTORY [--snapshot snapshot.json]');
  const {parse}=await import('csv-parse/sync');
  const sources:Partial<Record<Entity,Row[]>>={};
  for(const entity of Object.keys(specs) as Entity[]) {
    const spec=specs[entity];
    console.log(`Reading CSV: ${join(resolve(input), spec.file)}`);
    const table=parse(readFileSync(join(resolve(input),spec.file),'utf8'),{bom:true,delimiter:';',skip_empty_lines:true}) as string[][];
    if(!table.length)throw new Error(`Empty CSV: ${spec.file}`);
    const headers=table[0].map(h=>h.trim());
    if(new Set(headers).size!==headers.length)throw new Error(`Duplicate headers: ${spec.file}`);
    const missing=spec.fields.map(([,h])=>h).filter(h=>!headers.includes(h));
    if(missing.length)throw new Error(`${spec.file}: missing columns: ${missing.join(', ')}`);
    sources[entity]=table.slice(1).map(cells=>Object.fromEntries(headers.map((h,i)=>[h,cells[i]])));
  }
  mkdirSync(resolve(out),{mode:0o700});
  const snap:Row=rest.length?JSON.parse(readFileSync(rest[1],'utf8')):await snapshotFromDatabase();
  if(snap.version!==1)throw new Error('Unsupported snapshot version');
  const summary:Row={snapshotAt:snap.exportedAt??null,rule:'Unique normalized field-set match',normalization:'Ignore whitespace, case, ?, №, # and quotes; preserve other punctuation',entities:{}};
  const all:Row[]=[];
  for(const entity of Object.keys(specs) as Entity[]) {
    if(!Array.isArray(snap[entity]))throw new Error(`Missing snapshot table: ${entity}`);
    const {results,invalidDb}=compare(entity,sources[entity]!,snap[entity]);all.push(...results);
    summary.entities[entity]={csvRows:results.length,activeDbRows:snap[entity].filter((r:Row)=>!r.deleted).length,
      fields:specs[entity].fields.map(([,h])=>h),counts:results.reduce((a:Row,r)=>{a[r.status]=(a[r.status]??0)+1;return a;},{}),
      invalidDbRows:invalidDb.length};
    writeCsv(join(out,entity+'.csv'),results,['entity','row','legacy_id','file_id','space_id','status','candidates','missing_fields','detail','link_status','filename','url','source_values','normalized_values']);
    writeCsv(join(out,entity+'-db-issues.csv'),invalidDb,['space_id','reason','fields']);
  }
  const matched=all.filter(r=>r.status==='MATCH');
  writeCsv(join(out,'matched.csv'),matched,['entity','row','legacy_id','file_id','space_id','link_status','filename','url']);
  // Repeated assignments are reported, not suppressed: one record may have several files.
  const grouped=new Map<string,Row[]>();
  for(const r of matched) {const key=r.entity+':'+r.space_id;const group=grouped.get(key)??[];group.push(r);grouped.set(key,group);}
  const repeats=[...grouped.values()].filter(g=>g.length>1).flat();
  writeCsv(join(out,'repeated-targets.csv'),repeats,['entity','row','legacy_id','file_id','space_id','filename','url']);
  summary.repeatedTargetRows=repeats.length;
  summary.matchedWithValidLink=matched.filter(r=>r.link_status==='VALID').length;
  writeFileSync(join(out,'matches.json'),JSON.stringify(matched,null,2),{flag:'wx',mode:0o600});
  writeFileSync(join(out,'summary.json'),JSON.stringify(summary,null,2),{flag:'wx',mode:0o600});
  console.log(JSON.stringify(summary,null,2));console.log(`Reports saved: ${resolve(out)}. No database changes or downloads.`);
}
main().catch(e=>{console.error(e instanceof Error?e.message:String(e));process.exitCode=1;});
