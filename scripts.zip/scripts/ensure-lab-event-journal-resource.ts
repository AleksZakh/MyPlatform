// scripts/ensure-lab-event-journal-resource.ts

import {
  AccessAction,
  AccessResourceType,
  PrismaClient,
} from '@prisma/client'


const prisma =
  new PrismaClient()


const RESOURCE_KEY =
  'lab.event-journal'


function readGrantLogin():
  string | null {
  const prefix =
    '--grant-login='

  const arg =
    process.argv.find(
      value =>
        value.startsWith(
          prefix,
        ),
    )

  if (!arg) {
    return null
  }

  return (
    arg.slice(
      prefix.length,
    ).trim() ||
    null
  )
}


async function main() {
  const resource =
    await prisma.accessResource
      .upsert({
        where: {
          key:
            RESOURCE_KEY,
        },

        update: {
          name:
            'Журнал лабораторных событий',

          description:
            'Read-only журнал событий лабораторного процесса: отбор проб, поступление материала и протокол испытаний с историей изменений.',

          type:
            AccessResourceType.SECTION,

          isActive:
            true,
        },

        create: {
          key:
            RESOURCE_KEY,

          name:
            'Журнал лабораторных событий',

          description:
            'Read-only журнал событий лабораторного процесса: отбор проб, поступление материала и протокол испытаний с историей изменений.',

          type:
            AccessResourceType.SECTION,

          isActive:
            true,

          sortOrder:
            320,
        },
      })


  const department =
    await prisma.department
      .findUnique({
        where: {
          key:
            'laboratory-control',
        },

        select: {
          id:
            true,
        },
      })


  if (department) {
    await prisma.departmentResource
      .upsert({
        where: {
          departmentId_resourceId: {
            departmentId:
              department.id,

            resourceId:
              resource.id,
          },
        },

        update: {
          isOwner:
            true,
        },

        create: {
          departmentId:
            department.id,

          resourceId:
            resource.id,

          isOwner:
            true,
        },
      })
  }


  console.log(
    `✅ SECTION-ресурс готов: ${RESOURCE_KEY}`,
  )


  const grantLogin =
    readGrantLogin()


  if (!grantLogin) {
    console.log(
      'ℹ️ VIEW пользователю не выдавался.',
    )

    console.log(
      '   Для теста:',
    )

    console.log(
      '   npx tsx scripts/ensure-lab-event-journal-resource.ts --grant-login=LOGIN',
    )

    return
  }


  const user =
    await prisma.user
      .findUnique({
        where: {
          login:
            grantLogin,
        },

        select: {
          id:
            true,

          login:
            true,
        },
      })


  if (!user) {
    throw new Error(
      `Пользователь "${grantLogin}" не найден`,
    )
  }


  await prisma.userPermission
    .upsert({
      where: {
        userId_resourceId_action: {
          userId:
            user.id,

          resourceId:
            resource.id,

          action:
            AccessAction.VIEW,
        },
      },

      update: {
        grantedByLogin:
          'bootstrap-script',
      },

      create: {
        userId:
          user.id,

        resourceId:
          resource.id,

        action:
          AccessAction.VIEW,

        grantedByLogin:
          'bootstrap-script',
      },
    })


  console.log(
    `✅ VIEW выдан пользователю ${user.login}`,
  )
}


main()
  .catch(
    error => {
      console.error(
        '❌ Ошибка:',
        error,
      )

      process.exitCode =
        1
    },
  )
  .finally(
    async () => {
      await prisma.$disconnect()
    },
  )
