import { readFile, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const schema = path.resolve(process.argv[2] || path.join(root, 'prisma/schema.prisma'))
const source = await readFile(schema, 'utf8')
const hasGroup = /\bmodel\s+DomainGroup\s*\{/.test(source)
const hasPermission = /\bmodel\s+DomainGroupPermission\s*\{/.test(source)
const match = /\bmodel\s+AccessResource\s*\{[\s\S]*?^\}/m.exec(source)
if (!match) throw new Error('AccessResource model not found; schema has not been changed.')
const hasRelation = /\bdomainGroupPermissions\s+DomainGroupPermission\[\]/.test(match[0])
if (hasGroup && hasPermission && hasRelation) {
  console.log('Group models are already present. No changes. Run prisma validate to check your schema.')
} else {
  if (hasGroup || hasPermission || hasRelation) throw new Error('Partial group schema exists; reconcile it manually. No changes made.')
  const models = await readFile(path.join(root, 'prisma/patches/domain-groups.prisma'), 'utf8')
  const updated = source.replace(match[0], match[0].replace('{', '{\n  domainGroupPermissions DomainGroupPermission[]')) + '\n' + models
  // Never overwrite a prior backup.
  await writeFile(schema + '.before-domain-groups.bak', source, { flag: 'wx' })
  await writeFile(schema, updated)
  console.log('Added DomainGroup, DomainGroupPermission and AccessResource relation. Backup saved alongside the schema.')
}
