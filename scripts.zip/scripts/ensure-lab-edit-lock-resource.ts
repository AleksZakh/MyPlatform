// scripts/ensure-lab-edit-lock-resource.ts

import {
  AccessAction,
  AccessResourceType,
  PrismaClient,
} from '@prisma/client'


const prisma =
  new PrismaClient()


const RESOURCE_KEY =
  'lab.incoming-control.edit-lock-override'


function readGrantLogin():
  string | null {
  const prefix =
    '--grant-login='

  const arg =
    process.argv.find(
      value =>
        value.startsWith(
          prefix,
        ),
    )

  if (!arg) {
    return null
  }

  return (
    arg.slice(
      prefix.length,
    ).trim() ||
    null
  )
}


async function main() {
  const resource =
    await prisma.accessResource
      .upsert({
        where: {
          key:
            RESOURCE_KEY,
        },

        update: {
          name:
            'Обход 30-минутной блокировки Реестра входного контроля',

          description:
            'Позволяет руководителю редактировать отбор проб, поступление материала и существующий протокол после истечения стандартного 30-минутного окна.',

          type:
            AccessResourceType.FEATURE,

          isActive:
            true,
        },

        create: {
          key:
            RESOURCE_KEY,

          name:
            'Обход 30-минутной блокировки Реестра входного контроля',

          description:
            'Позволяет руководителю редактировать отбор проб, поступление материала и существующий протокол после истечения стандартного 30-минутного окна.',

          type:
            AccessResourceType.FEATURE,

          isActive:
            true,

          sortOrder:
            900,
        },
      })


  const department =
    await prisma.department
      .findUnique({
        where: {
          key:
            'laboratory-control',
        },

        select: {
          id: true,
        },
      })


  if (department) {
    await prisma.departmentResource
      .upsert({
        where: {
          departmentId_resourceId: {
            departmentId:
              department.id,

            resourceId:
              resource.id,
          },
        },

        update: {
          isOwner:
            true,
        },

        create: {
          departmentId:
            department.id,

          resourceId:
            resource.id,

          isOwner:
            true,
        },
      })
  }


  console.log(
    `✅ FEATURE-ресурс готов: ${RESOURCE_KEY}`,
  )


  const grantLogin =
    readGrantLogin()


  if (!grantLogin) {
    console.log(
      'ℹ️ Право пользователю не выдавалось.',
    )

    console.log(
      '   Для теста можно запустить:',
    )

    console.log(
      '   npx tsx scripts/ensure-lab-edit-lock-resource.ts --grant-login=LOGIN',
    )

    return
  }


  const user =
    await prisma.user
      .findUnique({
        where: {
          login:
            grantLogin,
        },

        select: {
          id: true,
          login: true,
        },
      })


  if (!user) {
    throw new Error(
      `Пользователь "${grantLogin}" не найден`,
    )
  }


  const existing =
    await prisma.userPermission
      .findFirst({
        where: {
          userId:
            user.id,

          resourceId:
            resource.id,

          action:
            AccessAction.UPDATE,
        },

        select: {
          id: true,
        },
      })


  if (!existing) {
    await prisma.userPermission
      .create({
        data: {
          userId:
            user.id,

          resourceId:
            resource.id,

          action:
            AccessAction.UPDATE,

          grantedByLogin:
            'bootstrap-script',
        },
      })
  }


  console.log(
    `✅ Override UPDATE выдан пользователю ${user.login}`,
  )
}


main()
  .catch(error => {
    console.error(
      '❌ Ошибка:',
      error,
    )

    process.exitCode = 1
  })
  .finally(
    async () => {
      await prisma.$disconnect()
    },
  )
