-- Удаляет ТОЛЬКО данные лабораторного контура.
-- Пользователи, права, Event Log и остальные таблицы не затрагиваются.
TRUNCATE TABLE
  "sampling_tests",
  "test_protocols",
  "receipt_materials",
  "test_locations",
  "test_objects",
  "materials",
  "manufacturers",
  "inspectors",
  "plps"
RESTART IDENTITY CASCADE;