import 'dotenv/config';

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

function hasValue(value: unknown): boolean {
  if (value === null || value === undefined) {
    return false;
  }

  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();

    return ![
      '',
      '-',
      'null',
      'undefined',
      'нет',
      'n/a',
    ].includes(normalized);
  }

  return true;
}

function receiptScore(receipt: {
  receiptDate: Date | null;
  qualDate: Date | null;
  qualDocNumber: string | null;
  qualDocPath: string | null;
  materialId: number;
} | null): number {
  if (!receipt) {
    return 0;
  }

  let score = 0;

  if (receipt.receiptDate) score++;
  if (receipt.qualDate) score++;
  if (hasValue(receipt.qualDocNumber)) score++;
  if (hasValue(receipt.qualDocPath)) score++;
  if (receipt.materialId) score++;

  return score;
}

async function main() {
  console.log('\n🔎 LAB RELATION CONFLICT AUDIT');
  console.log('READ ONLY\n');

  const records = await prisma.samplingTest.findMany({
    where: {
      testProtocolId: {
        not: null,
      },
    },

    select: {
      id: true,
      receiptMaterialId: true,

      receiptMaterial: {
        select: {
          id: true,
          receiptDate: true,
          qualDate: true,
          qualDocNumber: true,
          qualDocPath: true,
          materialId: true,
          createdAt: true,
        },
      },

      testProtocol: {
        select: {
          id: true,
          receiptMaterialId: true,

          receiptMaterial: {
            select: {
              id: true,
              receiptDate: true,
              qualDate: true,
              qualDocNumber: true,
              qualDocPath: true,
              materialId: true,
              createdAt: true,
            },
          },
        },
      },
    },
  });

  const conflicts = records.filter((record) => {
    const directReceiptId =
      record.receiptMaterialId;

    const protocolReceiptId =
      record.testProtocol?.receiptMaterialId ?? null;

    return (
      directReceiptId === null ||
      (
        protocolReceiptId !== null &&
        directReceiptId !== protocolReceiptId
      )
    );
  });

  console.log(
    `Найдено конфликтных SamplingTest: ${conflicts.length}\n`,
  );

  for (const record of conflicts) {
    const direct =
      record.receiptMaterial;

    const viaProtocol =
      record.testProtocol?.receiptMaterial ?? null;

    console.log('='.repeat(72));

    console.log(`SamplingTest ID: ${record.id}`);

    console.log(
      `TestProtocol ID: ${record.testProtocol?.id ?? '-'}`,
    );

    console.log(
      `Прямой ReceiptMaterial ID: ${direct?.id ?? '-'}`,
    );

    console.log(
      `ReceiptMaterial через TestProtocol: ${viaProtocol?.id ?? '-'}`,
    );

    console.log(
      `Одинаковый Material ID: ${
        direct &&
        viaProtocol &&
        direct.materialId === viaProtocol.materialId
          ? 'ДА'
          : 'НЕТ'
      }`,
    );

    console.log(
      `Полнота прямого ReceiptMaterial: ${receiptScore(direct)}/5`,
    );

    console.log(
      `Полнота ReceiptMaterial через TestProtocol: ${receiptScore(viaProtocol)}/5`,
    );

    console.log(
      `Дата поступления заполнена: direct=${
        !!direct?.receiptDate
      }, protocol=${!!viaProtocol?.receiptDate}`,
    );

    console.log(
      `Дата документа заполнена: direct=${
        !!direct?.qualDate
      }, protocol=${!!viaProtocol?.qualDate}`,
    );

    console.log(
      `Номер документа заполнен: direct=${
        hasValue(direct?.qualDocNumber)
      }, protocol=${
        hasValue(viaProtocol?.qualDocNumber)
      }`,
    );

    console.log(
      `Файл документа заполнен: direct=${
        hasValue(direct?.qualDocPath)
      }, protocol=${
        hasValue(viaProtocol?.qualDocPath)
      }`,
    );
  }


  // ==========================================================
  // Проверяем технические значения путей старого импорта
  // ==========================================================

  console.log('\n');
  console.log('='.repeat(72));
  console.log('PATH PLACEHOLDER AUDIT');
  console.log('='.repeat(72));

  const [
    samplingTests,
    receipts,
    protocols,
  ] = await Promise.all([
    prisma.samplingTest.findMany({
      select: {
        sDocPath: true,
      },
    }),

    prisma.receiptMaterial.findMany({
      select: {
        qualDocPath: true,
      },
    }),

    prisma.testProtocol.findMany({
      select: {
        protocolDocPath: true,
      },
    }),
  ]);

  function summarizePaths(
    values: Array<string | null>,
  ) {
    let nullOrEmpty = 0;
    let placeholder = 0;
    let realValue = 0;

    for (const value of values) {
      if (
        value === null ||
        value === undefined ||
        value.trim() === ''
      ) {
        nullOrEmpty++;
        continue;
      }

      if (!hasValue(value)) {
        placeholder++;
        continue;
      }

      realValue++;
    }

    return {
      nullOrEmpty,
      placeholder,
      realValue,
    };
  }

  console.log(
    'Sampling documents:',
    summarizePaths(
      samplingTests.map(
        record => record.sDocPath,
      ),
    ),
  );

  console.log(
    'Quality documents:',
    summarizePaths(
      receipts.map(
        record => record.qualDocPath,
      ),
    ),
  );

  console.log(
    'Protocol documents:',
    summarizePaths(
      protocols.map(
        record => record.protocolDocPath,
      ),
    ),
  );


  console.log('\n✅ Готово. БД не изменялась.\n');
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });