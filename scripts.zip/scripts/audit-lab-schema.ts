import 'dotenv/config';

import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { PrismaClient } from '@prisma/client';
import { parse } from 'csv-parse/sync';


const prisma = new PrismaClient();

const SAMPLE_SIZE = 10;


// ============================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function printSection(title: string) {
  console.log('\n');
  console.log('='.repeat(80));
  console.log(title);
  console.log('='.repeat(80));
}


function printCheck(
  title: string,
  count: number,
  sampleIds: number[] = [],
) {
  const icon = count === 0 ? '✅' : '⚠️';

  console.log(`${icon} ${title}: ${count}`);

  if (sampleIds.length > 0) {
    console.log(
      `   Примеры ID: ${sampleIds.slice(0, SAMPLE_SIZE).join(', ')}`,
    );
  }
}


function isEmpty(value: string | null | undefined): boolean {
  return !value || value.trim() === '';
}


function duplicateIds(
  rows: Array<{
    id: number;
    value: number | null;
  }>,
): Array<{
  value: number;
  recordIds: number[];
}> {
  const map = new Map<number, number[]>();

  for (const row of rows) {
    if (row.value === null) {
      continue;
    }

    const ids = map.get(row.value) ?? [];
    ids.push(row.id);
    map.set(row.value, ids);
  }

  return Array.from(map.entries())
    .filter(([, ids]) => ids.length > 1)
    .map(([value, recordIds]) => ({
      value,
      recordIds,
    }));
}


// ============================================================
// ОСНОВНАЯ ДИАГНОСТИКА
// ============================================================

async function main() {
  console.log('\n');
  console.log('🔎 LAB SCHEMA AUDIT');
  console.log('Режим: READ ONLY');
  console.log('База данных изменяться НЕ БУДЕТ.');
  console.log(`Запуск: ${new Date().toISOString()}`);


  // ============================================================
  // ЗАГРУЖАЕМ ТОЛЬКО НУЖНЫЕ ДАННЫЕ
  // ============================================================

  const [
    samplingTests,
    receiptMaterials,
    testProtocols,
    materials,
  ] = await Promise.all([

    prisma.samplingTest.findMany({
      select: {
        id: true,

        sActNumber: true,
        sActDate: true,
        sDocPath: true,

        receiptMaterialId: true,
        testProtocolId: true,

        deletedAt: true,

        receiptMaterial: {
          select: {
            id: true,
            receiptDate: true,
            qualDate: true,
            qualDocNumber: true,
            qualDocPath: true,
            materialId: true,
          },
        },

        testProtocol: {
          select: {
            id: true,
            protocolNumber: true,
            protocolDate: true,
            protocolDocPath: true,
            testResult: true,

            receiptMaterialId: true,

            receiptMaterial: {
              select: {
                id: true,
                receiptDate: true,
                qualDate: true,
                qualDocNumber: true,
                qualDocPath: true,
                materialId: true,
              },
            },
          },
        },
      },
    }),


    prisma.receiptMaterial.findMany({
      select: {
        id: true,
        receiptDate: true,
        qualDate: true,
        qualDocNumber: true,
        qualDocPath: true,
        materialId: true,
        deletedAt: true,
      },
    }),


    prisma.testProtocol.findMany({
      select: {
        id: true,
        protocolNumber: true,
        protocolDate: true,
        protocolDocPath: true,
        testResult: true,
        receiptMaterialId: true,
        deletedAt: true,
      },
    }),


    prisma.material.findMany({
      select: {
        id: true,
        name: true,
        manufacturerId: true,
        deletedAt: true,
      },
    }),
  ]);


  // ============================================================
  // 1. ОБЩАЯ СТАТИСТИКА
  // ============================================================

  printSection('1. ОБЩАЯ СТАТИСТИКА');

  console.log(`SamplingTest:      ${samplingTests.length}`);
  console.log(`ReceiptMaterial:   ${receiptMaterials.length}`);
  console.log(`TestProtocol:      ${testProtocols.length}`);
  console.log(`Material:          ${materials.length}`);


  // ============================================================
  // 2. SAMPLING TEST → RECEIPT MATERIAL
  // ============================================================

  printSection(
    '2. СВЯЗЬ SamplingTest → ReceiptMaterial',
  );


  const samplingWithoutReceipt =
    samplingTests.filter(
      record => record.receiptMaterialId === null,
    );


  printCheck(
    'SamplingTest без прямого receiptMaterialId',
    samplingWithoutReceipt.length,
    samplingWithoutReceipt.map(record => record.id),
  );


  // Проверяем повторное использование ReceiptMaterial.

  const duplicateReceipts = duplicateIds(
    samplingTests.map(record => ({
      id: record.id,
      value: record.receiptMaterialId,
    })),
  );


  printCheck(
    'ReceiptMaterial используется несколькими SamplingTest',
    duplicateReceipts.length,
    duplicateReceipts.flatMap(
      duplicate => duplicate.recordIds,
    ),
  );


  // ============================================================
  // 3. SAMPLING TEST → TEST PROTOCOL
  // ============================================================

  printSection(
    '3. СВЯЗЬ SamplingTest → TestProtocol',
  );


  const duplicateProtocols = duplicateIds(
    samplingTests.map(record => ({
      id: record.id,
      value: record.testProtocolId,
    })),
  );


  printCheck(
    'TestProtocol используется несколькими SamplingTest',
    duplicateProtocols.length,
    duplicateProtocols.flatMap(
      duplicate => duplicate.recordIds,
    ),
  );


  // ============================================================
  // 4. СТАРАЯ ЦЕПОЧКА
  //
  // SamplingTest
  //       ↓
  // TestProtocol
  //       ↓
  // ReceiptMaterial
  //
  // Сравниваем её с прямой связью SamplingTest.receiptMaterialId.
  // ============================================================

  printSection(
    '4. ПРОВЕРКА ДВУХ ПУТЕЙ К ReceiptMaterial',
  );


  const legacyOnlyReceipt = samplingTests.filter(
    record =>
      record.receiptMaterialId === null &&
      record.testProtocol?.receiptMaterialId != null,
  );


  printCheck(
    'Прямой ReceiptMaterial отсутствует, но найден через TestProtocol',
    legacyOnlyReceipt.length,
    legacyOnlyReceipt.map(record => record.id),
  );


  const mismatchedReceipt = samplingTests.filter(
    record =>
      record.receiptMaterialId !== null &&
      record.testProtocol?.receiptMaterialId != null &&
      record.receiptMaterialId !==
        record.testProtocol.receiptMaterialId,
  );


  printCheck(
    'SamplingTest и его TestProtocol указывают на разные ReceiptMaterial',
    mismatchedReceipt.length,
    mismatchedReceipt.map(record => record.id),
  );


  // ============================================================
  // 5. НЕИСПОЛЬЗУЕМЫЕ ReceiptMaterial
  // ============================================================

  printSection(
    '5. НЕИСПОЛЬЗУЕМЫЕ ReceiptMaterial',
  );


  const directlyUsedReceiptIds = new Set(
    samplingTests
      .map(record => record.receiptMaterialId)
      .filter((id): id is number => id !== null),
  );


  const protocolReceiptIds = new Set(
    testProtocols.map(
      protocol => protocol.receiptMaterialId,
    ),
  );


  const receiptUsedOnlyByProtocol =
    receiptMaterials.filter(
      receipt =>
        !directlyUsedReceiptIds.has(receipt.id) &&
        protocolReceiptIds.has(receipt.id),
    );


  printCheck(
    'ReceiptMaterial используется только старой связью через TestProtocol',
    receiptUsedOnlyByProtocol.length,
    receiptUsedOnlyByProtocol.map(receipt => receipt.id),
  );


  const completelyOrphanReceipts =
    receiptMaterials.filter(
      receipt =>
        !directlyUsedReceiptIds.has(receipt.id) &&
        !protocolReceiptIds.has(receipt.id),
    );


  printCheck(
    'ReceiptMaterial вообще ни к чему не привязан',
    completelyOrphanReceipts.length,
    completelyOrphanReceipts.map(receipt => receipt.id),
  );


  // ============================================================
  // 6. НЕИСПОЛЬЗУЕМЫЕ TestProtocol
  // ============================================================

  printSection(
    '6. НЕИСПОЛЬЗУЕМЫЕ TestProtocol',
  );


  const usedProtocolIds = new Set(
    samplingTests
      .map(record => record.testProtocolId)
      .filter((id): id is number => id !== null),
  );


  const orphanProtocols =
    testProtocols.filter(
      protocol => !usedProtocolIds.has(protocol.id),
    );


  printCheck(
    'TestProtocol не привязан ни к одному SamplingTest',
    orphanProtocols.length,
    orphanProtocols.map(protocol => protocol.id),
  );


  // ============================================================
  // 7. НЕСКОЛЬКО ПРОТОКОЛОВ НА ОДНО ПОСТУПЛЕНИЕ
  // ============================================================

  printSection(
    '7. TestProtocol → ReceiptMaterial',
  );


  const protocolReceiptDuplicates = duplicateIds(
    testProtocols.map(protocol => ({
      id: protocol.id,
      value: protocol.receiptMaterialId,
    })),
  );


  printCheck(
    'К одному ReceiptMaterial привязано несколько TestProtocol',
    protocolReceiptDuplicates.length,
    protocolReceiptDuplicates.flatMap(
      duplicate => duplicate.recordIds,
    ),
  );


  // ============================================================
  // 8. ОБЯЗАТЕЛЬНЫЕ ДАННЫЕ SamplingTest
  // ============================================================

  printSection(
    '8. ОБЯЗАТЕЛЬНЫЕ ДАННЫЕ SamplingTest',
  );


  const samplingWithoutActNumber =
    samplingTests.filter(
      record => isEmpty(record.sActNumber),
    );


  printCheck(
    'Пустой номер акта отбора',
    samplingWithoutActNumber.length,
    samplingWithoutActNumber.map(record => record.id),
  );


  const samplingWithoutDocument =
    samplingTests.filter(
      record => isEmpty(record.sDocPath),
    );


  printCheck(
    'Отсутствует обязательный файл акта отбора проб',
    samplingWithoutDocument.length,
    samplingWithoutDocument.map(record => record.id),
  );


  // ============================================================
  // 9. ОБЯЗАТЕЛЬНЫЕ ДАННЫЕ ReceiptMaterial
  // ============================================================

  printSection(
    '9. ОБЯЗАТЕЛЬНЫЕ ДАННЫЕ ReceiptMaterial',
  );


  const receiptWithoutDate =
    receiptMaterials.filter(
      receipt => receipt.receiptDate === null,
    );


  printCheck(
    'Не указана дата поступления материала',
    receiptWithoutDate.length,
    receiptWithoutDate.map(receipt => receipt.id),
  );


  // ============================================================
  // 10. ДОКУМЕНТ О КАЧЕСТВЕ
  // ============================================================

  printSection(
    '10. ЦЕЛОСТНОСТЬ ДОКУМЕНТА О КАЧЕСТВЕ',
  );


  const qualityDateWithoutDocument =
    receiptMaterials.filter(
      receipt =>
        receipt.qualDate !== null &&
        isEmpty(receipt.qualDocPath),
    );


  printCheck(
    'Есть дата документа о качестве, но нет файла',
    qualityDateWithoutDocument.length,
    qualityDateWithoutDocument.map(receipt => receipt.id),
  );


  const qualityDocumentWithoutDate =
    receiptMaterials.filter(
      receipt =>
        !isEmpty(receipt.qualDocPath) &&
        receipt.qualDate === null,
    );


  printCheck(
    'Есть файл документа о качестве, но нет даты',
    qualityDocumentWithoutDate.length,
    qualityDocumentWithoutDate.map(receipt => receipt.id),
  );


  const qualityNumberWithoutDate =
    receiptMaterials.filter(
      receipt =>
        !isEmpty(receipt.qualDocNumber) &&
        receipt.qualDate === null,
    );


  printCheck(
    'Есть номер документа о качестве, но нет даты',
    qualityNumberWithoutDate.length,
    qualityNumberWithoutDate.map(receipt => receipt.id),
  );


  // ============================================================
  // 11. ОБЯЗАТЕЛЬНЫЕ ДАННЫЕ TestProtocol
  // ============================================================

  printSection(
    '11. ОБЯЗАТЕЛЬНЫЕ ДАННЫЕ TestProtocol',
  );


  const protocolWithoutNumber =
    testProtocols.filter(
      protocol => isEmpty(protocol.protocolNumber),
    );


  printCheck(
    'Пустой номер протокола',
    protocolWithoutNumber.length,
    protocolWithoutNumber.map(protocol => protocol.id),
  );


  const protocolWithoutDate =
    testProtocols.filter(
      protocol => protocol.protocolDate === null,
    );


  printCheck(
    'Не указана дата протокола',
    protocolWithoutDate.length,
    protocolWithoutDate.map(protocol => protocol.id),
  );


  const protocolWithoutDocument =
    testProtocols.filter(
      protocol => isEmpty(protocol.protocolDocPath),
    );


  printCheck(
    'Отсутствует обязательный файл протокола',
    protocolWithoutDocument.length,
    protocolWithoutDocument.map(protocol => protocol.id),
  );


  const protocolWithoutResult =
    testProtocols.filter(
      protocol => isEmpty(protocol.testResult),
    );


  printCheck(
    'Не указан результат испытания',
    protocolWithoutResult.length,
    protocolWithoutResult.map(protocol => protocol.id),
  );


  // ============================================================
  // 12. ХРОНОЛОГИЯ
  // ============================================================

  printSection(
    '12. ПРОВЕРКА ХРОНОЛОГИИ ДАТ',
  );


  const qualityAfterSampling: number[] = [];
  const samplingAfterReceipt: number[] = [];
  const protocolBeforeReceipt: number[] = [];


  for (const record of samplingTests) {

    // Для диагностики старых данных:
    // сначала используем новую прямую связь,
    // а если её нет — старую через TestProtocol.

    const receipt =
      record.receiptMaterial ??
      record.testProtocol?.receiptMaterial ??
      null;


    if (!receipt) {
      continue;
    }


    // qualityDocumentDate <= samplingDate

    if (
      receipt.qualDate &&
      receipt.qualDate.getTime() >
        record.sActDate.getTime()
    ) {
      qualityAfterSampling.push(record.id);
    }


    // samplingDate <= receiptDate

    if (
      receipt.receiptDate &&
      record.sActDate.getTime() >
        receipt.receiptDate.getTime()
    ) {
      samplingAfterReceipt.push(record.id);
    }


    // receiptDate <= protocolDate

    if (
      receipt.receiptDate &&
      record.testProtocol?.protocolDate &&
      record.testProtocol.protocolDate.getTime() <
        receipt.receiptDate.getTime()
    ) {
      protocolBeforeReceipt.push(record.id);
    }
  }


  printCheck(
    'Дата документа о качестве ПОЗЖЕ даты отбора проб',
    qualityAfterSampling.length,
    qualityAfterSampling,
  );


  printCheck(
    'Дата отбора проб ПОЗЖЕ даты поступления материала',
    samplingAfterReceipt.length,
    samplingAfterReceipt,
  );


  printCheck(
    'Дата протокола РАНЬШЕ даты поступления материала',
    protocolBeforeReceipt.length,
    protocolBeforeReceipt,
  );


  // ============================================================
  // 13. ПРОИЗВОДИТЕЛИ
  // ============================================================

  printSection(
    '13. ГОТОВНОСТЬ К ПЕРЕНОСУ Manufacturer → ReceiptMaterial',
  );


  const materialManufacturerMap = new Map(
    materials.map(material => [
      material.id,
      material.manufacturerId,
    ]),
  );


  const receiptsWithoutManufacturer =
    receiptMaterials.filter(
      receipt =>
        materialManufacturerMap.get(
          receipt.materialId,
        ) == null,
    );


  printCheck(
    'Поступления, для которых у Material сейчас не указан Manufacturer',
    receiptsWithoutManufacturer.length,
    receiptsWithoutManufacturer.map(receipt => receipt.id),
  );


  // ============================================================
  // 14. СТАРЫЙ CSV
  // ============================================================

  printSection(
    '14. ПРОВЕРКА Material ↔ Manufacturer ПО СТАРОМУ CSV',
  );


  const csvPath = resolve(
    process.cwd(),
    'temp',
    'Reestr_1509.csv',
  );


  if (!existsSync(csvPath)) {
    console.log(
      'ℹ️ CSV temp/Reestr_1509.csv не найден. Проверка пропущена.',
    );
  } else {

    const csvContent =
      readFileSync(csvPath, 'utf8');


    const rows = parse(csvContent, {
      columns: true,
      delimiter: ';',
      bom: true,
      skip_empty_lines: true,
      relax_column_count: true,
    }) as Array<Record<string, string>>;


    const manufacturersByMaterial =
      new Map<string, Set<string>>();


    for (const row of rows) {

      const material =
        row['Наименование материала']
          ?.trim()
          .toLocaleLowerCase('ru-RU');


      const manufacturer =
        row['Предприятие-изготовитель']
          ?.trim()
          .toLocaleLowerCase('ru-RU');


      if (!material || !manufacturer) {
        continue;
      }


      const manufacturers =
        manufacturersByMaterial.get(material) ??
        new Set<string>();


      manufacturers.add(manufacturer);

      manufacturersByMaterial.set(
        material,
        manufacturers,
      );
    }


    const materialsWithSeveralManufacturers =
      Array.from(
        manufacturersByMaterial.entries(),
      )
        .filter(
          ([, manufacturers]) =>
            manufacturers.size > 1,
        );


    console.log(
      'ℹ️ Строк CSV:',
      rows.length,
    );


    console.log(
      'ℹ️ Уникальных материалов:',
      manufacturersByMaterial.size,
    );


    console.log(
      '⚠️ Материалов, встречавшихся у нескольких производителей:',
      materialsWithSeveralManufacturers.length,
    );
  }


  // ============================================================
  // ГОТОВО
  // ============================================================

  printSection(
    'ДИАГНОСТИКА ЗАВЕРШЕНА',
  );

  console.log(
    'База данных не изменялась.',
  );

  console.log(
    'Следующий шаг: разобрать результаты и подготовить безопасную миграцию.',
  );

  console.log('\n');
}


// ============================================================
// START
// ============================================================

main()
  .catch(error => {
    console.error('\n❌ Ошибка диагностики:');
    console.error(error);

    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });