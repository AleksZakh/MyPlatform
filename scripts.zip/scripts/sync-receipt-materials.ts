// scripts/sync-receipt-materials.ts
import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// ============================================
// НАСТРОЙКИ ЛОГИРОВАНИЯ
// ============================================
const LOG_DIR = path.join(process.cwd(), 'logs');
const LOG_FILE = path.join(LOG_DIR, `sync-receipt-${new Date().toISOString().replace(/[:.]/g, '-')}.log`);

// Создаем папку для логов, если её нет
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

// Функция для записи в лог
function writeLog(message: string, level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS' = 'INFO') {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [${level}] ${message}\n`;
  
  // Пишем в консоль
  if (level === 'ERROR') {
    console.error(logMessage);
  } else if (level === 'WARN') {
    console.warn(logMessage);
  } else if (level === 'SUCCESS') {
    console.log('\x1b[32m%s\x1b[0m', logMessage); // Зеленый цвет
  } else {
    console.log(logMessage);
  }
  
  // Пишем в файл
  fs.appendFileSync(LOG_FILE, logMessage);
}

// ============================================
// ОСНОВНАЯ ФУНКЦИЯ СИНХРОНИЗАЦИИ
// ============================================
async function syncReceiptMaterials() {
  writeLog('🚀 СТАРТ СИНХРОНИЗАЦИИ ДАННЫХ ПОСТУПЛЕНИЙ МАТЕРИАЛОВ', 'INFO');
  writeLog(`📁 Лог-файл: ${LOG_FILE}`, 'INFO');
  writeLog('', 'INFO');

  const CHUNK_SIZE = 100;
  let skip = 0;
  let hasMore = true;
  
  // Статистика
  let totalRecords = 0;
  let updatedRecords = 0;
  let skippedRecords = 0;
  let errorRecords = 0;
  let materialIdFixed = 0;
  let totalWithNote = 0;
  
  // Кэш для материалов (ускоряем поиск)
  const materialCache = new Map<string, number>();

  while (hasMore) {
    // Получаем порцию записей из AEng
    const records = await prisma.aEng.findMany({
      skip: skip,
      take: CHUNK_SIZE,
      orderBy: { id: 'asc' },
    });

    if (records.length === 0) {
      hasMore = false;
      break;
    }

    writeLog(`📦 Обработка порции... Индекс: ${skip}, Записей: ${records.length}`, 'INFO');
    
    for (const record of records) {
      totalRecords++;
      
      try {
        // ========================================
        // 1. ПОЛУЧАЕМ ДАННЫЕ ИЗ ЗАПИСИ AEng
        // ========================================
        const aengData = {
          id: record.id,
          materialName: record.materialName?.trim() || 'Неизвестный материал',
          qualDocDate: record.qualDocDate,
          qualDocNumber: record.qualDocNumber || '',
          qualDocPath: record.qualDocPath || record.qualityDocument || null,
          objectName: record.objectName?.trim() || 'Неизвестный объект',
          samplingPlace: record.samplingPlace?.trim() || 'Неизвестное место',
          samplingActNumber: record.samplingActNumber?.trim() || 'Без номера',
          note: record.note || '',
          manufacturer: record.manufacturer?.trim() || null,
        };

        // ========================================
        // 2. НАХОДИМ СООТВЕТСТВУЮЩУЮ ЗАПИСЬ В receipt_materials
        // ========================================
        // Ищем по номеру документа о качестве и материалу
        let receipt = await prisma.receiptMaterial.findFirst({
          where: {
            qualDocNumber: aengData.qualDocNumber,
            material: {
              name: aengData.materialName
            }
          },
          include: {
            material: true
          }
        });

        // Если не нашли по номеру документа, ищем по материалу и дате
        if (!receipt) {
          receipt = await prisma.receiptMaterial.findFirst({
            where: {
              material: {
                name: aengData.materialName
              },
              qualDate: aengData.qualDocDate,
            },
            include: {
              material: true
            }
          });
        }

        // Если всё равно не нашли, создаем новую запись
        if (!receipt) {
          writeLog(`⚠️ Запись поступления не найдена для AEng ID: ${record.id}, создаем новую`, 'WARN');
          
          // Находим или создаем материал
          let materialId = materialCache.get(aengData.materialName);
          if (!materialId) {
            let material = await prisma.material.findUnique({
              where: { name: aengData.materialName }
            });
            
            if (!material) {
              // Создаем материал, если его нет
              material = await prisma.material.create({
                data: {
                  name: aengData.materialName,
                  note: `Создан автоматически при синхронизации из AEng ID: ${record.id}`,
                  authorEmail: 'sync@system',
                  createdAt: new Date(),
                }
              });
              writeLog(`✅ Создан новый материал: "${aengData.materialName}" (ID: ${material.id})`, 'SUCCESS');
            }
            materialId = material.id;
            materialCache.set(aengData.materialName, materialId);
          }

          // Создаем новое поступление
          const newReceipt = await prisma.receiptMaterial.create({
            data: {
              qualDate: aengData.qualDocDate,
              qualDocNumber: aengData.qualDocNumber,
              qualDocPath: aengData.qualDocPath,
              note: `Объект: ${aengData.objectName}, Место: ${aengData.samplingPlace}, Акт: ${aengData.samplingActNumber}`,
              materialId: materialId,
              authorEmail: 'sync@system',
              createdAt: new Date(),
            }
          });
          
          receipt = newReceipt;
          writeLog(`✅ Создано новое поступление ID: ${receipt.id} для AEng ID: ${record.id}`, 'SUCCESS');
          updatedRecords++;
          continue;
        }

        // ========================================
        // 3. ПРОВЕРЯЕМ СООТВЕТСТВИЕ materialId
        // ========================================
        let materialId = materialCache.get(aengData.materialName);
        if (!materialId) {
          const material = await prisma.material.findUnique({
            where: { name: aengData.materialName }
          });
          if (material) {
            materialId = material.id;
            materialCache.set(aengData.materialName, materialId);
          }
        }

        // Проверяем, соответствует ли materialId
        if (materialId && receipt.materialId !== materialId) {
          writeLog(`🔄 Обновление materialId для receipt ID: ${receipt.id}`, 'INFO');
          await prisma.receiptMaterial.update({
            where: { id: receipt.id },
            data: {
              materialId: materialId,
              editorEmail: 'sync@system',
              editedAt: new Date(),
            }
          });
          materialIdFixed++;
        }

        // ========================================
        // 4. ПРОВЕРЯЕМ И ОБНОВЛЯЕМ ПОЛЯ
        // ========================================
        const needsUpdate: any = {};
        let hasChanges = false;

        // Проверяем qualDate
        if (receipt.qualDate?.getTime() !== aengData.qualDocDate?.getTime()) {
          needsUpdate.qualDate = aengData.qualDocDate;
          hasChanges = true;
        }

        // Проверяем qualDocNumber
        if ((receipt.qualDocNumber || '') !== aengData.qualDocNumber) {
          needsUpdate.qualDocNumber = aengData.qualDocNumber;
          hasChanges = true;
        }

        // Проверяем qualDocPath
        if ((receipt.qualDocPath || '') !== aengData.qualDocPath) {
          needsUpdate.qualDocPath = aengData.qualDocPath;
          hasChanges = true;
        }

        // Формируем примечание
        const newNote = `Объект: ${aengData.objectName}, Место: ${aengData.samplingPlace}, Акт: ${aengData.samplingActNumber}`;
        if ((receipt.note || '') !== newNote) {
          needsUpdate.note = newNote;
          hasChanges = true;
        }

        // Если есть изменения - обновляем
        if (hasChanges) {
          needsUpdate.editorEmail = 'sync@system';
          needsUpdate.editedAt = new Date();
          
          await prisma.receiptMaterial.update({
            where: { id: receipt.id },
            data: needsUpdate
          });
          
          updatedRecords++;
          totalWithNote++;
          
          writeLog(`✅ Обновлено поступление ID: ${receipt.id} для AEng ID: ${record.id}`, 'SUCCESS');
          writeLog(`   📅 Дата: ${aengData.qualDocDate || 'null'}`, 'INFO');
          writeLog(`   🔢 Номер: ${aengData.qualDocNumber}`, 'INFO');
          writeLog(`   📄 Путь: ${aengData.qualDocPath || 'null'}`, 'INFO');
          writeLog(`   📝 Примечание: ${newNote}`, 'INFO');
        } else {
          skippedRecords++;
          // Проверяем, есть ли примечание
          if (receipt.note) {
            totalWithNote++;
          }
        }

      } catch (error) {
        errorRecords++;
        writeLog(`❌ Ошибка при обработке AEng ID: ${record.id}: ${error}`, 'ERROR');
        if (error instanceof Error) {
          writeLog(`   ${error.stack}`, 'ERROR');
        }
      }
    }

    // Выводим прогресс
    writeLog(`📊 Прогресс: обработано ${totalRecords} записей, обновлено ${updatedRecords}, пропущено ${skippedRecords}, ошибок ${errorRecords}`, 'INFO');
    skip += CHUNK_SIZE;
  }

  // ========================================
  // 5. ИТОГОВАЯ СТАТИСТИКА
  // ========================================
  writeLog('', 'INFO');
  writeLog('🎉 СИНХРОНИЗАЦИЯ ЗАВЕРШЕНА!', 'SUCCESS');
  writeLog('📊 ИТОГОВАЯ СТАТИСТИКА:', 'INFO');
  writeLog(`   📋 Всего обработано записей AEng: ${totalRecords}`, 'INFO');
  writeLog(`   ✅ Обновлено записей receipt_materials: ${updatedRecords}`, 'SUCCESS');
  writeLog(`   ⏭️ Пропущено (без изменений): ${skippedRecords}`, 'INFO');
  writeLog(`   ❌ Ошибок: ${errorRecords}`, errorRecords > 0 ? 'ERROR' : 'INFO');
  writeLog(`   🔄 Исправлено materialId: ${materialIdFixed}`, 'INFO');
  writeLog(`   📝 Записей с примечанием: ${totalWithNote}`, 'INFO');

  // Проверка, что все записи имеют примечание
  const allReceipts = await prisma.receiptMaterial.count();
  const receiptsWithNote = await prisma.receiptMaterial.count({
    where: {
      note: {
        not: null
      }
    }
  });
  
  writeLog(`\n📋 СТАТИСТИКА ПОСТУПЛЕНИЙ:`, 'INFO');
  writeLog(`   📊 Всего записей в receipt_materials: ${allReceipts}`, 'INFO');
  writeLog(`   📝 С примечанием: ${receiptsWithNote}`, 'INFO');
  writeLog(`   ⚠️ Без примечания: ${allReceipts - receiptsWithNote}`, allReceipts - receiptsWithNote > 0 ? 'WARN' : 'INFO');

  // Дополнительная проверка: записи без примечания
  if (allReceipts - receiptsWithNote > 0) {
    writeLog(`\n⚠️ Найдены записи без примечания.`, 'WARN');
    
    const receiptsWithoutNote = await prisma.receiptMaterial.findMany({
      where: {
        note: null
      },
      take: 10,
      include: {
        material: true
      }
    });
    
    writeLog(`   Первые 10 записей без примечания:`, 'WARN');
    for (const r of receiptsWithoutNote) {
      writeLog(`   - ID: ${r.id}, Материал: ${r.material?.name || 'неизвестен'}, Документ: ${r.qualDocNumber || 'нет'}`, 'WARN');
    }
  }

  // ========================================
  // 6. ФИНАЛЬНАЯ ПРОВЕРКА СВЯЗЕЙ
  // ========================================
  writeLog(`\n🔍 ПРОВЕРКА СВЯЗЕЙ:`, 'INFO');
  
  // Проверяем, есть ли акты без поступлений
  const actsWithoutReceipt = await prisma.$queryRaw`
    SELECT COUNT(*) as count
    FROM sampling_tests st
    LEFT JOIN receipt_materials rm ON st."receiptMaterialId" = rm.id
    WHERE rm.id IS NULL
  `;
  
  const missingReceipts = Number(actsWithoutReceipt[0].count);
  writeLog(`   📄 Актов без поступлений: ${missingReceipts}`, missingReceipts > 0 ? 'WARN' : 'SUCCESS');
  
  // Проверяем, есть ли поступления без актов
  const receiptsWithoutAct = await prisma.$queryRaw`
    SELECT COUNT(*) as count
    FROM receipt_materials rm
    LEFT JOIN sampling_tests st ON st."receiptMaterialId" = rm.id
    WHERE st.id IS NULL
  `;
  
  const missingActs = Number(receiptsWithoutAct[0].count);
  writeLog(`   📥 Поступлений без актов: ${missingActs}`, missingActs > 0 ? 'WARN' : 'SUCCESS');

  await prisma.$disconnect();
  writeLog(`\n👋 Соединение с БД закрыто`, 'INFO');
  writeLog(`📁 Лог-файл сохранен: ${LOG_FILE}`, 'INFO');
}

// ============================================
// ЗАПУСК СКРИПТА
// ============================================
syncReceiptMaterials()
  .catch((error) => {
    console.error('❌ КРИТИЧЕСКАЯ ОШИБКА:', error);
    writeLog(`❌ КРИТИЧЕСКАЯ ОШИБКА: ${error}`, 'ERROR');
    if (error instanceof Error) {
      writeLog(error.stack || '', 'ERROR');
    }
    process.exit(1);
  });