import { readFile, writeFile } from 'node:fs/promises'
const file = new URL('../nuxt.config.ts', import.meta.url)
const source = await readFile(file, 'utf8')
const pattern = /(['"])(\*\/60|0|\*\/15) \* \* \* \*\1(\s*:\s*\[\s*['"]ad:refresh-ad-cache['"]\s*\])/g
const matches = [...source.matchAll(pattern)]
if (matches.length !== 1) throw new Error('Не найдено единственное ожидаемое расписание AD. Измените cron задачи ad:refresh-ad-cache на */15 * * * * вручную.')
if (matches[0][2] === '*/15') { console.log('Расписание AD уже настроено: каждые 15 минут.') }
else {
  const next = source.replace(pattern, (_, quote, old, suffix) => `${quote}*/15 * * * *${quote}${suffix}`)
  await writeFile(new URL('../nuxt.config.ts.before-auto-cache', import.meta.url), source, { flag: 'wx' })
  await writeFile(file, next)
  console.log('Расписание AD: каждые 15 минут. Исходный nuxt.config.ts сохранён в nuxt.config.ts.before-auto-cache.')
}
