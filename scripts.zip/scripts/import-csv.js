// scripts/import-csv.js
import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import csv from 'csv-parser';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const prisma = new PrismaClient();

// Функция парсинга даты из DD.MM.YYYY
function parseRussianDate(dateStr) {
  if (!dateStr || dateStr.trim() === '') return null;
  const parts = dateStr.trim().split('.');
  if (parts.length !== 3) return null;
  const day = parseInt(parts[0]);
  const month = parseInt(parts[1]) - 1;
  const year = parseInt(parts[2]);
  return new Date(Date.UTC(year, month, day));
}

// Функция очистки поля от лишних кавычек и пробелов
function cleanValue(value) {
  if (!value || value.trim() === '') return null;
  let cleaned = value.trim();
  if (cleaned.startsWith('"') && cleaned.endsWith('"')) {
    cleaned = cleaned.slice(1, -1);
  }
  cleaned = cleaned.replace(/""/g, '"');
  return cleaned || null;
}

// Функция для безопасного получения значения из строки CSV
function getField(row, key) {
  const value = row[key];
  return cleanValue(value);
}

async function importCSV() {
  try {
    await prisma.$connect();
    console.log('✅ Подключение к БД установлено');

    const filePath = path.join(__dirname, '..', 'server', 'assets', 'Reestr.csv');

    if (!fs.existsSync(filePath)) {
      throw new Error(`Файл не найден: ${filePath}`);
    }

    console.log(`📖 Чтение файла: ${filePath}`);

    const records = [];
    let totalRows = 0;
    let emptyRows = 0;
    let errorRows = 0;

    await new Promise((resolve, reject) => {
      fs.createReadStream(filePath, { encoding: 'utf-8' })
        .pipe(csv({
          separator: ';',
          quote: '"',
          escape: '"',
          skipLines: 0,
          strict: false,
          trim: true,
        }))
        .on('data', (row) => {
          totalRows++;

          const hasData = Object.values(row).some(val => val && val.trim() !== '');
          if (!hasData) {
            emptyRows++;
            return;
          }

          if (!row['Дата отбора проб'] && !row['Номер протокола']) {
            console.log(`⚠️ Пропущена строка ${totalRows}: нет даты и номера протокола`);
            errorRows++;
            return;
          }

          // Создаем запись в соответствии с новой схемой
          const record = {
            // Основные поля из CSV
            plp: getField(row, 'ПЛП'),
            objectName: getField(row, 'Наименование объект'),
            samplingActNumber: getField(row, 'Номер акта отбора проб'),
            samplingDate: parseRussianDate(row['Дата отбора проб']),
            samplingPlace: getField(row, 'Место отбора проб'),
            personProvidedSample: getField(row, 'Лицо, предоставившее пробу'),
            materialReceiptDate: parseRussianDate(row['Дата поступления материала']),
            materialName: getField(row, 'Наименование материала'),
            
            // Старое поле (оставляем для обратной совместимости)
            qualityDocument: getField(row, 'Документ о качестве'),
            
            // Новые поля для документов (пока null)
            sDocPath: null,
            qualDocPath: null,
            testDocPath: null,
            protocolDocPath: null,
            qualDocNumber: null,
            qualDocDate: null,
            authorEmail: null,
            editorEmail: null,
            
            // Остальные поля из CSV
            manufacturer: getField(row, 'Предприятие-изготовитель'),
            protocolNumber: getField(row, 'Номер протокола'),
            protocolDate: parseRussianDate(row['Дата протокола']),
            testResult: getField(row, 'Результат испытаний'),
            note: getField(row, 'Примечание'),
            
            // Системные поля
            createdAt: new Date(),
            // editedAt: null - не указываем, Prisma сам поставит null по умолчанию
          };

          records.push(record);
        })
        .on('end', () => {
          console.log(`📊 Прочитано строк: ${totalRows}`);
          console.log(`📊 Пустых строк: ${emptyRows}`);
          console.log(`📊 Строк с ошибками: ${errorRows}`);
          console.log(`📊 Успешно распарсено: ${records.length}`);
          resolve();
        })
        .on('error', (err) => {
          console.error('❌ Ошибка чтения файла:', err);
          reject(err);
        });
    });

    if (records.length === 0) {
      console.log('⚠️ Нет данных для импорта');
      return;
    }

    console.log('\n🔍 Проверка существующих записей в БД...');
    const existingCount = await prisma.aEng.count();
    console.log(`📊 Уже в БД: ${existingCount} записей`);

    const batchSize = 100;
    let imported = 0;
    let skipped = 0;

    console.log(`\n🚀 Начинаю импорт ${records.length} записей...`);

    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);

      try {
        const result = await prisma.aEng.createMany({
          data: batch,
          skipDuplicates: true,
        });

        imported += result.count;
        skipped += batch.length - result.count;

        console.log(`✅ Батч ${Math.floor(i / batchSize) + 1}: вставлено ${result.count}, пропущено ${batch.length - result.count}`);
        console.log(`📊 Прогресс: ${Math.min(i + batchSize, records.length)}/${records.length} (всего вставлено: ${imported})`);

      } catch (error) {
        console.error(`❌ Ошибка в батче ${Math.floor(i / batchSize) + 1}:`, error.message);

        // Пытаемся найти проблемную запись
        for (let j = 0; j < batch.length; j++) {
          try {
            await prisma.aEng.create({ data: batch[j] });
          } catch (singleError) {
            console.error(`   🔴 Проблемная запись ${i + j + 1}:`, singleError.message);
            console.log('   Данные:', JSON.stringify(batch[j], null, 2));
            break;
          }
        }
        break;
      }
    }

    console.log('\n🎉 ИТОГИ ИМПОРТА:');
    console.log(`📊 Всего записей в CSV: ${records.length}`);
    console.log(`✅ Успешно импортировано: ${imported}`);
    console.log(`⏭️ Пропущено (дубликаты): ${skipped}`);
    console.log(`📊 Всего в БД: ${await prisma.aEng.count()} записей`);

  } catch (error) {
    console.error('❌ Критическая ошибка:', error);
  } finally {
    await prisma.$disconnect();
    console.log('🔌 Соединение с БД закрыто');
  }
}

importCSV();