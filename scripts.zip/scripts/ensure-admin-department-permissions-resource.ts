// scripts/ensure-admin-department-permissions-resource.ts

import {
  AccessAction,
  AccessResourceType,
  PrismaClient,
} from '@prisma/client'


const prisma =
  new PrismaClient()


const RESOURCE_KEY =
  'admin.department-permissions'


function readGrantLogin():
  string | null {
  const prefix =
    '--grant-login='

  const value =
    process.argv.find(
      arg =>
        arg.startsWith(
          prefix,
        ),
    )

  return value
    ? value
      .slice(
        prefix.length,
      )
      .trim() ||
      null
    : null
}


async function main() {
  const resource =
    await prisma.accessResource
      .upsert({
        where: {
          key:
            RESOURCE_KEY,
        },

        update: {
          name:
            'Права подразделений',

          description:
            'Разрешает выдавать и отзывать права AccessResource целому подразделению Space.',

          type:
            AccessResourceType.FEATURE,

          isActive:
            true,
        },

        create: {
          key:
            RESOURCE_KEY,

          name:
            'Права подразделений',

          description:
            'Разрешает выдавать и отзывать права AccessResource целому подразделению Space.',

          type:
            AccessResourceType.FEATURE,

          isActive:
            true,

          sortOrder:
            1030,
        },
      })


  console.log(
    `✅ FEATURE-ресурс готов: ${RESOURCE_KEY}`,
  )


  const login =
    readGrantLogin()


  if (!login) {
    console.log(
      'ℹ️ UPDATE никому не выдавался.',
    )

    return
  }


  const user =
    await prisma.user
      .findUnique({
        where: {
          login,
        },

        select: {
          id:
            true,

          login:
            true,
        },
      })


  if (!user) {
    throw new Error(
      `Пользователь "${login}" не найден`,
    )
  }


  await prisma.userPermission
    .upsert({
      where: {
        userId_resourceId_action: {
          userId:
            user.id,

          resourceId:
            resource.id,

          action:
            AccessAction.UPDATE,
        },
      },

      update: {
        grantedByLogin:
          'bootstrap-script',
      },

      create: {
        userId:
          user.id,

        resourceId:
          resource.id,

        action:
          AccessAction.UPDATE,

        grantedByLogin:
          'bootstrap-script',
      },
    })


  console.log(
    `✅ UPDATE выдан пользователю ${user.login}`,
  )
}


main()
  .catch(
    error => {
      console.error(
        '❌ Ошибка:',
        error,
      )

      process.exitCode =
        1
    },
  )
  .finally(
    async () => {
      await prisma.$disconnect()
    },
  )
