// Точечная доработка формы объектов: не заменяет прочие изменения в большом Vue-файле.
import { readFile, writeFile, copyFile } from 'node:fs/promises';
const path = 'app/components/lab/ObjectsForm.vue';
const original = await readFile(path, 'utf8');
if (original.includes('// space-delete-reason-v1')) {
  console.log('ObjectsForm.vue: изменения уже применены.');
} else {
  let result = original;
  const once = (from, to) => {
    if (!result.includes(from) || result.indexOf(from) !== result.lastIndexOf(from)) {
      throw new Error(`Форма отличается от проверенной версии. Файл не изменён. Не найден однозначный фрагмент: ${from}`);
    }
    result = result.replace(from, to);
  };
  once('<script setup lang="ts">', `<script setup lang="ts">
// space-delete-reason-v1
import { useDeletePermission } from '~/composables/useDeletePermission';
import { requestDeletionReason } from '~/composables/useDeletionReason';
const { canDelete: canDeleteObject, refreshDeletePermission: checkObjectDelete } = useDeletePermission('lab.test-objects');
const { canDelete: canDeleteLocation, refreshDeletePermission: checkLocationDelete } = useDeletePermission('lab.test-locations');
`);
  for (const [kind, label, check] of [['Object', 'объект', 'checkObjectDelete'], ['Location', 'место', 'checkLocationDelete']]) {
    const variable = kind.toLowerCase();
    once(`async function delete${kind}(\n  ${variable}: ${kind}Row,\n) {`, `async function delete${kind}(\n  ${variable}: ${kind}Row,\n) {\n  if (!await ${check}()) return;`);
    once(`  if (\n    !confirm(\n      \`Удалить ${label} «\${${variable}.name}»?\`,\n    )\n  ) {\n    return\n  }`, `  const reason = requestDeletionReason(${variable}.name);\n  if (reason === null) return;`);
    const route = kind === 'Object' ? 'objects' : 'locations';
    once(`\`/api/lab/${route}/\${${variable}.id}\`,\n        {\n          method:\n            'DELETE',`, `\`/api/lab/${route}/\${${variable}.id}\`,\n        {\n          body: { reason },\n          method:\n            'DELETE',`);
  }
  // v-if не конфликтует с уже существующими :disabled у кнопок.
  once('@click.stop="deleteObject(object)"', 'v-if="canDeleteObject" @click.stop="deleteObject(object)"');
  once('@click="deleteObject(selectedObject)"', 'v-if="canDeleteObject" @click="deleteObject(selectedObject)"');
  once('@click="deleteLocation(location)"', 'v-if="canDeleteLocation" @click="deleteLocation(location)"');
  await copyFile(path, `${path}.before-delete-v1.bak`);
  await writeFile(path, result);
  console.log('ObjectsForm.vue: причина и проверка DELETE добавлены; резервная копия сохранена.');
}
