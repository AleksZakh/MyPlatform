// scripts/ensure-admin-ad-cache-refresh-resource.ts

import {
  AccessAction,
  AccessResourceType,
  PrismaClient,
} from '@prisma/client'


const prisma =
  new PrismaClient()


const RESOURCE_KEY =
  'admin.ad-cache-refresh'


function readGrantLogin():
  string | null {
  const prefix =
    '--grant-login='

  const arg =
    process.argv.find(
      value =>
        value.startsWith(
          prefix,
        ),
    )

  if (!arg) {
    return null
  }

  return (
    arg.slice(
      prefix.length,
    ).trim() ||
    null
  )
}


async function main() {
  const resource =
    await prisma.accessResource
      .upsert({
        where: {
          key:
            RESOURCE_KEY,
        },

        update: {
          name:
            'Обновление кэша Active Directory',

          description:
            'Позволяет вручную обновлять кэш доменных пользователей Active Directory из AdminCenter.',

          type:
            AccessResourceType.FEATURE,

          isActive:
            true,
        },

        create: {
          key:
            RESOURCE_KEY,

          name:
            'Обновление кэша Active Directory',

          description:
            'Позволяет вручную обновлять кэш доменных пользователей Active Directory из AdminCenter.',

          type:
            AccessResourceType.FEATURE,

          isActive:
            true,

          sortOrder:
            1010,
        },
      })


  console.log(
    `✅ FEATURE-ресурс готов: ${RESOURCE_KEY}`,
  )


  const grantLogin =
    readGrantLogin()


  if (!grantLogin) {
    console.log(
      'ℹ️ UPDATE пользователю не выдавался.',
    )

    console.log(
      '   Для теста:',
    )

    console.log(
      '   npx tsx scripts/ensure-admin-ad-cache-refresh-resource.ts --grant-login=LOGIN',
    )

    return
  }


  const user =
    await prisma.user
      .findUnique({
        where: {
          login:
            grantLogin,
        },

        select: {
          id:
            true,

          login:
            true,
        },
      })


  if (!user) {
    throw new Error(
      `Пользователь "${grantLogin}" не найден в app_users`,
    )
  }


  await prisma.userPermission
    .upsert({
      where: {
        userId_resourceId_action: {
          userId:
            user.id,

          resourceId:
            resource.id,

          action:
            AccessAction.UPDATE,
        },
      },

      update: {
        grantedByLogin:
          'bootstrap-script',
      },

      create: {
        userId:
          user.id,

        resourceId:
          resource.id,

        action:
          AccessAction.UPDATE,

        grantedByLogin:
          'bootstrap-script',
      },
    })


  console.log(
    `✅ UPDATE выдан пользователю ${user.login}`,
  )
}


main()
  .catch(
    error => {
      console.error(
        '❌ Ошибка:',
        error,
      )

      process.exitCode =
        1
    },
  )
  .finally(
    async () => {
      await prisma.$disconnect()
    },
  )
