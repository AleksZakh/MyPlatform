import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()
async function main() {
  const result = await prisma.accessResource.updateMany({
    where: { key: 'lab.incoming-control.edit-lock-override' },
    data: {
      name: 'Обход 30-минутной блокировки Реестра входного контроля',
      description: 'Позволяет руководителю редактировать отбор проб, поступление материала и существующий протокол после истечения стандартного 30-минутного окна.',
    },
  })
  console.log(`Обновлено описаний ресурса: ${result.count}. Назначения прав и активность ресурса не изменены.`)
}
main().catch(error => { console.error(error); process.exitCode = 1 }).finally(() => prisma.$disconnect())
